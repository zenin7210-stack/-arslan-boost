import tempfile
import unittest
from pathlib import Path
from service import Store, ValidationError
from donat_catalog import normalize_order, PRODUCTS


class DonatOrderTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / 'store.sqlite3')
        self.user = {'id': 123456, 'username': 'buyer'}

    def tearDown(self):
        self.temp.cleanup()

    def order(self, **changes):
        data={'product':'gold_id','option':'100','detail':'12345678','paymentMethod':'uzcard',
              'requestId':'fixed-order-123456','lang':'uz','amount':1}
        data.update(changes)
        return data

    def test_prices_are_server_authoritative(self):
        item=normalize_order(self.order())
        self.assertEqual(item['amount'],24990)
        item=normalize_order(self.order(product='gold_rinok',quantity=101,detail=''))
        self.assertEqual(item['amount'],12110)
        item=normalize_order(self.order(product='gold_rinok',quantity=10000,detail=''))
        self.assertEqual(item['amount'],1199000)

    def test_donat_receipt_flow(self):
        record,new=self.store.create_donat_order(self.user,self.order())
        self.assertTrue(new)
        self.assertEqual(record['amount'],24990)
        same,new=self.store.create_donat_order(self.user,self.order())
        self.assertFalse(new)
        self.assertEqual(same['id'],record['id'])
        with self.assertRaises(ValidationError):
            self.store.create_donat_order(self.user,self.order(option='200'))
        with self.assertRaises(ValidationError):
            self.store.donat_order(record['id'],user_id=654321)
        self.assertFalse(self.store.attach_donat_receipt(record['id'],999,'file','photo'))
        self.assertTrue(self.store.attach_donat_receipt(record['id'],self.user['id'],'file','photo'))
        self.assertEqual(self.store.donat_order(record['id'])['status'],'review')
        self.assertTrue(self.store.decide_donat(record['id'],True))
        self.assertFalse(self.store.decide_donat(record['id'],True))
        self.assertEqual(self.store.donat_state(self.user['id'])[0]['status'],'paid')
        self.assertFalse(self.store.attach_donat_receipt(record['id'],self.user['id'],'file2','photo'))

    def test_reject_unsafe_inputs(self):
        for data in [self.order(option='999'),self.order(detail='<script>'),
                     self.order(detail=''),self.order(paymentMethod='invalid_method'),
                     self.order(product='unknown'),self.order(product='gold_rinok',quantity=0,detail='')]:
            with self.subTest(data=data):
                with self.assertRaises(ValidationError):
                    normalize_order(data)

    def test_existing_boost_still_works(self):
        boost={'mode':'wing','fromIndex':0,'toIndex':2,'gameId':'12345678',
               'paymentMethod':'uzcard','requestId':'boost-request-123456'}
        row,new=self.store.create_order(self.user,boost)
        self.assertTrue(new)
        self.assertEqual(row['amount'],12000)
        self.assertEqual(len(self.store.state(self.user['id'])['orders']),1)


if __name__=='__main__':
    unittest.main()

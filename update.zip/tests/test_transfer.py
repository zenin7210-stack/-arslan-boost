import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from referrals import Referrals
from service import Store, ValidationError


class TransferTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.store = Store(Path(directory.name) / 'test.sqlite3', transfer_test=True)
        self.user = {'id': 123, 'username': 'buyer'}

    def topup(self, key='topup-test'):
        payment, _ = self.store.create_topup(self.user, {
            'paymentMethod': 'uzcard', 'amount': 50_000, 'requestId': key,
        })
        return payment['id']

    def test_topup_requires_receipt_and_credits_once(self):
        payment_id = self.topup()
        self.assertEqual(self.topup(), payment_id)
        with self.assertRaisesRegex(ValidationError, 'receipt_required'):
            self.store.decide_manual(payment_id, True)
        self.assertFalse(self.store.attach_receipt(payment_id, 456, 'photo-id', 'photo', 'photo-unique'))
        self.assertTrue(self.store.attach_receipt(payment_id, 123, 'photo-id', 'photo', 'photo-unique'))
        self.assertEqual(self.store.pending_admin_notices(), [payment_id])
        self.assertEqual(self.store.state(123)['payments'][0]['status'], 'review')
        self.store.mark_admin_notified(payment_id)
        self.assertTrue(self.store.attach_receipt(payment_id, 123, 'photo-id', 'photo', 'photo-unique'))
        self.assertFalse(self.store.pending_admin_notices())
        second = self.topup('topup-second')
        with self.assertRaisesRegex(ValidationError, 'receipt_used'):
            self.store.attach_receipt(second, 123, 'same-photo-other-id', 'photo', 'photo-unique')
        self.assertEqual(self.store.state(123)['balance'], 0)
        with ThreadPoolExecutor(max_workers=2) as executor:
            approvals = list(executor.map(lambda _: self.store.decide_manual(payment_id, True), range(2)))
        self.assertEqual(sum(approvals), 1)
        self.assertEqual(self.store.state(123)['balance'], 50_000)
        self.assertEqual(self.store.state(123)['starsBalance'], 0)
        self.assertFalse(self.store.pending_admin_notices())
        self.store.create_order(self.user, {
            'mode': 'wing', 'fromIndex': 0, 'toIndex': 3, 'gameId': '12345678',
            'paymentMethod': 'balance', 'expectedAmount': 13_000, 'requestId': 'wallet-checkout',
        })
        self.assertEqual(self.store.state(123)['balance'], 37_000)

    def test_both_catalogs_move_to_work_on_approval(self):
        boost_data = {'mode': 'wing', 'fromIndex': 0, 'toIndex': 3, 'gameId': '12345678',
                      'paymentMethod': 'uzcard', 'expectedAmount': 13_000, 'requestId': 'boost-checkout'}
        donat_data = {'product': 'gold_id', 'option': '100', 'detail': '12345678',
                      'paymentMethod': 'uzcard', 'expectedAmount': 24_990, 'requestId': 'donat-checkout'}
        for make, data in ((self.store.create_order, boost_data), (self.store.create_donat_order, donat_data)):
            with self.assertRaisesRegex(ValidationError, 'order_quote_changed'):
                make(self.user, {**data, 'expectedAmount': 1})
        boost, _ = self.store.create_order(self.user, boost_data)
        donat, _ = self.store.create_donat_order(self.user, donat_data)
        boost_payment = self.store.payment(order_id=boost['id'])
        donat_payment = self.store.payment(donat_order_id=donat['id'])
        self.assertFalse(self.store.pending_admin_notices())
        self.assertFalse(self.store.attach_donat_receipt(donat['id'], 123, 'legacy', 'photo'))
        self.assertFalse(self.store.decide_donat(donat['id'], True))
        for payment in (boost_payment, donat_payment):
            pid = payment['id']
            self.assertTrue(self.store.attach_receipt(pid, 123, f'file-{pid}', 'document', f'unique-{pid}'))
        self.assertEqual(self.store.state(123)['orders'][0]['status'], 'review')
        self.assertEqual(self.store.donat_order(donat['id'])['status'], 'review')
        for payment in (boost_payment, donat_payment):
            self.assertTrue(self.store.decide_manual(payment['id'], True))
        self.assertEqual(self.store.state(123)['orders'][0]['status'], 'in_progress')
        self.assertEqual(self.store.donat_order(donat['id'])['status'], 'in_progress')
        self.assertEqual(self.store.state(123)['balance'], 0)
        self.assertTrue(Referrals(self.store).fulfilled('donat', donat['id'], 9000)['new'])

    def test_rejection_does_not_credit_wallet(self):
        pid = self.topup()
        self.store.attach_receipt(pid, 123, 'file', 'photo', 'unique')
        self.assertTrue(self.store.decide_manual(pid, False))
        self.assertFalse(self.store.decide_manual(pid, True))
        self.assertEqual(self.store.payment(payment_id=pid)['status'], 'rejected')
        self.assertEqual(self.store.state(123)['balance'], 0)

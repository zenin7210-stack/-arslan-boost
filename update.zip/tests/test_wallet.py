import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from service import Store, ValidationError


class WalletTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name) / 'wallet.sqlite3'
        self.store = Store(self.path, stars_rate=160)
        self.buyer = {'id': 1001}

    def topup(self, **changes):
        data = {'paymentMethod': 'stars', 'stars': 100, 'starsRate': 160, 'requestId': 'topup-first'}
        return self.store.create_topup(self.buyer, {**data, **changes})

    def settle(self, payment, charge='telegram-charge'):
        return self.store.settle_stars(payment['id'], self.buyer['id'], 'XTR', payment['stars'], charge)

    def test_credit_comes_from_a_single_matching_telegram_charge(self):
        payment, created = self.topup(amount=1)
        self.assertTrue(created)
        self.assertEqual(payment['amount'], 16_000)
        self.assertEqual(self.store.state(self.buyer['id'])['starsBalance'], 0)
        for user, currency, stars in ((1002, 'XTR', 100), (1001, 'UZS', 100), (1001, 'XTR', 99)):
            with self.assertRaisesRegex(ValidationError, 'invalid_payment'):
                self.store.settle_stars(payment['id'], user, currency, stars, 'incorrect-charge')
        self.assertTrue(self.settle(payment))
        self.assertFalse(self.settle(payment))
        second_payment, _ = self.topup(requestId='topup-second')
        with self.assertRaisesRegex(ValidationError, 'duplicate_payment'):
            self.settle(second_payment)
        self.assertTrue(self.settle(second_payment, 'new-charge'))
        self.assertEqual(self.store.state(self.buyer['id'])['starsBalance'], 32_000)

    def test_topup_validates_count_rate_and_retry(self):
        for stars in (0, -1, True, 1.5, 100_001, '9' * 4500):
            with self.subTest(stars=str(stars)[:20]), self.assertRaises(ValidationError):
                self.topup(stars=stars)
        payment, _ = self.topup()
        self.store = Store(self.path, stars_rate=200)
        same, created = self.topup()
        self.assertEqual(same['id'], payment['id'])
        self.assertFalse(created)
        with self.assertRaisesRegex(ValidationError, 'stars_quote_changed'):
            self.topup(requestId='topup-outdated')

    def test_orders_debit_only_stars_wallet_and_retry_once(self):
        user_id = self.buyer['id']
        self.store.credit(user_id, 50_000, 'manual-credit')
        boost = {'mode': 'wing', 'fromIndex': 0, 'toIndex': 3, 'gameId': '12345678',
                 'paymentMethod': 'balance', 'requestId': 'boost-order'}
        donat = {'product': 'gold_id', 'option': '100', 'detail': '12345678',
                 'paymentMethod': 'balance', 'requestId': 'donat-order'}
        with self.assertRaisesRegex(ValidationError, 'insufficient_balance'):
            self.store.create_order(self.buyer, boost)
        with self.assertRaisesRegex(ValidationError, 'invalid_payment_method'):
            self.store.create_order(self.buyer, {**boost, 'paymentMethod': 'stars'})
        with self.assertRaisesRegex(ValidationError, 'invalid_payment_method'):
            self.store.create_donat_order(self.buyer, {**donat, 'paymentMethod': 'stars'})
        payment, _ = self.topup(stars=250)
        self.settle(payment)
        with self.assertRaisesRegex(ValidationError, 'order_quote_changed'):
            self.store.create_order(self.buyer, {**boost, 'expectedAmount': 1})
        with self.assertRaisesRegex(ValidationError, 'order_quote_changed'):
            self.store.create_donat_order(self.buyer, {**donat, 'expectedAmount': 1})
        order, created = self.store.create_order(self.buyer, boost)
        self.assertTrue(created)
        self.assertEqual(order['status'], 'paid')
        with ThreadPoolExecutor(max_workers=2) as executor:
            results = list(executor.map(lambda _: self.store.create_donat_order(self.buyer, donat), range(2)))
        self.assertEqual(sum(created for _, created in results), 1)
        self.assertEqual(results[0][0]['id'], results[1][0]['id'])
        self.assertEqual(results[0][0]['status'], 'paid')
        self.assertEqual(self.store.state(user_id)['starsBalance'], 2_010)
        self.assertEqual(self.store.state(user_id)['balance'], 52_010)
        notices = self.store.pending_admin_notices()
        self.assertEqual(len(notices), 2)
        self.store.mark_admin_notified(notices[0])
        self.assertEqual(self.store.pending_admin_notices(), notices[1:])

        # Reopen an older accounts schema, which tracked a single combined balance.
        with self.store.connect() as con:
            con.execute('ALTER TABLE accounts DROP COLUMN stars_balance')
        self.store = Store(self.path, stars_rate=160)
        self.assertEqual(self.store.state(user_id)['starsBalance'], 2_010)
        self.assertEqual(self.store.state(user_id)['balance'], 52_010)

import tempfile
import unittest
from pathlib import Path
from datetime import datetime, timezone, timedelta
from service import Store, ValidationError
from referrals import Referrals, MIN_WITHDRAW


class ReferralTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.store=Store(Path(self.tmp.name)/'test.sqlite3')
        self.refs=Referrals(self.store)
        self.buyer={'id':9911,'username':'buyer'}
        self.buyer2={'id':9912,'username':'buyer2'}
        self.blogger={'id':5511,'username':'blogger'}
        self.blogger2={'id':5512,'username':'blogger2'}

    def tearDown(self):self.tmp.cleanup()

    def make_partner(self,user):
        status,new=self.refs.apply(user);self.assertTrue(new)
        self.assertEqual(self.refs.approve(user['id']),'approved')
        return self.refs.dashboard(user['id'],'arslanboostbot')['code']

    def order(self,user=None,key='request-order-1'):
        user=user or self.buyer
        return self.store.create_donat_order(user,{'product':'gold_rinok','quantity':3000,
                'detail':'','option':None,'paymentMethod':'uzcard','requestId':key})[0]

    def paid(self,order):
        self.assertTrue(self.store.attach_donat_receipt(order['id'],order['user_id'],'file','photo'))
        self.assertTrue(self.store.decide_donat(order['id'],True))

    def test_unique_lifetime_bind_and_private_dashboard(self):
        a=self.make_partner(self.blogger);b=self.make_partner(self.blogger2)
        self.assertFalse(self.refs.bind(self.blogger['id'],a))
        self.assertTrue(self.refs.bind(self.buyer['id'],a))
        self.assertFalse(self.refs.bind(self.buyer['id'],b))
        self.assertEqual(self.refs.partner_for(self.buyer['id']),self.blogger['id'])
        self.assertEqual(self.refs.dashboard(self.blogger['id'],'arslanboostbot')['clients'],1)
        self.assertEqual(self.refs.dashboard(self.blogger2['id'],'arslanboostbot')['clients'],0)
        self.assertEqual(self.refs.dashboard(self.buyer['id'])['status'],'none')
        self.assertTrue(self.refs.dashboard(self.blogger['id'],'arslanboostbot')['url'].endswith(a))

    def test_complete_donat_24h_50pct_and_withdraw(self):
        code=self.make_partner(self.blogger)
        self.refs.bind(self.buyer['id'],code)
        order=self.order()
        self.assertEqual(self.refs.track_order('donat',order['id']),self.blogger['id'])
        self.assertFalse(self.refs.claim_paid_notice('donat',order['id']))
        self.paid(order)
        self.assertEqual(self.refs.claim_paid_notice('donat',order['id']),self.blogger['id'])
        self.assertIsNone(self.refs.claim_paid_notice('donat',order['id']))
        # 3000 Gold x 11990 / 100 = 359700 UZS; cost 259700 => profit 100000 and affiliate 50000
        result=self.refs.fulfilled('donat',order['id'],259700,now=1000000)
        self.assertEqual(result['commission'],50000)
        self.assertFalse(self.refs.fulfilled('donat',order['id'],259700,now=1000001)['new'])
        self.assertEqual(self.refs.release_due(now=1000000+86399),[])
        state=self.refs.dashboard(self.blogger['id'])
        self.assertEqual(state['available'],0)
        self.assertEqual(state['pending'],50000)
        self.assertEqual(self.refs.release_due(now=1000000+86400),[{'partner_id':self.blogger['id'],'amount':50000}])
        self.assertEqual(self.refs.release_due(now=1000000+86401),[])
        state=self.refs.dashboard(self.blogger['id'])
        self.assertEqual(state['available'],50000)
        self.assertEqual(state['pending'],0)
        with self.assertRaises(ValidationError):self.refs.withdraw(self.blogger['id'],9000,'Humo 12345')
        oid=self.refs.withdraw(self.blogger['id'],20000,'Humo 12345')
        self.assertEqual(self.refs.dashboard(self.blogger['id'])['available'],30000)
        with self.assertRaises(ValidationError):self.refs.withdraw(self.blogger['id'],40000,'Humo 12345')
        self.assertEqual(self.refs.decide_withdraw(oid,True)['partner_id'],self.blogger['id'])
        self.assertIsNone(self.refs.decide_withdraw(oid,True))
        self.assertEqual(self.refs.dashboard(self.blogger['id'])['available'],30000)
        self.assertEqual(self.refs.reverse('donat',order['id']),True)
        self.assertEqual(self.refs.dashboard(self.blogger['id'])['available'],0)
        self.assertEqual(self.refs.reverse('donat',order['id']),False)

    def test_no_retroactive_and_no_early_commission(self):
        code=self.make_partner(self.blogger)
        order=self.order()
        self.assertTrue(self.refs.bind(self.buyer['id'],code))
        self.assertIsNone(self.refs.track_order('donat',order['id']))
        self.paid(order)
        self.assertIsNone(self.refs.claim_paid_notice('donat',order['id']))
        r=self.refs.fulfilled('donat',order['id'],10000)
        self.assertIsNone(r['partner_id'])
        self.assertEqual(self.refs.dashboard(self.blogger['id'])['available'],0)

    def test_require_actual_payment_and_zero_profit(self):
        code=self.make_partner(self.blogger)
        self.refs.bind(self.buyer['id'],code)
        order=self.order()
        self.refs.track_order('donat',order['id'])
        with self.assertRaisesRegex(ValidationError,'order_not_paid'):
            self.refs.fulfilled('donat',order['id'],10000)
        self.paid(order)
        result=self.refs.fulfilled('donat',order['id'],10000000)
        self.assertEqual(result['commission'],0)
        self.assertEqual(self.store.donat_order(order['id'])['status'],'fulfilled')
        self.assertEqual(self.refs.dashboard(self.blogger['id'])['pending'],0)

    def test_rejected_application_and_denied_withdraw(self):
        self.refs.apply(self.blogger)
        self.assertEqual(self.refs.approve(self.blogger['id'],False),'rejected')
        self.assertEqual(self.refs.dashboard(self.blogger['id'])['status'],'rejected')
        self.assertIsNone(self.refs.approve(self.blogger['id'],True))
        status,new=self.refs.apply(self.blogger)
        self.assertTrue(new)
        self.assertEqual(status,'pending')

    def test_boost_supported(self):
        code=self.make_partner(self.blogger)
        self.refs.bind(self.buyer['id'],code)
        boost,_=self.store.create_order(self.buyer,{'mode':'wing','fromIndex':0,'toIndex':3,'gameId':'12345678','paymentMethod':'uzcard','requestId':'boost-idempotent-123'})
        self.refs.track_order('boost',boost['id'])
        payment=self.store.payment(order_id=boost['id'])
        self.assertTrue(self.store.decide_manual(payment['id'],True))
        self.assertEqual(self.refs.claim_paid_notice('boost',boost['id']),self.blogger['id'])
        result=self.refs.fulfilled('boost',boost['id'],1000,now=5000)
        self.assertEqual(result['commission'],(boost['amount']-1000)//2)
        self.assertEqual(len(self.refs.release_due(now=5000+86400)),1)


if __name__=='__main__':unittest.main()

"""Validated orders and payment accounting shared by the bot and Mini App API."""
import hashlib
import hmac
import json
import re
import sqlite3
import time
import uuid
import unicodedata
from contextlib import contextmanager
from datetime import datetime, timezone
from urllib.parse import parse_qsl

RANKS = ('Calibration', 'Bronze', 'Silver', 'Gold', 'Phoenix', 'Ranger',
         'Champion', 'Master', 'Elite', 'The Legend')
PRICES = (0, 3000, 4000, 6000, 9000, 13000, 18000, 25000, 35000, 50000)
CALIBRATION_LEGEND_PRICE = 90_000
BOOST_MODE_SURCHARGE = 1_000
MIN_BOOST_PRICE = 12_000
MAX_TOPUP_AMOUNT = 100_000_000
MAX_TOPUP_STARS = 100_000
MODES = {'wing': 'Напарники', 'comp': 'Соревновательный', 'duel': 'Дуэль'}
METHODS = ('humo', 'uzcard', 'terminal', 'stars', 'balance')
TEST_PROVIDERS = ('click', 'payme')
TEST_PAYMENT_UZS = 10_000
ALIASES = {'Калибровка': 'Calibration', 'Kalibrovka': 'Calibration', 'Kalibrlash': 'Calibration', 'Fenix': 'Phoenix', 'Elita': 'Elite'}
PAYMENT_TAGS = {'uzcard':'_uzcard', 'humo':'_humo', 'terminal':'_terminal',
                'balance':'_balance', 'stars':'_stars'}


def player_name(value):
    if not isinstance(value, str):
        raise ValidationError('invalid_game_id')
    value=value.strip()
    if not 1 <= len(value) <= 32 or any(unicodedata.category(c).startswith('C') or c in '<>\u2028\u2029' for c in value):
        raise ValidationError('invalid_game_id')
    return value


def payment_tag(message):
    """Recognize one explicit tag/keyword, never silently choose between methods."""
    lowered=message.casefold()
    tagged=set(re.findall(r'(?<!\w)[_#](uzcard|xumo|humo|terminal)(?!\w)',lowered))
    if len(tagged)==1:
        tag=tagged.pop()
        return 'humo' if tag=='xumo' else tag
    if tagged:
        return None
    matches={method for method,phrase in {'uzcard':'оплачу на узкард','humo':'оплачу на хумо',
            'stars':'оплачу на тг старс','terminal':'оплачу на терминал'}.items() if phrase in lowered}
    return matches.pop() if len(matches)==1 else None


class ValidationError(ValueError):
    pass


def integer(value, low, high):
    if isinstance(value, bool) or not re.fullmatch(r'\d+', str(value)):
        raise ValidationError('invalid_number')
    try:
        value = int(value)
    except ValueError as exc:
        raise ValidationError('invalid_number') from exc
    if not low <= value <= high:
        raise ValidationError('invalid_number')
    return value


def rank_index(data, index_key, name_key):
    if index_key in data:
        return integer(data[index_key], 0, len(RANKS) - 1)
    name = data.get(name_key)
    if not isinstance(name, str):
        raise ValidationError('invalid_rank')
    name = ALIASES.get(name, name)
    if name not in RANKS:
        raise ValidationError('invalid_rank')
    return RANKS.index(name)


def boost_amount(start, end, mode):
    if start == 0 and end == len(RANKS) - 1:
        base = CALIBRATION_LEGEND_PRICE
    else:
        base = sum(PRICES[start + 1:end + 1])
    return max(base, MIN_BOOST_PRICE) + (0 if mode == 'wing' else BOOST_MODE_SURCHARGE)


def validate_order(data):
    if not isinstance(data, dict):
        raise ValidationError('invalid_order')
    start = rank_index(data, 'fromIndex', 'from')
    end = rank_index(data, 'toIndex', 'to')
    game_id = player_name(data.get('gameId', ''))
    mode = data.get('mode')
    if end <= start or not isinstance(mode, str) or mode not in MODES:
        raise ValidationError('invalid_rank')
    method = data.get('paymentMethod', 'terminal')
    if method not in METHODS:
        raise ValidationError('invalid_payment_method')
    return dict(mode=mode, start=start, end=end, game_id=game_id,
                amount=boost_amount(start, end, mode), method=method,
                lang='ru' if data.get('lang') == 'ru' else 'uz')


def validate_init_data(raw, token, now=None):
    """Accept only Telegram-signed, recent initData. Client user fields are untrusted."""
    if not raw or len(raw) > 16000:
        raise ValidationError('unauthorized')
    pairs = parse_qsl(raw, keep_blank_values=True)
    data = dict(pairs)
    if len(data) != len(pairs):
        raise ValidationError('unauthorized')
    received_hash = data.pop('hash', '')
    if not re.fullmatch(r'[0-9a-f]{64}', received_hash):
        raise ValidationError('unauthorized')
    check = '\n'.join(f'{key}={value}' for key, value in sorted(data.items()))
    key = hmac.new(b'WebAppData', token.encode(), hashlib.sha256).digest()
    expected = hmac.new(key, check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, received_hash):
        raise ValidationError('unauthorized')
    now = int(time.time()) if now is None else now
    auth_date = integer(data.get('auth_date', ''), 1, 10**12)
    if now - auth_date > 86400 or auth_date > now + 30:
        raise ValidationError('session_expired')
    try:
        user = json.loads(data.get('user', '{}'))
        if not isinstance(user, dict):
            raise ValidationError('unauthorized')
        user['id'] = integer(user.get('id'), 1, 2**63 - 1)
    except (TypeError, KeyError, json.JSONDecodeError) as exc:
        raise ValidationError('unauthorized') from exc
    return user


def request_key(data):
    key = data.get('requestId') or uuid.uuid4().hex
    if not isinstance(key, str) or not re.fullmatch(r'[a-zA-Z0-9_-]{8,80}', key):
        raise ValidationError('invalid_request')
    return key


class Store:
    def __init__(self, path, stars_rate=0, *, transfer_test=False):
        self.path = str(path)
        self.stars_rate = integer(stars_rate, 0, 1000000)
        self.transfer_test = transfer_test
        self.init_db()

    @contextmanager
    def connect(self):
        con = sqlite3.connect(self.path, timeout=15)
        con.row_factory = sqlite3.Row
        try:
            con.execute('BEGIN IMMEDIATE')
            yield con
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()

    def init_db(self):
        with self.connect() as con:
            con.execute('''CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, username TEXT,
                access_type TEXT, mode TEXT, current_rank INTEGER, target_rank INTEGER,
                amount INTEGER, card TEXT, receipt_file_id TEXT, receipt_type TEXT,
                status TEXT DEFAULT 'pending', created_at TEXT)''')
            columns = {row['name'] for row in con.execute('PRAGMA table_info(orders)')}
            for name, definition in {'game_id': "TEXT DEFAULT ''", 'request_key': 'TEXT',
                                     'lang': "TEXT DEFAULT 'uz'", 'eta_min_hours': 'INTEGER',
                                     'eta_max_hours': 'INTEGER'}.items():
                if name not in columns:
                    con.execute(f'ALTER TABLE orders ADD COLUMN {name} {definition}')
            con.execute('CREATE UNIQUE INDEX IF NOT EXISTS order_requests ON orders(user_id, request_key)')
            con.execute('''CREATE TABLE IF NOT EXISTS boost_schedule (
                id INTEGER PRIMARY KEY CHECK(id=1), min_hours INTEGER NOT NULL, max_hours INTEGER NOT NULL)''')
            con.execute('''CREATE TABLE IF NOT EXISTS accounts (
                user_id INTEGER PRIMARY KEY, balance INTEGER NOT NULL DEFAULT 0 CHECK(balance >= 0))''')
            account_columns={row['name'] for row in con.execute('PRAGMA table_info(accounts)')}
            for name,definition in {'game_id':"TEXT DEFAULT ''",'lang':"TEXT DEFAULT 'uz'"}.items():
                if name not in account_columns:
                    con.execute(f'ALTER TABLE accounts ADD COLUMN {name} {definition}')
            con.execute('''CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
                order_id INTEGER, kind TEXT NOT NULL, method TEXT NOT NULL,
                amount INTEGER NOT NULL, stars INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'pending', request_key TEXT NOT NULL,
                telegram_charge_id TEXT UNIQUE, created_at TEXT NOT NULL,
                receipt_file_id TEXT, receipt_type TEXT,
                UNIQUE(user_id, request_key))''')
            payment_columns = {row['name'] for row in con.execute('PRAGMA table_info(payments)')}
            for column, definition in {'donat_order_id':'INTEGER', 'checkout_query_id':'TEXT',
                                       'checkout_reserved_at':'INTEGER',
                                       'receipt_unique_id':'TEXT',
                                       'admin_notice_pending':'INTEGER NOT NULL DEFAULT 0'}.items():
                if column not in payment_columns:
                    con.execute(f'ALTER TABLE payments ADD COLUMN {column} {definition}')
            con.execute('CREATE UNIQUE INDEX IF NOT EXISTS donat_payment ON payments(donat_order_id)')
            con.execute('CREATE UNIQUE INDEX IF NOT EXISTS unique_payment_receipt ON payments(receipt_unique_id)')
            if 'stars_balance' not in account_columns:
                con.execute('ALTER TABLE accounts ADD COLUMN stars_balance INTEGER NOT NULL DEFAULT 0')
                # Preserve recorded Stars credit without counting legacy card/admin credit as Stars.
                con.execute('''UPDATE accounts SET stars_balance=MAX(0, MIN(balance, COALESCE((
                    SELECT SUM(CASE
                        WHEN kind='topup' AND method='stars' AND telegram_charge_id IS NOT NULL THEN amount
                        WHEN kind IN ('order','donat') AND method='balance' THEN -amount
                        ELSE 0 END)
                    FROM payments WHERE user_id=accounts.user_id AND status='paid'), 0)))''')
            con.execute('''CREATE TABLE IF NOT EXISTS order_help_requests (
                id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, username TEXT NOT NULL,
                request_key TEXT NOT NULL, kind TEXT NOT NULL, details TEXT NOT NULL,
                notified INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, UNIQUE(user_id, request_key))''')
            con.execute('''CREATE TABLE IF NOT EXISTS admin_credits (
                request_key TEXT PRIMARY KEY, user_id INTEGER NOT NULL, amount INTEGER NOT NULL)''')
            con.execute('''CREATE TABLE IF NOT EXISTS business_replies (
                connection_id TEXT,chat_id INTEGER,message_id INTEGER,
                PRIMARY KEY(connection_id,chat_id,message_id))''')
            con.execute('''CREATE TABLE IF NOT EXISTS donat_orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL, username TEXT NOT NULL DEFAULT '',
                product TEXT NOT NULL, option_code TEXT NOT NULL,
                option_label TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '',
                amount INTEGER NOT NULL CHECK(amount > 0),
                method TEXT NOT NULL, lang TEXT NOT NULL DEFAULT 'uz',
                status TEXT NOT NULL DEFAULT 'pending',
                request_key TEXT NOT NULL, receipt_file_id TEXT,
                receipt_type TEXT, created_at TEXT NOT NULL,
                UNIQUE(user_id, request_key))''')

    @property
    def max_topup_stars(self):
        if not self.stars_rate:
            return 0
        return min(MAX_TOPUP_STARS, MAX_TOPUP_AMOUNT // self.stars_rate)

    def debit_wallet(self, con, user_id, amount):
        if self.transfer_test:
            updated = con.execute('''UPDATE accounts SET balance=balance-?,
                stars_balance=MAX(0,stars_balance-?) WHERE user_id=? AND balance>=?''',
                (amount, amount, user_id, amount)).rowcount
            if not updated:
                raise ValidationError('insufficient_balance')
            return
        updated = con.execute('''UPDATE accounts SET balance=balance-?, stars_balance=stars_balance-?
            WHERE user_id=? AND stars_balance>=? AND balance>=?''',
            (amount, amount, user_id, amount, amount)).rowcount
        if not updated:
            raise ValidationError('insufficient_balance')

    @staticmethod
    def now():
        return datetime.now(timezone.utc).isoformat()

    def set_boost_eta(self, low=None, high=None):
        if low is not None:
            low = integer(low, 1, 720)
            high = integer(high, low, 720)
        with self.connect() as con:
            if low is None:
                con.execute('DELETE FROM boost_schedule WHERE id=1')
            else:
                con.execute("""INSERT INTO boost_schedule VALUES (1, ?, ?)
                    ON CONFLICT(id) DO UPDATE SET min_hours=excluded.min_hours, max_hours=excluded.max_hours""",
                    (low, high))

    @staticmethod
    def _boost_eta(con):
        row = con.execute('SELECT min_hours,max_hours FROM boost_schedule WHERE id=1').fetchone()
        return tuple(row) if row else (None, None)

    def boost_eta(self):
        with self.connect() as con:
            return self._boost_eta(con)

    def start_boost(self, order_id):
        order_id = integer(order_id, 1, 2**63 - 1)
        with self.connect() as con:
            if not con.execute("UPDATE orders SET status='in_progress' WHERE id=? AND status='paid'",
                               (order_id,)).rowcount:
                return None
            return dict(con.execute('SELECT id,user_id,lang FROM orders WHERE id=?',(order_id,)).fetchone())

    def create_order(self, user, data):
        order = validate_order(data)
        key = request_key(data)
        with self.connect() as con:
            existing = con.execute('SELECT * FROM orders WHERE user_id=? AND request_key=?',
                                   (user['id'], key)).fetchone()
            if existing:
                values = (existing['mode'], existing['current_rank'], existing['target_rank'],
                          existing['game_id'], existing['card'])
                if values != (order['mode'], order['start'], order['end'], order['game_id'], order['method']):
                    raise ValidationError('request_conflict')
                return dict(existing), False
            if order['method'] == 'stars':
                raise ValidationError('invalid_payment_method')
            status = 'paid' if order['method'] == 'balance' else 'pending'
            if 'expectedAmount' in data and data['expectedAmount'] != order['amount']:
                raise ValidationError('order_quote_changed')
            if order['method'] == 'balance':
                self.debit_wallet(con, user['id'], order['amount'])
            eta_min, eta_max = self._boost_eta(con)
            row = con.execute('''INSERT INTO orders (user_id, username, access_type, mode,
                current_rank, target_rank, game_id, amount, card, status, created_at, request_key, lang, eta_min_hours, eta_max_hours)
                VALUES (?, ?, 'yes', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (user['id'], user.get('username', ''), order['mode'], order['start'], order['end'],
                 order['game_id'], order['amount'], order['method'], status, self.now(), key, order['lang'], eta_min, eta_max))
            order_id = row.lastrowid
            con.execute('''INSERT INTO accounts(user_id,game_id,lang) VALUES (?,?,?)
                ON CONFLICT(user_id) DO UPDATE SET game_id=excluded.game_id,lang=excluded.lang''',
                (user['id'],order['game_id'],order['lang']))
            con.execute('''INSERT INTO payments (user_id, order_id, kind, method, amount,
                status, admin_notice_pending, request_key, created_at) VALUES (?, ?, 'order', ?, ?, ?, ?, ?, ?)''',
                (user['id'], order_id, order['method'], order['amount'], status, int(status == 'paid'), key, self.now()))
            return dict(con.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()), True

    def create_topup(self, user, data):
        if not isinstance(data, dict):
            raise ValidationError('invalid_request')
        method = data.get('paymentMethod')
        if method not in METHODS[:-1]:
            raise ValidationError('invalid_payment_method')
        if method == 'stars':
            stars = integer(data.get('stars'), 1, MAX_TOPUP_STARS)
            rate = integer(data.get('starsRate'), 1, 1_000_000)
            amount = integer(stars * rate, 1, MAX_TOPUP_AMOUNT)
        else:
            stars = 0
            amount = integer(data.get('amount'), 1, MAX_TOPUP_AMOUNT)
        key = request_key(data)
        with self.connect() as con:
            existing = con.execute('SELECT * FROM payments WHERE user_id=? AND request_key=?',
                                   (user['id'], key)).fetchone()
            if existing:
                if (existing['kind'], existing['method'], existing['amount'], existing['stars']) != ('topup', method, amount, stars):
                    raise ValidationError('request_conflict')
                return dict(existing), False
            if method == 'stars' and not self.stars_rate:
                raise ValidationError('stars_not_configured')
            if method == 'stars' and rate != self.stars_rate:
                raise ValidationError('stars_quote_changed')
            row = con.execute('''INSERT INTO payments (user_id, kind, method, amount,
                stars, request_key, created_at) VALUES (?, 'topup', ?, ?, ?, ?, ?)''',
                (user['id'], method, amount, stars, key, self.now()))
            return dict(con.execute('SELECT * FROM payments WHERE id=?', (row.lastrowid,)).fetchone()), True

    def provider_test(self, user_id, method, key, create=False):
        if method not in TEST_PROVIDERS:
            raise ValidationError('invalid_payment_method')
        key = request_key({'requestId': key})
        with self.connect() as con:
            row = con.execute('SELECT * FROM payments WHERE user_id=? AND request_key=?',
                              (user_id, key)).fetchone()
            if row:
                if (row['kind'], row['method']) != ('provider_test', method):
                    raise ValidationError('request_conflict')
                return dict(row)
            if not create:
                raise ValidationError('payment_not_found')
            row_id = con.execute('''INSERT INTO payments (user_id, kind, method, amount, request_key, created_at)
                VALUES (?, 'provider_test', ?, ?, ?, ?)''',
                (user_id, method, TEST_PAYMENT_UZS, key, self.now())).lastrowid
            return dict(con.execute('SELECT * FROM payments WHERE id=?', (row_id,)).fetchone())

    def payment(self, payment_id=None, order_id=None, donat_order_id=None):
        with self.connect() as con:
            if payment_id is not None:
                row = con.execute('SELECT * FROM payments WHERE id=?', (payment_id,)).fetchone()
            elif donat_order_id is not None:
                row = con.execute('SELECT * FROM payments WHERE donat_order_id=?', (donat_order_id,)).fetchone()
            else:
                row = con.execute('SELECT * FROM payments WHERE order_id=?', (order_id,)).fetchone()
            if not row:
                raise ValidationError('payment_not_found')
            return dict(row)

    def pending_admin_notices(self):
        with self.connect() as con:
            return [row['id'] for row in con.execute('SELECT id FROM payments WHERE admin_notice_pending=1 ORDER BY id LIMIT 50')]

    def mark_admin_notified(self, payment_id):
        with self.connect() as con:
            con.execute('UPDATE payments SET admin_notice_pending=0 WHERE id=?', (payment_id,))

    def check_stars(self, payment_id, user_id, currency, total, query_id):
        return self.check_telegram_payment(payment_id, user_id, currency, total, query_id, 'stars')

    @staticmethod
    def verify_telegram_payment(payment, user_id, currency, total, method):
        if not payment or payment['user_id'] != user_id or payment['method'] != method:
            raise ValidationError('invalid_payment')
        if method == 'stars':
            valid = currency == 'XTR' and total == payment['stars']
        else:
            valid = (method in TEST_PROVIDERS and payment['kind'] == 'provider_test'
                     and currency == 'UZS' and total == payment['amount'] * 100)
        if not valid:
            raise ValidationError('invalid_payment')

    def check_telegram_payment(self, payment_id, user_id, currency, total, query_id, method):
        now = int(time.time())
        with self.connect() as con:
            payment = con.execute('SELECT * FROM payments WHERE id=?',(payment_id,)).fetchone()
            self.verify_telegram_payment(payment, user_id, currency, total, method)
            if payment['status'] != 'pending':
                raise ValidationError('invalid_payment')
            if (payment['checkout_query_id'] not in (None, query_id)
                    and now - payment['checkout_reserved_at'] < 180):
                raise ValidationError('payment_in_progress')
            con.execute('UPDATE payments SET checkout_query_id=?,checkout_reserved_at=? WHERE id=?',
                        (query_id,now,payment_id))
            return dict(payment)

    @staticmethod
    def apply_paid(con, payment):
        if payment['kind'] == 'provider_test':
            return
        if payment['kind'] == 'topup':
            stars_balance = payment['amount'] if payment['method'] == 'stars' else 0
            con.execute('''INSERT INTO accounts(user_id, balance, stars_balance) VALUES (?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET balance=balance+excluded.balance,
                    stars_balance=stars_balance+excluded.stars_balance''',
                (payment['user_id'], payment['amount'], stars_balance))
        else:
            is_donat = payment['kind'] == 'donat'
            table = 'donat_orders' if is_donat else 'orders'
            order_id = payment['donat_order_id'] if is_donat else payment['order_id']
            if not con.execute(f"UPDATE {table} SET status='paid' WHERE id=? AND status='pending'",
                               (order_id,)).rowcount:
                raise ValidationError('invalid_payment')

    def settle_stars(self, payment_id, user_id, currency, total, charge_id):
        return self.settle_telegram_payment(payment_id, user_id, currency, total, charge_id, 'stars')

    def settle_telegram_payment(self, payment_id, user_id, currency, total, charge_id, method):
        if not isinstance(charge_id, str) or not charge_id:
            raise ValidationError('invalid_payment')
        with self.connect() as con:
            payment = con.execute('SELECT * FROM payments WHERE id=?', (payment_id,)).fetchone()
            self.verify_telegram_payment(payment, user_id, currency, total, method)
            if payment['status'] == 'paid':
                if payment['telegram_charge_id'] != charge_id:
                    raise ValidationError('duplicate_payment')
                return False
            if payment['status'] != 'pending':
                raise ValidationError('invalid_payment')
            duplicate = con.execute('SELECT id FROM payments WHERE telegram_charge_id=?', (charge_id,)).fetchone()
            if duplicate:
                raise ValidationError('duplicate_payment')
            con.execute("UPDATE payments SET status='paid', telegram_charge_id=? WHERE id=?", (charge_id, payment_id))
            self.apply_paid(con, payment)
            return True

    def decide_manual(self, payment_id, approve):
        with self.connect() as con:
            payment = con.execute('SELECT * FROM payments WHERE id=?', (payment_id,)).fetchone()
            if not payment or payment['method'] not in ('humo', 'uzcard', 'terminal'):
                raise ValidationError('invalid_payment')
            if payment['status'] != 'pending':
                return False
            if self.transfer_test and not payment['receipt_file_id']:
                raise ValidationError('receipt_required')
            con.execute('UPDATE payments SET status=?, admin_notice_pending=0 WHERE id=?',
                        ('paid' if approve else 'rejected', payment_id))
            if self.transfer_test and payment['kind'] in ('order', 'donat'):
                table = 'orders' if payment['kind'] == 'order' else 'donat_orders'
                order_id = payment['order_id'] or payment['donat_order_id']
                if not con.execute(f"UPDATE {table} SET status=? WHERE id=? AND status IN ('pending','review')",
                                   ('in_progress' if approve else 'rejected', order_id)).rowcount:
                    raise ValidationError('invalid_payment')
                return True
            if approve:
                self.apply_paid(con, payment)
            elif payment['order_id']:
                con.execute("UPDATE orders SET status='rejected' WHERE id=?", (payment['order_id'],))
            return True

    def attach_receipt(self, payment_id, user_id, file_id, file_type, unique_id=None):
        if not file_id or file_type not in ('photo', 'document'):
            raise ValidationError('invalid_receipt')
        with self.connect() as con:
            payment = con.execute("""SELECT * FROM payments WHERE id=? AND user_id=?
                AND status='pending' AND method IN ('humo','uzcard','terminal')""",
                (payment_id, user_id)).fetchone()
            if not payment:
                return False
            if payment['receipt_file_id']:
                return (payment['receipt_file_id'] == file_id
                        or bool(unique_id and payment['receipt_unique_id'] == unique_id))
            if unique_id and con.execute('SELECT 1 FROM payments WHERE receipt_unique_id=?',
                                         (unique_id,)).fetchone():
                raise ValidationError('receipt_used')
            con.execute('''UPDATE payments SET receipt_file_id=?, receipt_type=?, receipt_unique_id=?,
                admin_notice_pending=1 WHERE id=?''', (file_id, file_type, unique_id, payment_id))
            if self.transfer_test and payment['kind'] in ('order', 'donat'):
                table = 'orders' if payment['kind'] == 'order' else 'donat_orders'
                order_id = payment['order_id'] or payment['donat_order_id']
                if not con.execute(f"UPDATE {table} SET status='review' WHERE id=? AND status='pending'",
                                   (order_id,)).rowcount:
                    raise ValidationError('invalid_payment')
            return True

    def credit(self, user_id, amount, key):
        user_id = integer(user_id, 1, 2**63 - 1)
        amount = integer(amount, 1, 100000000)
        with self.connect() as con:
            if not con.execute('INSERT OR IGNORE INTO admin_credits VALUES (?, ?, ?)', (key, user_id, amount)).rowcount:
                return False
            con.execute('''INSERT INTO accounts(user_id,balance) VALUES (?, ?)
                ON CONFLICT(user_id) DO UPDATE SET balance=balance+excluded.balance''', (user_id, amount))
            return True

    def profile(self,user_id,game_id=None,lang=None):
        if game_id is not None:
            game_id=player_name(game_id)
        if lang is not None and lang not in ('uz','ru'):
            raise ValidationError('invalid_language')
        with self.connect() as con:
            con.execute('INSERT OR IGNORE INTO accounts(user_id) VALUES (?)',(user_id,))
            if game_id is not None:
                con.execute('UPDATE accounts SET game_id=? WHERE user_id=?',(game_id,user_id))
            if lang is not None:
                con.execute('UPDATE accounts SET lang=? WHERE user_id=?',(lang,user_id))
            return dict(con.execute('SELECT * FROM accounts WHERE user_id=?',(user_id,)).fetchone())

    def state(self, user_id):
        with self.connect() as con:
            account = con.execute('SELECT balance,stars_balance,game_id,lang FROM accounts WHERE user_id=?', (user_id,)).fetchone()
            orders = [dict(r) for r in con.execute('''SELECT id, mode, current_rank, target_rank,
                game_id, amount, card, status, created_at, eta_min_hours, eta_max_hours FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 100''', (user_id,))]
            payments = [dict(r) for r in con.execute('''SELECT id, order_id, donat_order_id, kind, method, amount,
                stars, CASE WHEN status='pending' AND receipt_file_id IS NOT NULL THEN 'review'
                            ELSE status END AS status, created_at
                FROM payments WHERE user_id=? AND kind<>'provider_test'
                ORDER BY id DESC LIMIT 100''', (user_id,))]
        return {'balance': account['balance'] if account else 0, 'starsBalance': account['stars_balance'] if account else 0,
                'gameId': account['game_id'] if account else '',
                'lang':account['lang'] if account else 'uz','orders': orders, 'payments': payments}

    def create_donat_order(self, user, data):
        from donat_catalog import normalize_order
        info = normalize_order(data)
        key = request_key(data)
        with self.connect() as con:
            existing = con.execute('SELECT * FROM donat_orders WHERE user_id=? AND request_key=?',
                                   (user['id'], key)).fetchone()
            if existing:
                fields = ('product','option_code','detail','amount','method')
                incoming = (info['product'], info['option'], info['detail'], info['amount'], info['method'])
                if tuple(existing[k] for k in fields) != incoming:
                    raise ValidationError('request_conflict')
                return dict(existing), False
            if info['method'] == 'stars':
                raise ValidationError('invalid_payment_method')
            status = 'paid' if info['method'] == 'balance' else 'pending'
            if 'expectedAmount' in data and data['expectedAmount'] != info['amount']:
                raise ValidationError('order_quote_changed')
            if info['method'] == 'balance':
                self.debit_wallet(con, user['id'], info['amount'])
            cursor = con.execute('''INSERT INTO donat_orders
                (user_id,username,product,option_code,option_label,detail,amount,method,lang,status,request_key,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''',
                (user['id'],user.get('username',''),info['product'],info['option'],info['label'],
                 info['detail'],info['amount'],info['method'],info['lang'],status,key,self.now()))
            order_id = cursor.lastrowid
            if status == 'paid' or (self.transfer_test and info['method'] == 'uzcard'):
                con.execute('''INSERT INTO payments (user_id, donat_order_id, kind, method, amount, status,
                    admin_notice_pending, request_key, created_at)
                    VALUES (?, ?, 'donat', ?, ?, ?, ?, ?, ?)''',
                    (user['id'], order_id, info['method'], info['amount'], status,
                     int(status == 'paid'), f'donat:{order_id}', self.now()))
            row = con.execute('SELECT * FROM donat_orders WHERE id=?',(order_id,)).fetchone()
            return dict(row), True

    def donat_order(self, order_id, user_id=None):
        order_id=integer(order_id,1,2**63-1)
        with self.connect() as con:
            row=con.execute('SELECT * FROM donat_orders WHERE id=?',(order_id,)).fetchone()
            if not row or (user_id is not None and row['user_id']!=user_id):
                raise ValidationError('order_not_found')
            return dict(row)

    def donat_state(self, user_id):
        with self.connect() as con:
            return [dict(row) for row in con.execute('''SELECT id,product,option_label,detail,amount,method,
                status,created_at FROM donat_orders WHERE user_id=? ORDER BY id DESC LIMIT 100''',(user_id,))]

    def attach_donat_receipt(self, order_id, user_id, file_id, file_type):
        if file_type not in ('photo','document') or not file_id:
            raise ValidationError('invalid_receipt')
        with self.connect() as con:
            changed=con.execute('''UPDATE donat_orders SET receipt_file_id=?,receipt_type=?,status='review'
                WHERE id=? AND user_id=? AND method<>'stars' AND status IN ('pending','review')
                AND NOT EXISTS (SELECT 1 FROM payments WHERE donat_order_id=donat_orders.id)''',
                (file_id,file_type,order_id,user_id)).rowcount
            return bool(changed)

    def decide_donat(self, order_id, approve):
        with self.connect() as con:
            row=con.execute('SELECT * FROM donat_orders WHERE id=?',(order_id,)).fetchone()
            if not row:
                raise ValidationError('order_not_found')
            if row['method']=='stars' or row['status'] not in ('pending','review'):
                return False
            if con.execute('SELECT 1 FROM payments WHERE donat_order_id=?', (order_id,)).fetchone():
                return False
            con.execute('UPDATE donat_orders SET status=? WHERE id=?',
                        ('paid' if approve else 'rejected',order_id))
            return True

    def save_order_help(self, user, data):
        if not isinstance(data, dict) or data.get('kind') not in ('boost', 'donat'):
            raise ValidationError('invalid_request')
        kind = data['kind']
        reason = data.get('reason')
        if reason not in (None, 'atm'):
            raise ValidationError('invalid_request')
        values = {**data, 'paymentMethod':'balance'}
        if kind == 'boost':
            details = validate_order(values)
        else:
            from donat_catalog import normalize_order
            details = normalize_order(values)
        details.pop('method', None)
        details.pop('lang', None)
        if reason:
            details['reason'] = reason
        payload = json.dumps(details, ensure_ascii=False, sort_keys=True)
        key = request_key(data)
        with self.connect() as con:
            con.execute('''INSERT OR IGNORE INTO order_help_requests
                (user_id,username,request_key,kind,details,created_at) VALUES (?,?,?,?,?,?)''',
                (user['id'],user.get('username',''),key,kind,payload,self.now()))
            row = con.execute('SELECT * FROM order_help_requests WHERE user_id=? AND request_key=?',
                              (user['id'],key)).fetchone()
            if (row['kind'],row['details']) != (kind,payload):
                raise ValidationError('request_conflict')
            return dict(row)

    def mark_order_help_sent(self, request_id):
        with self.connect() as con:
            con.execute('UPDATE order_help_requests SET notified=1 WHERE id=?',(request_id,))

    def claim_business_reply(self,connection_id,chat_id,message_id):
        with self.connect() as con:
            return bool(con.execute('INSERT OR IGNORE INTO business_replies VALUES (?,?,?)',
                (connection_id,chat_id,message_id)).rowcount)

    def release_business_reply(self,connection_id,chat_id,message_id):
        with self.connect() as con:
            con.execute('DELETE FROM business_replies WHERE connection_id=? AND chat_id=? AND message_id=?',
                        (connection_id,chat_id,message_id))

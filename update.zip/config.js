// Public configuration. No passwords or bot tokens belong here.
// Edit this file for future price/contact changes; upload the same update.zip.
window.ARSLAN_CONFIG = {
  version: '2026-11-09.boost-offers',
  supportUrl: 'https://t.me/khblyv',
  botUrl: 'https://t.me/arslanboostbot',
  // Public HTTPS URL of the running bot API, if hosted separately. GitHub Pages alone cannot run it.
  apiBaseUrl: '',
  paymentAdminUrl: 'https://t.me/khblyv',
  // Entry costs: Bronze, Silver, Gold, Phoenix, Ranger, Champion, Master, Elite, Legend.
  prices: [0, 3000, 4000, 6000, 9000, 13000, 18000, 25000, 35000, 50000],
  calibrationLegendPrice: 90000,
  boostModeSurcharge: 1000,
  minBoostPrice: 12000,
  paymentTags: {uzcard:'_uzcard', humo:'_humo', terminal:'_terminal'},
  introDuration: 900,
  banners: {uz:'assets/hero-banner-hd.png', ru:'assets/hero-banner-ru.png'},
};

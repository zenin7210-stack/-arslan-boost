'use strict';
(() => {
  const tg = window.Telegram?.WebApp;
  try { tg?.ready(); tg?.expand(); tg?.setHeaderColor?.('#06101e'); tg?.setBackgroundColor?.('#06101e'); } catch {}
  const $ = s => document.querySelector(s);
  const all = s => [...document.querySelectorAll(s)];
  const storage = {get(k) { try { return localStorage.getItem(k); } catch { return null; } }, set(k,v) { try { localStorage.setItem(k,v); } catch {} }};
  const config = {...window.ARSLAN_CONFIG};
  const ranks = ['Calibration','Bronze','Silver','Gold','Phoenix','Ranger','Champion','Master','Elite','The Legend'];
  let prices = [...(config.prices || [0,3000,4000,6000,9000,13000,18000,25000,35000,50000])];
  let calibrationLegendPrice = config.calibrationLegendPrice ?? 90000;
  let boostModeSurcharge = config.boostModeSurcharge ?? 1000;
  let minBoostPrice = config.minBoostPrice ?? 12000;
  let boostEta = [];
  const rankCenters = [null,[214,174],[380,174],[546,174],[723,174],[723,317],[723,460],[905,174],[905,317],[1095,174]];
  const dictionaries = {
    ru: {
      miniApp:'мини-приложение',balance:'Баланс',promo:'Промокод',support:'Поддержка',chooseMode:'Выберите режим',
      currentRank:'Текущий ранг',targetRank:'Желаемый ранг',gameId:'Игровой ID или ник',orderPrice:'Стоимость заказа',order:'Заказать',
      history:'История',orders:'Заказы',payments:'Платежи',all:'Все',completed:'Оплачено',pending:'Ожидают',cancelled:'Отклонено',
      emptyHistory:'Пока нет операций',appUser:'Пользователь Mini App',balanceCaption:'БАЛАНС',cashback:'КЕШБЭК',settings:'Настройки',language:'ЯЗЫК',settingsCaption:'НАСТРОЙКИ',
      profile:'Данные профиля',profileDesc:'Ваш профиль и личные данные',orderHistory:'История заказов',historyDesc:'Все заказы и их статусы',
      promoCodes:'Промокоды',promoDesc:'Промокоды и бонусы',supportDesc:'Помощь с заказами и оплатой',animations:'Анимации',motionDesc:'Уменьшить анимации приложения',
      security:'Безопасность',securityDesc:'Не отправляйте пароль от аккаунта боту',about:'О приложении',aboutDesc:'Arslan Boost · повышение ранга Standoff 2',home:'Главная',skip:'Пропустить',
      priceNote:'Способ оплаты выбирается при заказе.',boostMinimum:'Минимальный заказ — {price}',
      selectedMode:'Выбранный режим',wing:'Напарники',comp:'Сорев',duel:'Дуэль',calibration:'Калибровка',currency:'сум',steps:'ступеней',idPlaceholder:'Например: 12345678 или Player',
      invalidId:'Введите игровой ID или ник',choosePayment:'Способ оплаты',topup:'Пополнить баланс',topupAmount:'Сумма пополнения, сум',amountPlaceholder:'Например: 30000',
      invalidAmount:'Введите сумму пополнения от 1 до 100 000 000 сум',method_humo:'HUMO',method_uzcard:'UZCARD',method_terminal:'Банкомат / терминал',method_stars:'Telegram Stars',method_balance:'С баланса',
      manualHint:'Заявка администратору с расчётом суммы',starsHint:'Счёт в Telegram Stars',balanceHint:'Доступно: {amount}',notEnough:'На балансе недостаточно средств',
      admin:'Перейти к администратору',copy:'Скопировать сообщение',copied:'Сообщение скопировано',copyHint:'Выделите и скопируйте сообщение ниже',back:'К способам оплаты',close:'Закрыть',
      payment:'Оплата',total:'Итого',calculation:'Расчёт',paymentMethod:'Способ оплаты',topupRequest:'Заявка на пополнение баланса',orderRequest:'Заявка на буст Standoff 2',
      adminMissing:'Администратор пока не подключён. Сообщение с расчётом можно скопировать.',botMissing:'Бот для оплаты Stars пока не подключён.',
      starsNotConfigured:'Стоимость в Stars ещё не задана владельцем.',openBot:'Открыть счёт в боте',payStars:'Оплатить {stars} ⭐',confirming:'Проверяем подтверждение платежа…',paid:'Оплата подтверждена',
      invoiceClosed:'Оплата не завершена',pendingStatus:'Ожидает оплаты',paidStatus:'Оплачено',rejectedStatus:'Отклонено',unknownStatus:'На проверке',orderNumber:'Заказ',paymentNumber:'Платёж',
      processing:'Подождите…',submitted:'Заявка сохранена',connectionError:'Не удалось связаться с ботом. Попробуйте ещё раз.',sessionExpired:'Откройте Mini App заново через Telegram',
      profileText:'Профиль загружается из Telegram.',securityText:'Не вводите пароль от игры и SMS-коды в Mini App. Детали буста согласуйте с администратором.',
      aboutText:'Arslan Boost — буст Standoff 2 и магазин игровой валюты.',promoText:'Введите промокод, чтобы уточнить условия у администратора.',promoPlaceholder:'Промокод',promoAction:'Уточнить промокод',
      supportText:'Вопросы по заказу, балансу и оплате можно отправить администратору.',noAutoCredit:'Пополнение появится на балансе после подтверждения оплаты.',
      orderSent:'Оплаченный заказ передан администратору.',paymentConfirmedText:'Оплата подтверждена сервером.',selectRank:'Выберите ранг',userId:'Telegram ID',receiptText:'Хочу оформить заказ. Подскажите реквизиты и условия оплаты.',
      topupText:'Хочу пополнить баланс. Подскажите реквизиты и условия оплаты.',requestId:'Заявка',draftHint:'Текст откроется в чате администратора. Отправьте его, чтобы оформить заявку.'
    },
    uz: {
      miniApp:'mini-ilova',balance:'Balans',promo:'Promo kod',support:'Texnik yordam',chooseMode:'Rejimni tanlang',currentRank:'Hozirgi rankingiz',targetRank:'Maqsad rank',gameId:'O‘yin ID yoki nick',
      orderPrice:'Buyurtma narxi',order:'Buyurtma berish',history:'Tarix',orders:'Buyurtmalar',payments:'To‘lovlar',all:'Barchasi',completed:'To‘langan',pending:'Kutilmoqda',cancelled:'Rad etilgan',
      emptyHistory:'Hozircha operatsiyalar yo‘q',appUser:'Mini App foydalanuvchisi',balanceCaption:'BALANS',cashback:'KESHBEK',settings:'Sozlamalar',language:'TIL',settingsCaption:'SOZLAMALAR',
      profile:'Profil ma’lumotlari',profileDesc:'Profilingiz va shaxsiy ma’lumotlar',orderHistory:'Buyurtmalar tarixi',historyDesc:'Barcha buyurtmalar va ularning holati',promoCodes:'Promo kodlar',
      promoDesc:'Promo kodlar va bonuslar',supportDesc:'Buyurtma va to‘lov bo‘yicha yordam',animations:'Animatsiyalar',motionDesc:'Ilova animatsiyalarini kamaytirish',security:'Xavfsizlik',
      securityDesc:'Akkaunt parolini botga yubormang',about:'Ilova haqida',aboutDesc:'Arslan Boost · Standoff 2 rank boost',home:'Bosh sahifa',skip:'O‘tkazish',
      priceNote:'To‘lov usulini buyurtma paytida tanlang.',boostMinimum:'Eng kam buyurtma — {price}',
      selectedMode:'Tanlangan rejim',wing:'Naparnik',comp:'Сорев',duel:'Duel',calibration:'Kalibrovka',currency:'so‘m',steps:'ta bosqich',idPlaceholder:'Masalan: 12345678 yoki Player',
      invalidId:'O‘yin ID yoki nickni kiriting',choosePayment:'To‘lov usuli',topup:'Balansni to‘ldirish',topupAmount:'To‘ldirish summasi, so‘m',amountPlaceholder:'Masalan: 30000',
      invalidAmount:'1 dan 100 000 000 so‘mgacha summa kiriting',method_humo:'HUMO',method_uzcard:'UZCARD',method_terminal:'Bankomat / terminal',method_stars:'Telegram Stars',method_balance:'Balansdan',
      manualHint:'Administratorga summa hisobi bilan murojaat',starsHint:'Telegram Stars orqali hisob',balanceHint:'Mavjud: {amount}',notEnough:'Balansda mablag‘ yetarli emas',
      admin:'Administratorga o‘tish',copy:'Xabarni nusxalash',copied:'Xabar nusxalandi',copyHint:'Quyidagi xabarni belgilang va nusxalang',back:'To‘lov usullariga',close:'Yopish',
      payment:'To‘lov',total:'Jami',calculation:'Hisob',paymentMethod:'To‘lov usuli',topupRequest:'Balansni to‘ldirish uchun ariza',orderRequest:'Standoff 2 boost buyurtmasi',
      adminMissing:'Administrator hali ulanmagan. Hisoblangan xabarni nusxalashingiz mumkin.',botMissing:'Stars uchun to‘lov boti hali ulanmagan.',starsNotConfigured:'Stars narxi hali belgilanmagan.',
      openBot:'Hisobni botda ochish',payStars:'{stars} ⭐ to‘lash',confirming:'To‘lov tasdig‘i tekshirilmoqda…',paid:'To‘lov tasdiqlandi',invoiceClosed:'To‘lov yakunlanmadi',
      pendingStatus:'To‘lov kutilmoqda',paidStatus:'To‘langan',rejectedStatus:'Rad etilgan',unknownStatus:'Tekshirilmoqda',orderNumber:'Buyurtma',paymentNumber:'To‘lov',processing:'Kuting…',submitted:'Ariza saqlandi',
      connectionError:'Botga ulanish amalga oshmadi. Qayta urinib ko‘ring.',sessionExpired:'Mini App’ni Telegram orqali qayta oching',profileText:'Profil Telegram orqali yuklanadi.',
      securityText:'O‘yin paroli va SMS-kodlarni Mini App’ga kiritmang. Boost tafsilotlarini administrator bilan kelishing.',aboutText:'Arslan Boost — Standoff 2 rank oshirish va o‘yin valyutalari do‘koni.',
      promoText:'Shartlarni administratordan bilish uchun promo kodni kiriting.',promoPlaceholder:'Promo kod',promoAction:'Promo kodni tekshirish',supportText:'Buyurtma, balans va to‘lov bo‘yicha administratorga yozing.',
      noAutoCredit:'Mablag‘ to‘lov tasdiqlanganidan keyin balansda ko‘rinadi.',orderSent:'To‘langan buyurtma administratorga yuborildi.',paymentConfirmedText:'To‘lov server orqali tasdiqlandi.',
      selectRank:'Rankni tanlang',userId:'Telegram ID',receiptText:'Buyurtma bermoqchiman. Rekvizit va to‘lov shartlarini yuboring.',topupText:'Balansni to‘ldirmoqchiman. Rekvizit va to‘lov shartlarini yuboring.',requestId:'Ariza',
      draftHint:'Xabar administrator chatida ochiladi. Arizani rasmiylashtirish uchun uni yuboring.'
    }
  };
  Object.assign(dictionaries.ru,{pay_uzcard:'✅ Оплачу на UZCARD',pay_humo:'✅ Оплачу на HUMO',pay_terminal:'✅ Оплачу через терминал',pay_stars:'✅ Оплачу в Telegram Stars',cardNumber:'Номер карты',cardHolder:'Получатель',copyCard:'Нажмите, чтобы скопировать номер'});
  Object.assign(dictionaries.uz,{pay_uzcard:'✅ UZCARD orqali to‘layman',pay_humo:'✅ HUMO orqali to‘layman',pay_terminal:'✅ Terminal orqali to‘layman',pay_stars:'✅ Telegram Stars orqali to‘layman',cardNumber:'Karta raqami',cardHolder:'Karta egasi',copyCard:'Nusxalash uchun karta raqamiga bosing'});

  Object.assign(dictionaries.uz,{wing:'Naparnik',comp:'Сорев',manualHint:'Kartaga o‘tkazma',method_terminal:'Bankomat',introSubtitle:'Rank oshirish xizmati',walletTitle:'Hamyonni to‘ldirish',yourBalance:'Balansingiz',continue:'Davom etish',help:'Yordam',helpDesc:'Operator bilan bog‘lanish',commission:'Komissiya 3%',topup:'Hamyonni to‘ldirish',requestSent:'Xabar yuborilgach, administrator tasdig‘ini kuting.',manualNotice:'To‘lovni administrator tasdiqlaydi.'});
  Object.assign(dictionaries.ru,{wing:'Напарник',comp:'Сорев',manualHint:'Перевод на карту',method_terminal:'Банкомат',introSubtitle:'Повышение ранга',walletTitle:'Пополнение кошелька',yourBalance:'Ваш баланс',continue:'Продолжить',help:'Помощь',helpDesc:'Связаться с оператором',commission:'Комиссия 3%',requestSent:'После отправки сообщения ожидайте подтверждения администратора.',manualNotice:'Оплату подтверждает администратор.'});
  const glyph = name => `<img class="ui-icon" src="assets/icons/${name}.svg" alt="" aria-hidden="true" width="32" height="32">`;
  all('[data-ui-icon]').forEach(node=>node.innerHTML=glyph(node.dataset.uiIcon));

  Object.assign(dictionaries.ru, {
    mainServices: 'Разделы', navigation: 'Главное меню', goBack: 'Назад', menu: 'Меню',
    sendAdmin: 'Отправить заявку админу', atmOnly: 'Доступен только банкомат', adminSent: 'Заявка отправлена', terms: 'Принимаю условия',
    payStars: 'Оплатить в Stars', invoiceReady: 'Счёт готов', termsRequired: 'Прими условия оплаты',
    boostEta: 'Примерный срок после оплаты — {hours} ч', inProgress: 'В работе',
    repeatBoost: 'Повторить заказ', orderDetails: 'Детали заказа',
    reviewedStatus: 'На проверке', fulfilledStatus: 'Выполнено', parties: 'Партнёрская программа',
    unavailableHistory: 'История заказов доступна при подключении сервера бота.',
    payBalance: 'Оплатить с баланса', starsQuantity: 'Количество Stars', topupCredit: 'Зачислится на баланс',
    rateExample: 'Пример курса', rateChanged: 'Курс обновился. Проверьте сумму зачисления.',
    orderQuoteChanged: 'Цена обновилась. Откройте заказ заново.',
    checkPayment: 'Проверить оплату', balanceCredited: 'Баланс пополнен', legacyBalance: 'Другие средства: {amount} · поддержка'
  });
  Object.assign(dictionaries.uz, {
    mainServices: 'Xizmatlar', navigation: 'Asosiy menyu', goBack: 'Orqaga', menu: 'Menyu',
    sendAdmin: 'Adminga ariza yuborish', atmOnly: 'Faqat bankomatdan foydalana olaman', adminSent: 'Ariza adminga yuborildi', terms: 'Shartlarga roziman',
    payStars: 'Stars orqali to‘lash', invoiceReady: 'Hisob tayyor', termsRequired: 'To‘lov shartlarini qabul qiling',
    boostEta: 'To‘lovdan keyin taxminan {hours} soat', inProgress: 'Bajarilmoqda',
    repeatBoost: 'Qayta buyurtma berish', orderDetails: 'Buyurtma tafsilotlari',
    reviewedStatus: 'Tekshirilmoqda', fulfilledStatus: 'Bajarildi', parties: 'Hamkorlik dasturi',
    unavailableHistory: 'Buyurtmalar tarixi bot serveri ulanganda ko‘rinadi.',
    payBalance: 'Balansdan to‘lash', starsQuantity: 'Stars soni', topupCredit: 'Hisobga tushadi',
    rateExample: 'Namuna kursi', rateChanged: 'Kurs yangilandi. To‘ldirish summasini tekshiring.',
    orderQuoteChanged: 'Narx yangilandi. Buyurtmani qayta oching.',
    checkPayment: 'To‘lovni tekshirish', balanceCredited: 'Balans to‘ldirildi', legacyBalance: 'Boshqa mablag‘: {amount} · yordam'
  });
  Object.assign(dictionaries.ru, {
    selectService:'Выберите услугу', selectServiceHint:'Выберите раздел, чтобы продолжить',
    serviceBoost:'Повышение ранга', serviceDonat:'Купить донат', serviceDonatHint:'Игровая валюта и услуги',
    transferPay:'Перевод на UZCARD', transferTest:'Закрытый тест. Переводить деньги не нужно.',
    transferSend:'Отправить тестовый чек боту', transferCopy:'Скопировать', transferCopied:'Номер скопирован',
    transferReply:'В боте ответьте на сообщение о заявке фото тестового чека или PDF.',
    transferPending:'Ожидается чек', transferReview:'Чек получен. Ожидается решение администратора.',
    transferWork:'Оплата подтверждена. Заказ передан в работу.', transferTopup:'Тестовый баланс пополнен.',
    transferOpen:'Открыть платёж'
  });
  Object.assign(dictionaries.uz, {
    selectService:'Xizmatni tanlang', selectServiceHint:'Davom etish uchun bo‘limni tanlang',
    serviceBoost:'Rank ko‘tarish', serviceDonat:'Donat sotib olish', serviceDonatHint:'O‘yin valyutalari va xizmatlar',
    transferPay:'UZCARD orqali o‘tkazma', transferTest:'Yopiq sinov. Pul o‘tkazish shart emas.',
    transferSend:'Sinov chekini botga yuborish', transferCopy:'Nusxalash', transferCopied:'Karta raqami nusxalandi',
    transferReply:'Botdagi ariza xabariga javoban sinov cheki rasmini yoki PDF faylini yuboring.',
    transferPending:'Chek kutilmoqda', transferReview:'Chek qabul qilindi. Admin tasdig‘ini kuting.',
    transferWork:'To‘lov tasdiqlandi. Buyurtma ishga olindi.', transferTopup:'Sinov balansi to‘ldirildi.',
    transferOpen:'To‘lovni ochish'
  });
  let mainPage = new URLSearchParams(location.search).get('section') === 'donat' ? 'donat' : 'services';
  const state = {
    lang: storage.get('ab-lang') === 'ru' ? 'ru' : 'uz',
    mode: 'wing', balance: 0, legacyBalance: 0, orders: [], donatOrders: [], payments: [],
    historyTab: 'orders', filter: 'all', historyLoaded: false,
    sheet: null, context: null, service: false, uzcardTest: false, busy: false
  };
  const t = (key, values={}) => Object.entries(values).reduce((s,[k,v])=>s.replaceAll('{'+k+'}',v),dictionaries[state.lang][key] ?? key);
  const money = n => new Intl.NumberFormat('ru-RU').format(n).replace(/\u00a0/g,' ');
  const sum = n => money(n)+' '+t('currency');
  function etaText(eta) {
    const [low, high] = Array.isArray(eta) ? eta : [];
    if (!Number.isSafeInteger(low) || low < 1 || !Number.isSafeInteger(high) || high < low) return '';
    return t('boostEta', {hours: low === high ? String(low) : low + '–' + high});
  }
  const escape = text => String(text ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const rankName = index => +index === 0 ? t('calibration') : state.lang==='uz'?(['Kalibrovka','Bronza','Silver','Gold','Phoenix','Ranger','Champion','Master','Elite','The Legend'][+index]):ranks[+index];
  const from=$('#from-rank'), to=$('#to-rank'), gameId=$('#game-id'), orderBtn=$('#order-btn');
  ranks.forEach((r,i)=>{if(i<ranks.length-1)from.add(new Option(r,i));if(i>0)to.add(new Option(r,i));});
  from.value='0';to.value='3';
  const overlay=$('#overlay'),title=$('#sheet-title'),body=$('#sheet-body');
  let returnFocus=null,toastTimer;
  function toast(text){clearTimeout(toastTimer);$('#toast').textContent=text;$('#toast').classList.add('show');toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),3000);}
  function icon(index){if(+index===0)return '<span class="rank-icon rank-icon-calibration" aria-hidden="true"></span>';const center=rankCenters[+index];return center?`<span class="rank-icon" aria-hidden="true" style="background-position:${19-center[0]*.24}px ${19-center[1]*.24}px"></span>`:'<span aria-hidden="true">♢</span>';}
  function boostQuote(start, end, mode) {
    const steps = start === 0 && end === ranks.length - 1 && calibrationLegendPrice
      ? [calibrationLegendPrice] : prices.slice(start + 1, end + 1);
    const minimumApplied = steps.reduce((total, price) => total + price, 0) < minBoostPrice;
    const terms = minimumApplied ? [minBoostPrice] : steps;
    if (mode !== 'wing' && boostModeSurcharge) terms.push(boostModeSurcharge);
    return {terms, minimumApplied, amount: terms.reduce((total, price) => total + price, 0)};
  }
  function calculation(order) {
    const {terms, minimumApplied} = boostQuote(order.fromIndex, order.toIndex, order.mode);
    if (minimumApplied) {
      const minimum = t('boostMinimum', {price: sum(minBoostPrice)});
      return terms.length === 1 ? minimum : minimum + ' · +' + sum(terms[1]);
    }
    return terms.length === 1
      ? rankName(order.fromIndex) + ' → ' + rankName(order.toIndex)
      : terms.map(money).join(' + ') + ' = ' + sum(order.amount);
  }
  function currentOrder() {
    const fromIndex = Number(from.value), toIndex = Number(to.value);
    return {type:'boost_order', mode:state.mode, fromIndex, toIndex, gameId:gameId.value.trim(), lang:state.lang,
      amount:from.value === '' || to.value === '' ? 0 : boostQuote(fromIndex, toIndex, state.mode).amount};
  }
  function validId(){const value=gameId.value.trim();return [...value].length>0&&[...value].length<=32&&!/[\p{C}\p{Zl}\p{Zp}<>]/u.test(value);}
  function updatePrice(){
    const a=+from.value;
    [...to.options].forEach(option=>option.disabled=+option.value<=a);
    if(to.value!==''&&+to.value<=a)to.value=String(a+1);
    const order=currentOrder();
    $('#amount').textContent=order.amount ? sum(order.amount) : '—';$('#formula').textContent=order.amount ? calculation(order) : '';const count=order.amount ? order.toIndex-order.fromIndex : 0;const ending=state.lang==='uz'?'ta bosqich':count%100>=11&&count%100<=14?'ступеней':count%10===1?'ступень':count%10>=2&&count%10<=4?'ступени':'ступеней';$('#steps').textContent=count+' '+ending;
    [from, to].forEach(select => {
      select.closest('.field').querySelector('.rank-mark').innerHTML = select.value === '' ? '' : icon(select.value);
      const trigger = $('#' + select.id + '-trigger');
      const name = select.value === '' ? t('selectRank') : rankName(select.value);
      trigger.textContent = name;
      trigger.setAttribute('aria-label', t(select === from ? 'currentRank' : 'targetRank') + ', ' + name);
      [...select.options].forEach(option => { option.textContent = rankName(option.value); });
    });
    const minimum = $('#boost-minimum');
    const minimumApplied = order.amount > 0 && boostQuote(order.fromIndex, order.toIndex, order.mode).minimumApplied;
    minimum.hidden = minBoostPrice === 0 || minimumApplied;
    minimum.textContent = t('boostMinimum', {price: sum(minBoostPrice)});
    const estimate = $('#boost-eta');
    estimate.textContent = etaText(boostEta);
    estimate.hidden = !estimate.textContent;
    orderBtn.disabled=!validId()||order.amount<=0;orderBtn.setAttribute('aria-disabled',String(orderBtn.disabled));
  }
  function nav(page, switchService = false) {
    if (switchService) mainPage = page;
    const current = page === 'home' && !switchService ? mainPage : page;
    const isMain = current === 'home' || current === 'donat';
    closeSheet();
    all('.page').forEach(section => section.classList.toggle('active', section.id === current));
    all('[data-service]').forEach(button => {
      button.setAttribute('aria-pressed', String(button.dataset.service === mainPage));
    });
    $('#service-switch').hidden = !isMain;
    $('.tg-icon.left').hidden = current === 'services';
    $('#bottom-nav').hidden = current === 'services';
    all('[data-page]').forEach(button => {
      const active = button.dataset.page === (isMain ? 'home' : current);
      button.classList.toggle('active', active);
      if (active) button.setAttribute('aria-current', 'page');
      else button.removeAttribute('aria-current');
    });
    window.scrollTo(0, 0);
    if (page === 'history' || page === 'settings') syncState();
  }
  function showSheet(name,html,heading){
    if(!overlay.classList.contains('open'))returnFocus=document.activeElement;
    state.sheet=name;
    const topup=['topup','topup-status'].includes(name),wallet=topup||name==='checkout'||name==='transfer',sheet=$('.sheet');
    sheet.classList.toggle('donat-sheet', name === 'donat');
    sheet.classList.toggle('payment-sheet',wallet);title.innerHTML=wallet?glyph('wallet')+'<span>'+escape(heading)+'</span>':escape(heading);
    if(topup)title.innerHTML=`<img class="wallet-brand" src="assets/intro-emblem.webp" width="36" height="36" alt="ARSLAN BOOST"><span>${escape(heading)}</span>`;
    $('#wallet-history')?.remove();
    if(wallet){const button=document.createElement('button');button.type='button';button.id='wallet-history';button.className='wallet-history';button.setAttribute('aria-label',t('history'));button.innerHTML=glyph('book');button.onclick=()=>{state.historyTab='payments';all('[data-history]').forEach(b=>b.classList.toggle('active',b.dataset.history==='payments'));nav('history');renderHistory();};$('#close-sheet').before(button);}
    body.innerHTML=html;overlay.classList.add('open');sheet.focus({preventScroll:true});
  }
  function closeSheet() {
    if (!overlay.classList.contains('open')) return;
    overlay.classList.remove('open');
    state.sheet = null;
    body.replaceChildren();
    returnFocus?.focus?.({ preventScroll: true });
    returnFocus = null;
  }
  function openRanks(which){const select=which==='from'?from:to;const choices=ranks.map((_,i)=>i).filter(i=>which==='from'?i<ranks.length-1:i>+from.value);showSheet('rank:'+which,`<div class="rank-options" role="listbox" aria-label="${escape(t('selectRank'))}">${choices.map(i=>`<button class="rank-option" role="option" aria-selected="${+select.value===i}" data-rank="${i}">${icon(i)}<span>${escape(rankName(i))}</span></button>`).join('')}</div>`,t(which==='from'?'currentRank':'targetRank'));all('[data-rank]').forEach(button=>button.onclick=()=>{select.value=button.dataset.rank;updatePrice();closeSheet();});}
  function statusName(status) {
    const labels = {
      paid: 'paidStatus', approved: 'paidStatus', rejected: 'rejectedStatus',
      pending: 'pendingStatus', review: 'reviewedStatus', in_progress: 'inProgress', fulfilled: 'fulfilledStatus', refunded:'rejectedStatus'
    };
    return t(labels[status] || 'unknownStatus');
  }

  function renderHistory() {
    const isOrder = state.historyTab === 'orders';
    $('#filters').style.display = isOrder ? 'flex' : 'none';
    const orders = [
      ...state.orders.map(item => ({ ...item, kind: 'boost' })),
      ...state.donatOrders.map(item => ({ ...item, kind: 'donat' }))
    ].sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    const statuses = {
      completed: ['paid', 'approved', 'fulfilled'], cancelled: ['rejected', 'refunded'], pending: ['pending', 'review', 'in_progress']
    };
    const entries = isOrder
      ? orders.filter(item => {
          if (state.filter === 'all') return true;
          if (item.kind === 'boost' && item.status === 'paid') return state.filter === 'pending';
          return statuses[state.filter].includes(item.status);
        })
      : state.payments;
    $('#history-content').innerHTML = entries.length ? entries.map(item => {
      const service = item.kind === 'donat' ? 'Donat Shop' : 'Boost';
      const method = t('method_' + item.method);
      const description = !isOrder ? method : item.kind === 'donat'
        ? shop.productTitle(item.product) + ' · ' + shop.optionLabel(item.option_label)
        : rankName(item.current_rank) + ' → ' + rankName(item.target_rank);
      const date = new Date(item.created_at).toLocaleString(state.lang === 'ru' ? 'ru-RU' : 'uz-UZ');
      return `<button type="button" class="txn order-row" data-history-kind="${isOrder ? item.kind : 'payment'}" data-history-id="${escape(item.id)}">
        <div class="txn-icon">${glyph(isOrder ? 'receipt' : 'wallet')}</div>
        <div>${escape(isOrder ? service : t('paymentNumber'))} #${escape(item.id)}
          <small>${escape(description)}</small><small>${escape(statusName(item.status))} · ${escape(date)}</small>
        </div><strong>${escape(sum(item.amount))}</strong>
      </button>`;
    }).join('') : `<div class="empty">${escape(t(state.historyLoaded ? 'emptyHistory' : 'unavailableHistory'))}</div>`;
  }
  function openHistoryEntry(kind, id) {
    const entries = kind === 'boost' ? state.orders : kind === 'donat' ? state.donatOrders : state.payments;
    const item = entries.find(order => String(order.id) === id);
    if (!item) return;
    const description = kind === 'boost' ? rankName(item.current_rank) + ' → ' + rankName(item.target_rank)
      : kind === 'donat' ? shop.productTitle(item.product) + ' · ' + shop.optionLabel(item.option_label)
      : t('method_' + item.method);
    const eta = kind === 'boost' ? etaText([item.eta_min_hours, item.eta_max_hours]) : '';
    const transfer = state.uzcardTest && state.payments.find(payment =>
      payment.method === 'uzcard' && ['pending','review'].includes(payment.status)
      && (kind === 'payment' ? payment.id === item.id : kind === 'boost' ? payment.order_id === item.id : payment.donat_order_id === item.id));
    showSheet('history-entry', `<div class="checkout-summary">
      <div><strong>${escape(description)}</strong></div>
      ${kind === 'boost' && item.game_id ? '<div>ID: ' + escape(item.game_id) + '</div>' : ''}
      <div>${escape(statusName(item.status))} · ${escape(sum(item.amount))}</div>
      ${eta ? '<div>' + escape(eta) + '</div>' : ''}
      </div>${transfer ? '<button type="button" class="action" id="resume-transfer">' + escape(t('transferOpen')) + '</button>' : ''}
      ${kind === 'boost' && !transfer ? '<button type="button" class="action" id="repeat-boost">' + escape(t('repeatBoost')) + '</button>' : ''}`,
      t('orderDetails') + ' #' + id);
    $('#resume-transfer')?.addEventListener('click', event => {
      requestTransfer('transfer', {paymentId:transfer.id}, event.currentTarget, () => openHistoryEntry(kind,id));
    });
    $('#repeat-boost')?.addEventListener('click', () => {
      gameId.value = item.game_id || '';
      storage.set('ab-game-id', gameId.value);
      from.value = '';
      to.value = '';
      nav('home', true);
      selectMode(item.mode);
    });
  }

  function applyLanguage(){
    document.documentElement.lang=state.lang;all('[data-i18n]').forEach(x=>x.textContent=t(x.dataset.i18n));all('[data-lang]').forEach(b=>b.classList.toggle('active',b.dataset.lang===state.lang));
    gameId.placeholder=t('idPlaceholder');gameId.setAttribute('aria-label',t('gameId'));$('#close-sheet').setAttribute('aria-label',t('close'));
    $('#service-switch').setAttribute('aria-label', t('mainServices'));
    $('#bottom-nav').setAttribute('aria-label', t('navigation'));
    $('.tg-icon.left').setAttribute('aria-label', t('goBack'));
    $('.tg-icon.right').setAttribute('aria-label', t('menu'));
    shop.applyLanguage();
    const banner=config.banners?.[state.lang];if(banner){try{const url=new URL(banner,document.baseURI);if(['https:','http:'].includes(url.protocol))$('.hero').style.backgroundImage=`url(${JSON.stringify(url.href)})`;}catch{}}
    all('[data-mode]').forEach(button=>button.textContent=t(button.dataset.mode));$('#mode-label').textContent=t('selectedMode')+': '+t(state.mode);
    $('#quick-balance').textContent=sum(state.balance);$('#setting-balance').textContent=sum(state.balance);updatePrice();renderHistory();
    const sheet=state.sheet;
    if(sheet?.startsWith('rank:'))openRanks(sheet.split(':')[1]);
    else if(sheet==='checkout')renderPayments();
    else if(sheet==='topup')renderTopup();
    else if(sheet==='topup-status')renderTopupStatus(state.context);
    else if(sheet==='transfer')renderTransfer(state.context);
    else if(sheet)openInfo(sheet);
  }
  function starsEnabled() {
    return state.service && Number.isSafeInteger(config.starsRate) && config.starsRate > 0
      && Number.isSafeInteger(config.starsMax) && config.starsMax > 0
      && /^https:\/\/[^\s<>]+$/.test(config.termsUrl || '') && typeof tg?.openInvoice === 'function';
  }
  function paymentTerms() {
    return starsEnabled()
      ? `<label class="terms-choice"><input type="checkbox" id="accept-payment-terms"><a href="${escape(config.termsUrl)}" target="_blank" rel="noopener noreferrer">${escape(t('terms'))}</a></label>`
      : `<p class="notice">${escape(t('starsNotConfigured'))}</p>`;
  }
  function orderSummary(context){
    const order=context.order;return `<div class="checkout-summary"><div>${glyph('receipt')} <strong>${escape(t(order.mode))}</strong></div><div>${escape(rankName(order.fromIndex))} → ${escape(rankName(order.toIndex))}</div><div>ID: ${escape(order.gameId)}</div><strong>${escape(t('total'))}: ${escape(sum(order.amount))}</strong>${etaText(context.eta ?? boostEta) ? '<div>' + escape(etaText(context.eta ?? boostEta)) + '</div>' : ''}</div>`;
  }
  function openOrderHelp(send, back, draft) {
    if (!state.service) {
      const link = adminUrl(draft, 'payment');
      showSheet('order-help', `<p>${escape(t(link ? 'draftHint' : 'adminMissing'))}</p>
        <button class="action" type="button" id="order-help-submit" ${link ? '' : 'disabled'}>${escape(t('sendAdmin'))}</button>
        <button class="secondary" type="button" id="order-help-back">${escape(t('goBack'))}</button>`, t('sendAdmin'));
      $('#order-help-submit').onclick = () => openTelegram(link);
      $('#order-help-back').onclick = back;
      return;
    }
    showSheet('order-help', `<label class="terms-choice"><input id="order-help-atm" type="checkbox">${escape(t('atmOnly'))}</label>
      <button class="action" type="button" id="order-help-submit">${escape(t('sendAdmin'))}</button>
      <button class="secondary" type="button" id="order-help-back">${escape(t('back'))}</button>`, t('sendAdmin'));
    $('#order-help-back').onclick=back;
    const button=$('#order-help-submit');
    button.onclick=async()=>{
      button.disabled=true;
      try {
        const result=await send($('#order-help-atm').checked?'atm':undefined);
        if(button.isConnected)showSheet('order-help',`<p>${escape(t('adminSent'))} #${escape(result.id)}</p>`,t('adminSent'));
      } catch(error) {toast(errorMessage(error));}
      finally {button.disabled=false;}
    };
  }
  function renderPayments() {
    const c=state.context;
    const enough=state.balance>=c.order.amount;
    showSheet('checkout', orderSummary(c)+`
      <p>${escape(t('balanceHint',{amount:sum(state.balance)}))}</p>
      ${state.uzcardTest ? `<button class="action" type="button" id="checkout-uzcard">${escape(t('transferPay'))}</button>` : ''}
      <button class="action" type="button" id="payment-continue" ${!enough||!state.service?'disabled':''}>${escape(t('payBalance'))}</button>
      ${enough?'':`<button class="secondary" type="button" id="checkout-topup">${escape(t('topup'))}</button>`}
      <button class="secondary" type="button" id="send-order-help">${escape(t('sendAdmin'))}</button>`,t('choosePayment'));
    $('#checkout-topup')?.addEventListener('click',()=>openTopup(()=>{state.context=c;renderPayments();}));
    $('#checkout-uzcard')?.addEventListener('click', event => requestTransfer('checkout',
      {...c.order,lang:state.lang,paymentMethod:'uzcard',expectedAmount:c.order.amount,requestId:requestId(c,'uzcard')},
      event.currentTarget, () => {state.context=c;renderPayments();}));
    const button=$('#payment-continue');
    button.onclick=async()=>{
      if(button.disabled)return;
      button.disabled=true;
      try {
        const result=await api('checkout',{...c.order,lang:state.lang,paymentMethod:'balance',
          expectedAmount:c.order.amount,requestId:requestId(c,'balance')});
        await syncState();
        if(button.isConnected)showSheet('checkout-paid',`<div class="checkout-summary">${escape(t('orderNumber'))} #${escape(result.id)} · ${escape(sum(result.amount))}</div><p>${escape(t('orderSent'))}</p>`,t('paid'));
      } catch(error) {
        if(error.message==='insufficient_balance') {
          await syncState();
          if(button.isConnected)renderPayments();
        } else if(error.message==='order_quote_changed'&&button.isConnected) {
          closeSheet();
          await loadConfig();
        }
        toast(errorMessage(error));
      } finally {button.disabled=false;}
    };
    $('#send-order-help').onclick=()=>openOrderHelp(
      reason=>api('order-help',{...c.order,kind:'boost',reason,requestId:requestId(c,reason?'admin_atm':'admin')}),
      renderPayments,
      [
        t('orderRequest'), t(c.order.mode),
        `${rankName(c.order.fromIndex)} → ${rankName(c.order.toIndex)}`,
        `ID: ${c.order.gameId}`, `${t('total')}: ${sum(c.order.amount)}`
      ].join('\n'));
  }
  function openTopup(back) {
    state.context={kind:'topup',starsInput:'100',sumInput:'50000',back};
    renderTopup();
  }
  function renderTopup() {
    if (state.uzcardTest) return renderUzcardTopup();
    const context=state.context;
    const enabled=starsEnabled(),rate=enabled?config.starsRate:160,max=enabled?config.starsMax:100000;
    showSheet('topup',`
      <div class="wallet-balance"><div>${glyph('wallet')} ${escape(t('yourBalance'))}</div><strong id="topup-balance">${escape(sum(state.balance))}</strong></div>
      ${state.legacyBalance?`<button class="secondary" id="legacy-balance" type="button">${escape(t('legacyBalance',{amount:sum(state.legacyBalance)}))}</button>`:''}
      <div class="checkout-summary topup-method"><b class="topup-star" aria-hidden="true">⭐</b><div>${escape(t('paymentMethod'))}<br><strong>Telegram Stars</strong></div></div>
      <label for="topup-stars">${escape(t('starsQuantity'))}</label>
      <input id="topup-stars" inputmode="numeric" autocomplete="off" maxlength="6" value="${escape(context.starsInput)}">
      <p class="topup-rate">${enabled?'':escape(t('rateExample'))+' · '}1–${escape(money(max))} ⭐ · 1 ⭐ = ${escape(sum(rate))}</p>
      <div class="checkout-summary topup-quote"><span>${escape(t('topupCredit'))}</span><strong id="topup-quote" aria-live="polite"></strong></div>
      ${paymentTerms()}
      <button class="wallet-continue" type="button" id="topup-continue" disabled>${escape(t('continue'))}</button>
      ${(state.testProviders||[]).map(method=>
        `<button class="secondary" type="button" data-test-provider="${method}">${method==='click'?'Click':'Payme'} TEST</button>`).join('')}
      <p id="provider-test-status" role="status"></p>
      ${context.back?`<button class="secondary" type="button" id="topup-back">${escape(t('goBack'))}</button>`:''}`,t('walletTitle'));
    const input=$('#topup-stars'),quote=$('#topup-quote'),pay=$('#topup-continue'),accept=$('#accept-payment-terms');
    const update=()=>{
      context.starsInput=input.value;
      const stars=/^\d+$/.test(input.value)?Number(input.value):0;
      const valid=Number.isSafeInteger(stars)&&stars>=1&&stars<=max;
      quote.textContent=valid?sum(stars*rate):'—';
      pay.disabled=state.busy||!accept?.checked||!valid;
    };
    input.addEventListener('input',update);
    accept?.addEventListener('change',update);
    pay.onclick=async()=>{
      if(pay.disabled)return;
      state.busy=true;
      input.disabled=accept.disabled=true;
      update();
      try {
        const stars=Number(context.starsInput);
        const result=await api('topup',{stars,starsRate:rate,lang:state.lang,paymentMethod:'stars',
          acceptTerms:true,requestId:requestId(context,`${stars}:${rate}`)});
        if(!pay.isConnected||state.context!==context)return;
        context.payment=result;
        renderTopupStatus(context);
        if(result.invoiceLink)openTopupInvoice(context);
        else if(result.status==='paid')await syncState();
      } catch(error) {
        if(error.message==='stars_quote_changed') {
          await loadConfig();
          if(pay.isConnected) {
            state.busy=false;
            renderTopup();
          }
        }
        toast(errorMessage(error));
      } finally {
        state.busy=false;
        if(pay.isConnected) {
          input.disabled=accept.disabled=false;
          update();
        }
      }
    };
    $('#legacy-balance')?.addEventListener('click',()=>openInfo('support'));
    $('#topup-back')?.addEventListener('click',context.back);
    const testButtons = [...document.querySelectorAll('[data-test-provider]')];
    for (const button of testButtons) {
      button.onclick = () => runProviderTest(context, button.dataset.testProvider, testButtons);
    }
    update();
  }
  function renderUzcardTopup() {
    const context = state.context;
    showSheet('topup', `
      <div class="wallet-balance"><div>${glyph('wallet')} ${escape(t('yourBalance'))}</div><strong id="topup-balance">${escape(sum(state.balance))}</strong></div>
      <label for="uzcard-topup-amount">${escape(t('topupAmount'))}</label>
      <input id="uzcard-topup-amount" inputmode="numeric" autocomplete="off" maxlength="9" value="${escape(context.sumInput)}">
      <h2 class="payment-heading">${escape(t('paymentMethod'))}</h2>
      <div class="checkout-summary topup-method"><img width="40" height="40" src="assets/uzcard.svg" alt="">
        <div><strong>UZCARD</strong><br>${escape(t('manualHint'))}</div></div>
      <p class="notice">${escape(t('transferTest'))}</p>
      <button class="wallet-continue" type="button" id="uzcard-topup-continue">${escape(t('continue'))}</button>
      ${context.back ? `<button class="secondary" type="button" id="topup-back">${escape(t('goBack'))}</button>` : ''}`, t('walletTitle'));
    const input = $('#uzcard-topup-amount');
    const button = $('#uzcard-topup-continue');
    const amount = () => /^\d{1,9}$/.test(input.value.trim()) ? Number(input.value) : 0;
    const update = () => {
      context.sumInput = input.value;
      button.disabled = amount() < 1 || amount() > 100_000_000;
    };
    input.addEventListener('input', update);
    button.onclick = () => requestTransfer('topup', {
      paymentMethod:'uzcard', amount:amount(), lang:state.lang, requestId:requestId(context,'uzcard:'+amount())
    }, button, () => {state.context=context;renderTopup();});
    $('#topup-back')?.addEventListener('click', context.back);
    update();
  }

  async function requestTransfer(path, data, button, back) {
    if (button.disabled) return;
    const controls = [...body.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled])')];
    controls.forEach(control => control.disabled = true);
    try {
      const result = await api(path, data);
      if (!button.isConnected) return;
      const context = {transfer:result.transfer ?? result, back};
      state.context = context;
      renderTransfer(context);
      await syncState();
    } catch (error) {
      if (button.isConnected) toast(errorMessage(error));
    } finally {
      controls.forEach(control => control.disabled = false);
    }
  }

  function renderTransfer(context) {
    const transfer = context.transfer;
    const pending = transfer.status === 'pending';
    const message = {
      pending:'transferPending', review:'transferReview', rejected:'rejectedStatus',
      paid:transfer.kind === 'topup' ? 'transferTopup' : 'transferWork'
    }[transfer.status] || 'unknownStatus';
    const receipt = pending && validTelegramUrl(transfer.receiptLink);
    showSheet('transfer', `
      <div class="checkout-summary"><strong>UZCARD · #${escape(transfer.id)}</strong>
        ${transfer.orderId ? `<div>${escape(t('orderNumber'))} #${escape(transfer.orderId)}</div>` : ''}
        <div>${escape(t('total'))} · <strong>${escape(sum(transfer.amount))}</strong></div></div>
      <p class="notice">${escape(t('transferTest'))}</p>
      <p role="status">${escape(t(message))}</p>
      ${pending ? `<div class="checkout-summary">
        <label for="transfer-card">${escape(t('cardNumber'))}</label>
        <input id="transfer-card" value="${escape(transfer.cardNumber)}" readonly aria-readonly="true">
        <div>${escape(t('cardHolder'))} · ${escape(transfer.cardHolder)}</div>
        <button class="secondary" id="transfer-copy" type="button">${escape(t('transferCopy'))}</button>
      </div>
      <p>${escape(t('transferReply'))}</p>
      <button class="action" id="transfer-receipt" type="button" ${receipt ? '' : 'disabled'}>${escape(t('transferSend'))}</button>` : ''}
      <button class="secondary" id="transfer-refresh" type="button">${escape(t('checkPayment'))}</button>
      <button class="secondary" id="transfer-back" type="button">${escape(t('goBack'))}</button>`, t('transferPay'));
    $('#transfer-copy')?.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(transfer.cardNumber.replaceAll(' ', ''));
        toast(t('transferCopied'));
      } catch {
        const input = $('#transfer-card');
        input?.focus();
        input?.select();
      }
    });
    $('#transfer-receipt')?.addEventListener('click', () => openTelegram(receipt.href));
    $('#transfer-refresh').onclick = () => refreshTransfer(context);
    $('#transfer-back').onclick = context.back || closeSheet;
  }

  async function refreshTransfer(context) {
    if (context.refreshing) return;
    context.refreshing = true;
    const button = $('#transfer-refresh');
    if (button) button.disabled = true;
    try {
      context.transfer = await api('transfer', {paymentId:context.transfer.id});
      if (state.sheet === 'transfer' && state.context === context) renderTransfer(context);
      await syncState();
    } catch (error) {
      if (button?.isConnected) toast(errorMessage(error));
    } finally {
      context.refreshing = false;
      if (button?.isConnected) button.disabled = false;
    }
  }
  async function runProviderTest(context, method, buttons) {
    const status = $('#provider-test-status');
    const ru = state.lang === 'ru';
    const awaiting = context.testAwaiting ??= new Set();
    const data = {method, lang: state.lang, requestId: requestId(context, `test:${method}`)};
    const check = async () => {
      const result = await api('payment-test', {...data, action:'status'});
      status.textContent = result.status === 'paid'
        ? (ru ? 'Тестовый платёж подтверждён сервером.' : 'Sinov to‘lovi serverda tasdiqlandi.')
        : (ru ? 'Ожидается подтверждение. Нажми кнопку TEST ещё раз.' : 'Tasdiq kutilmoqda. TEST tugmasini yana bosing.');
    };
    buttons.forEach(button => button.disabled = true);
    try {
      if (awaiting.has(method)) {
        await check();
        return;
      }
      if (typeof tg?.openInvoice !== 'function') throw new Error('connection_error');
      const result = await api('payment-test', {...data, action:'create'});
      if (!status.isConnected) return;
      if (result.invoiceLink) {
        const invoiceStatus = await new Promise(resolve => tg.openInvoice(result.invoiceLink, resolve));
        if (invoiceStatus !== 'paid' && invoiceStatus !== 'pending') {
          status.textContent = ru ? 'Тестовый счёт закрыт.' : 'Sinov hisobi yopildi.';
          return;
        }
        awaiting.add(method);
      }
      await check();
    } catch {
      status.textContent = ru ? 'Не удалось проверить счёт. Попробуй ещё раз.' : 'Hisobni tekshirib bo‘lmadi. Qayta urinib ko‘ring.';
    } finally {
      buttons.forEach(button => button.disabled = false);
    }
  }
  function validTelegramUrl(value){try{const u=new URL(value);return u.protocol==='https:'&&u.hostname==='t.me'&&/^\/[A-Za-z0-9_]{3,32}\/?$/.test(u.pathname)?u:null;}catch{return null;}}
  function adminUrl(text,scope='support'){
    const url=validTelegramUrl(scope==='payment'?(config.paymentAdminUrl||config.supportUrl):config.supportUrl);if(!url)return null;
    // URLSearchParams encodes spaces as '+', which Telegram iOS can display literally.
    return url.origin+url.pathname+(text?'?text='+encodeURIComponent(text):'');
  }
  function openTelegram(url){if(!url)return;try{if(tg?.initData&&tg.openTelegramLink)tg.openTelegramLink(url);else window.location.assign(url);}catch{toast(t('connectionError'));}}
  function requestId(context,key) {
    const requests=context.requests??=new Map();
    if(!requests.has(key)) {
      const bytes=crypto.getRandomValues(new Uint8Array(16));
      requests.set(key,Array.from(bytes,n=>n.toString(16).padStart(2,'0')).join(''));
    }
    return requests.get(key);
  }
  function renderTopupStatus(context) {
    const payment=context.payment,paid=payment.status==='paid';
    const action=paid?'':context.awaiting?'checkPayment':'payStars';
    showSheet('topup-status',`
      <div class="checkout-summary topup-quote"><span>${escape(money(payment.stars))} ⭐</span><strong>${escape(sum(payment.amount))}</strong></div>
      <p role="status">${escape(t(paid?'balanceCredited':context.awaiting?'confirming':'invoiceReady'))}</p>
      ${action?`<button class="wallet-continue" type="button" id="topup-status-action" ${context.checking||context.invoiceOpen?'disabled':''}>${escape(t(action))}</button>`:''}
      <button class="secondary" type="button" id="topup-status-back">${escape(t('goBack'))}</button>`,t('walletTitle'));
    $('#topup-status-action')?.addEventListener('click',()=>context.awaiting?confirmTopup(context):openTopupInvoice(context));
    $('#topup-status-back').onclick=()=>{
      if(paid){if(context.back)context.back();else openTopup();}
      else renderTopup();
    };
  }
  function openTopupInvoice(context) {
    if(context.invoiceOpen||!context.payment.invoiceLink)return;
    context.invoiceOpen=true;
    renderTopupStatus(context);
    try {
      tg.openInvoice(context.payment.invoiceLink,status=>{
        context.invoiceOpen=false;
        if(status==='paid'||status==='pending') {
          context.awaiting=true;
          confirmTopup(context);
        } else if(state.context===context&&state.sheet==='topup-status') {
          renderTopupStatus(context);
          toast(t('invoiceClosed'));
        }
      });
    } catch {
      context.invoiceOpen=false;
      renderTopupStatus(context);
      toast(t('connectionError'));
    }
  }
  function apiUrl(path){return config.apiBaseUrl?config.apiBaseUrl.replace(/\/$/,'')+'/api/'+path:new URL('api/'+path,document.baseURI).href;}
  async function api(path,data){
    const response=await fetch(apiUrl(path),{method:'POST',headers:{'Content-Type':'application/json','X-Telegram-Init-Data':tg?.initData||''},body:JSON.stringify(data||{}),signal:AbortSignal.timeout(15000)});
    let result;try{result=await response.json();}catch{throw new Error('connection_error');}if(!response.ok)throw new Error(result?.error||'connection_error');if(!result||typeof result!=='object')throw new Error('connection_error');return result;
  }
  let syncVersion = 0;
  async function syncState() {
    if (!state.service || !tg?.initData) return null;
    const version = ++syncVersion;
    const [boost, donat] = await Promise.allSettled([api('state'), api('donat/state')]);
    const boostData = boost.status === 'fulfilled' ? boost.value : null;
    if (version !== syncVersion) return boostData;
    if (boostData) {
      state.uzcardTest = boostData.uzcardTest === true;
      state.balance = Number(state.uzcardTest ? boostData.balance : boostData.starsBalance) || 0;
      state.legacyBalance = Math.max(0, (Number(boostData.balance) || 0) - state.balance);
      state.orders = Array.isArray(boostData.orders) ? boostData.orders : [];
      state.payments = Array.isArray(boostData.payments) ? boostData.payments : [];
      state.testProviders = Array.isArray(boostData.testProviders)
        ? boostData.testProviders.filter(method => method === 'click' || method === 'payme') : [];
      if (!gameId.value && boostData.gameId) {
        gameId.value = boostData.gameId;
        updatePrice();
      }
      $('#quick-balance').textContent = sum(state.balance);
      $('#setting-balance').textContent = sum(state.balance);
      const topupBalance=$('#topup-balance');
      if(topupBalance)topupBalance.textContent=sum(state.balance);
    }
    if (donat.status === 'fulfilled' && Array.isArray(donat.value.orders)) {
      state.donatOrders = donat.value.orders;
    }
    state.historyLoaded ||= Boolean(boostData) || donat.status === 'fulfilled';
    renderHistory();
    return boostData;
  }
  async function confirmTopup(context) {
    if(context.checking)return;
    context.checking=true;
    const visible=()=>state.context===context&&state.sheet==='topup-status';
    if(visible())renderTopupStatus(context);
    try {
      for(let attempt=0;attempt<5;attempt++) {
        const result=await syncState();
        const payment=result?.payments?.find(item=>item.id===context.payment.id);
        if(payment?.status==='paid') {
          context.payment=payment;
          if(visible())toast(t('balanceCredited'));
          break;
        }
        if(!visible())break;
        await new Promise(resolve=>setTimeout(resolve,1000));
      }
    } finally {
      context.checking=false;
      if(visible())renderTopupStatus(context);
    }
  }
  function errorMessage(error){const mapping={invalid_game_id:'invalidId',insufficient_balance:'notEnough',stars_not_configured:'starsNotConfigured',stars_quote_changed:'rateChanged',order_quote_changed:'orderQuoteChanged',terms_required:'termsRequired',unauthorized:'sessionExpired',session_expired:'sessionExpired'};return t(mapping[error.message]||'connectionError');}
  function openInfo(name){
    if(name==='balance'){openTopup();return;}
    const textKey={support:'supportText',profile:'profileText',security:'securityText',about:'aboutText',promo:'promoText'}[name]||'aboutText';
    const user=tg?.initDataUnsafe?.user;
    let html=`<p>${escape(t(textKey))}</p>`;
    if(name==='profile')html+=`<div class="checkout-summary">${escape([user?.first_name,user?.last_name].filter(Boolean).join(' ')||t('appUser'))}${user?.id?'<br>ID: '+escape(user.id):''}</div>`;
    if(name==='promo')html+=`<input id="promo-input" maxlength="64" placeholder="${escape(t('promoPlaceholder'))}"><button class="action" id="promo-submit">${escape(t('promoAction'))}</button>`;
    if(name==='support'){html+=`<button class="action" id="support-contact" ${adminUrl()?'':'disabled'}>${escape(t('admin'))}</button>`;if(!adminUrl())html+=`<p class="notice">${escape(t('adminMissing'))}</p>`;}
    showSheet(name,html,t(name));
    $('#support-contact')?.addEventListener('click',()=>openTelegram(adminUrl()));$('#promo-submit')?.addEventListener('click',()=>{const code=$('#promo-input').value.trim();if(!code){$('#promo-input').focus();return;}const message=t('promo')+': '+code;const link=adminUrl(message);if(link)openTelegram(link);else toast(t('adminMissing'));});
  }
  const shop = window.initArslanShop({
    config,
    openTopup, openOrderHelp, requestTransfer, canTransfer: () => state.uzcardTest,
    syncState, walletBalance: () => state.balance,
    lang: () => state.lang,
    api,
    connected: () => state.service && Boolean(tg?.initData),
    openSheet: (heading, html) => showSheet('donat', html, heading),
    closeSheet,
    sheetBody: body,
    openTelegram,
    telegramUrl: validTelegramUrl,
    toast,
    escape,
    money,
    glyph,
    showHistory: () => {
      state.historyTab = 'orders';
      state.filter = 'all';
      all('[data-history]').forEach(button => button.classList.toggle('active', button.dataset.history === 'orders'));
      all('#filters .chip').forEach((button, index) => button.classList.toggle('active', index === 0));
      nav('history');
      renderHistory();
    }
  });
  function openMenu() {
    showSheet('menu', `
      <button class="action" type="button" id="menu-partners">${escape(t('parties'))}</button>
      <button class="secondary" type="button" id="menu-support">${escape(t('support'))}</button>
      <button class="secondary" type="button" id="menu-about">${escape(t('about'))}</button>`, t('menu'));
    $('#menu-partners').onclick = () => shop.openPartners();
    $('#menu-support').onclick = () => openInfo('support');
    $('#menu-about').onclick = () => openInfo('about');
  }
  all('[data-page]').forEach(button => button.onclick = () => nav(button.dataset.page));
  all('[data-service]').forEach(button => button.onclick = () => nav(button.dataset.service, true));
  all('[data-nav]').forEach(button => button.onclick = () => nav(button.dataset.nav));
  all('[data-sheet]').forEach(button => button.onclick = () => openInfo(button.dataset.sheet));
  $('[data-partners]').onclick = () => shop.openPartners();
  function selectMode(mode) {
    state.mode = ['wing','comp','duel'].includes(mode) ? mode : 'wing';
    all('.mode').forEach(button => {
      const selected = button.dataset.mode === state.mode;
      button.classList.toggle('selected', selected);
      button.setAttribute('aria-pressed', String(selected));
    });
    $('#mode-label').textContent = t('selectedMode') + ': ' + t(state.mode);
    updatePrice();
  }
  all('.mode').forEach(button => button.onclick = () => selectMode(button.dataset.mode));
  $('#history-content').addEventListener('click', event => {
    const button = event.target.closest('[data-history-kind]');
    if (button) openHistoryEntry(button.dataset.historyKind, button.dataset.historyId);
  });
  $('#from-rank-trigger').onclick=()=>openRanks('from');$('#to-rank-trigger').onclick=()=>openRanks('to');from.onchange=updatePrice;to.onchange=updatePrice;let profileTimer;gameId.value=storage.get('ab-game-id')||'';gameId.addEventListener('input',()=>{updatePrice();clearTimeout(profileTimer);storage.set('ab-game-id',gameId.value);if(validId()&&state.service&&tg?.initData)profileTimer=setTimeout(()=>api('profile',{gameId:gameId.value.trim(),lang:state.lang}).catch(()=>{}),500);});
  orderBtn.onclick=()=>{if(!validId()||orderBtn.disabled){gameId.focus();toast(t('invalidId'));return;}gameId.blur();state.context={kind:'order',order:currentOrder()};renderPayments();};
  $('#close-sheet').onclick=closeSheet;overlay.onclick=e=>{if(e.target===overlay)closeSheet();};document.addEventListener('keydown',event=>{if(!overlay.classList.contains('open'))return;if(event.key==='Escape')closeSheet();if(event.key==='Tab'){const focusable=[...overlay.querySelectorAll('button:not([disabled]),input,textarea,[tabindex="0"]')];const first=focusable[0],last=focusable.at(-1);if(event.shiftKey&&document.activeElement===first){last?.focus();event.preventDefault();}else if(!event.shiftKey&&document.activeElement===last){first?.focus();event.preventDefault();}}});
  all('[data-lang]').forEach(button=>button.onclick=()=>{state.lang=button.dataset.lang;storage.set('ab-lang',state.lang);applyLanguage();if(state.service&&tg?.initData)api('profile',{lang:state.lang}).catch(()=>{});});
  all('[data-history]').forEach(button=>button.onclick=()=>{state.historyTab=button.dataset.history;all('[data-history]').forEach(b=>b.classList.toggle('active',b===button));renderHistory();syncState();});
  all('#filters .chip').forEach((button,i)=>{button.onclick=()=>{state.filter=['all','completed','pending','cancelled'][i];all('#filters .chip').forEach(b=>b.classList.toggle('active',b===button));renderHistory();};});
  function setMotion(reduced){document.body.classList.toggle('reduce-motion',reduced);$('#motion-toggle').classList.toggle('on',reduced);storage.set('ab-reduced-motion',String(reduced));}
  $('#setting-balance-card')?.addEventListener('click',()=>openInfo('balance'));$('#motion-row').onclick=()=>setMotion(!document.body.classList.contains('reduce-motion'));if(storage.get('ab-reduced-motion')==='true')setMotion(true);
  const user=tg?.initDataUnsafe?.user;if(user){$('#username').textContent=[user.first_name,user.last_name].filter(Boolean).join(' ')||t('appUser');$('#telegram-id').textContent=user.username?'@'+user.username:'ID: '+user.id;const avatar=$('.avatar'),initial=(user.first_name||'A').slice(0,1);avatar.textContent=initial;if(user.photo_url){try{const photo=new URL(user.photo_url);if(photo.protocol==='https:'){const img=new Image();img.alt='';img.width=54;img.height=54;img.decoding='async';img.referrerPolicy='no-referrer';img.onload=()=>avatar.replaceChildren(img);img.onerror=()=>{avatar.textContent=initial;};img.src=photo.href;}}catch{}}}
  $('.tg-icon.left').onclick=()=>{if(overlay.classList.contains('open'))closeSheet();else nav('services',true);};$('.tg-icon.right').onclick=openMenu;
  window.visualViewport?.addEventListener('resize',()=>document.body.classList.toggle('keyboard-open',window.innerHeight-window.visualViewport.height>140));
  document.addEventListener('visibilitychange',()=>{
    if(document.visibilityState!=='visible')return;
    if(state.sheet==='transfer')refreshTransfer(state.context);else syncState();
  });
  // Lock accidental WebView pinch/double-tap zoom, retain normal one-finger scrolling.
  const stopZoom=e=>{if(e.cancelable)e.preventDefault();};
  ['gesturestart','gesturechange','gestureend'].forEach(name=>document.addEventListener(name,stopZoom,{passive:false}));
  document.addEventListener('touchmove',e=>{if(e.touches.length>1)stopZoom(e);},{passive:false});
  let lastTap=0,lastPoint=null;document.addEventListener('touchend',e=>{const p=e.changedTouches[0],now=Date.now();if(p&&lastPoint&&now-lastTap<300&&Math.hypot(p.clientX-lastPoint.x,p.clientY-lastPoint.y)<25)stopZoom(e);lastTap=now;lastPoint=p?{x:p.clientX,y:p.clientY}:null;},{passive:false});
  document.addEventListener('wheel',e=>{if(e.ctrlKey)stopZoom(e);},{passive:false});
  applyLanguage();
  nav(mainPage, true);
  async function loadConfig(){if(!tg?.initData)return;try{const response=await fetch(apiUrl('config'),{signal:AbortSignal.timeout(5000)});if(!response.ok)return;const server=await response.json();if(!server.arslanBoostApi)return;if(server.botUrl)config.botUrl=server.botUrl;for(const key of ['termsUrl','starsRate','starsMax'])config[key]=server[key];if(Array.isArray(server.prices)&&server.prices.length===prices.length&&server.prices.every(p=>Number.isSafeInteger(p)&&p>=0)){
      prices=server.prices;
      calibrationLegendPrice=Number.isSafeInteger(server.calibrationLegendPrice)?server.calibrationLegendPrice:0;
      boostModeSurcharge=Number.isSafeInteger(server.boostModeSurcharge)?server.boostModeSurcharge:0;
      minBoostPrice=Number.isSafeInteger(server.minBoostPrice)&&server.minBoostPrice>0?server.minBoostPrice:0;
    }boostEta=server.boostEta;state.service=true;updatePrice();await syncState();if(state.sheet==='topup'&&!state.busy)renderTopup();else if(state.sheet==='checkout')renderPayments();}catch{}}
  loadConfig();
  const intro=$('#intro');let introTimeout;function finishIntro(){clearTimeout(introTimeout);intro.classList.remove('show');intro.setAttribute('aria-hidden','true');}
  if(storage.get('ab-reduced-motion')!=='true'&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches){const duration=Math.min(1000,Math.max(400,config.introDuration||800));intro.style.setProperty('--intro-duration',duration+'ms');intro.classList.add('show');intro.setAttribute('aria-hidden','false');introTimeout=setTimeout(finishIntro,duration);}
})();

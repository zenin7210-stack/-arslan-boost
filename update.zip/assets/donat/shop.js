'use strict';

window.initArslanShop = function ({
  config, lang, api, connected, openSheet, closeSheet, sheetBody, openTopup, walletBalance, syncState, openOrderHelp,
  requestTransfer, canTransfer,
  openTelegram, telegramUrl, toast, escape, money, glyph, showHistory
}) {
  const translations = {
    uz: {
      sub: 'O‘yin valyutalari va xizmatlar', search: 'Qidirish…', clear: 'Qidiruvni tozalash',
      all: 'Hammasi', games: 'O‘yinlar', services: 'Servislar', filters: 'Do‘kon filtrlari',
      other: 'Boshqa o‘yinlar', showAll: 'Barchasi', noResults: 'Mahsulot topilmadi',
      loading: 'Mahsulotlar yuklanmoqda…', loadError: 'Katalogni yuklab bo‘lmadi', retry: 'Qayta urinish',
      quantity: 'Nechta Gold kerak?', select: 'Paketni tanlang', game: 'O‘yin ID',
      username: 'Username', optional: 'Nick yoki izoh (ixtiyoriy)', example: 'Masalan, 12345678',
      price: 'Jami', next: 'Davom etish', back: 'Orqaga', pay: 'To‘lov usuli',
      confirm: 'Buyurtma berish', copy: 'Xabarni nusxalash', contact: 'Administratorga yozish',
      receipt: 'Chekni botga yuborish', manual: 'Rekvizitlarni administratordan oling. To‘lovdan keyin chek yuboring.',
      market: 'Skinni qo‘yishdan oldin narxni admin bilan kelishing. Skinni aynan shu narxda qo‘ying.',
      created: 'Buyurtma yaratildi', draft: 'Buyurtma matni tayyor', sendBot: 'Botga yuborish',
      draftHint: 'Buyurtmani rasmiylashtirish uchun xabarni administratorga yuboring.',
      delivery: 'Admin to‘lovni tekshiradi va buyurtmani bajaradi.',
      error: 'Serverga ulanib bo‘lmadi. Qayta urinib ko‘ring.', copied: 'Nusxalandi',
      copyHint: 'Matnni belgilang va nusxalang', done: 'Tayyor', terminal: 'Bankomat',
      partners: 'Hamkorlar', partner: 'Hamkorlik dasturi', apply: 'Ariza yuborish',
      waiting: 'Arizangiz ko‘rib chiqilmoqda', rejected: 'Ariza rad etildi. Qayta yuborishingiz mumkin.',
      disabled: 'Hamkorlik vaqtincha to‘xtatilgan', clients: 'Mijozlar', available: 'Yechib olish mumkin',
      pending: '24 soat kutmoqda', link: 'Sizning taklif havolangiz', copyLink: 'Havolani nusxalash',
      withdrawal: 'Pul yechish', withdrawalAmount: 'Yechish summasi (kamida 10 000 so‘m)',
      withdrawalDetails: 'Karta yoki telefon raqami', withdrawalSent: 'So‘rov yuborildi',
      insufficient: 'Mablag‘ yetarli emas', invalid: 'Ma’lumotlarni tekshiring', commissions: 'Hisoblangan komissiyalar',
      intro: 'Taklif qilgan mijozlaringizning bajarilgan buyurtmalaridan sof foydaning 50% ini olasiz.',
      minimum: 'Yechish 10 000 so‘mdan', delay: '24 soatdan keyin', openBot: 'Telegram botini ochish',
      waitingCommission: 'Kutilmoqda', availableCommission: 'Hisoblandi', reversedCommission: 'Bekor qilindi',
      popular: 'Eng ommabop', fast: 'Tez va qulay', balance: 'Mavjud balans', topup: 'Hamyonni to‘ldirish',
      payBalance: 'Balansdan to‘lash', paid: 'To‘langan buyurtma adminga yuborildi', walletShort: 'Balansda mablag‘ yetarli emas',
      quoteChanged: 'Narx yangilandi. Buyurtmani qayta oching.'
    },
    ru: {
      sub: 'Игровая валюта и услуги', search: 'Поиск…', clear: 'Очистить поиск',
      all: 'Все', games: 'Игры', services: 'Услуги', filters: 'Фильтры магазина',
      other: 'Другие игры', showAll: 'Все игры', noResults: 'Ничего не найдено',
      loading: 'Загружаем товары…', loadError: 'Не удалось загрузить каталог', retry: 'Повторить',
      quantity: 'Сколько нужно Gold?', select: 'Выберите пакет', game: 'Игровой ID',
      username: 'Имя пользователя', optional: 'Ник или комментарий (необязательно)', example: 'Например, 12345678',
      price: 'Итого', next: 'Продолжить', back: 'Назад', pay: 'Способ оплаты',
      confirm: 'Оформить заказ', copy: 'Скопировать сообщение', contact: 'Написать администратору',
      receipt: 'Отправить чек боту', manual: 'Реквизиты уточните у администратора. После оплаты отправьте чек.',
      market: 'Согласуйте цену скина с администратором и выставьте его ровно по этой цене.',
      created: 'Заказ создан', draft: 'Текст заказа готов', sendBot: 'Отправить боту',
      draftHint: 'Отправьте сообщение администратору, чтобы оформить заказ.',
      delivery: 'Администратор проверит оплату и выполнит заказ.',
      error: 'Не удалось связаться с ботом. Попробуйте ещё раз.', copied: 'Скопировано',
      copyHint: 'Выделите и скопируйте текст', done: 'Готово', terminal: 'Банкомат',
      partners: 'Партнёрам', partner: 'Партнёрская программа', apply: 'Подать заявку',
      waiting: 'Заявка на рассмотрении', rejected: 'Заявка отклонена. Её можно подать снова.',
      disabled: 'Партнёрство приостановлено', clients: 'Клиенты', available: 'Доступно к выводу',
      pending: 'Ожидает 24 часа', link: 'Ваша реферальная ссылка', copyLink: 'Скопировать ссылку',
      withdrawal: 'Вывод средств', withdrawalAmount: 'Сумма вывода (от 10 000 сум)',
      withdrawalDetails: 'Номер карты или телефона', withdrawalSent: 'Заявка отправлена',
      insufficient: 'Недостаточно средств', invalid: 'Проверьте введённые данные', commissions: 'История начислений',
      intro: 'Получайте 50% чистой прибыли с выполненных заказов клиентов, которых вы пригласили.',
      minimum: 'Вывод от 10 000 сум', delay: 'Начисление через 24 часа', openBot: 'Открыть Telegram-бота',
      waitingCommission: 'Ожидает', availableCommission: 'Начислено', reversedCommission: 'Отменено',
      popular: 'Самый популярный', fast: 'Быстро и удобно', balance: 'Доступный баланс', topup: 'Пополнить баланс',
      payBalance: 'Оплатить с баланса', paid: 'Оплаченный заказ передан администратору', walletShort: 'На балансе недостаточно средств',
      quoteChanged: 'Цена обновилась. Откройте заказ заново.'
    }
  };
  const translatedSubtitles = {
    gold_rinok: 'Gold через рынок',
    gold_id: 'Gold по игровому ID',
    spin_coins: 'Валюта для Spin',
    telegram_premium: '1 / 3 / 6 / 12 мес.'
  };
  const cardStyles = {
    gold_rinok: 'gold', gold_id: 'id', gold_pass: 'pass', spin_coins: 'coins'
  };
  const gameArt = new Set(['pubg_mobile', 'mobile_legends', 'brawl_stars', 'roblox']);

  const shopPage = document.querySelector('#donat');
  const content = document.querySelector('#shop-content');
  const search = document.querySelector('#shop-search');
  const clear = document.querySelector('#clear-search');
  const filters = [...document.querySelectorAll('#shop-filters button')];
  const state = { items: [], loading: false, failed: false, category: 'all' };

  const t = key => translations[lang()][key];
  const amount = value => money(value) + ' UZS';
  const optionLabel = value => lang() === 'ru'
    ? value.replace(' oy', ' мес.').replace('(kirishsiz)', '(подарок)')
    : value;
  const subtitle = item => (lang() === 'ru' && translatedSubtitles[item.id]) || item.subtitle;
  const botLink = start => {
    const link = telegramUrl(config.botUrl);
    if (!link) return null;
    link.search = '';
    link.searchParams.set('start', start);
    return link.href;
  };

  function card(item) {
    const cardStyle = cardStyles[item.id] || 'telegram';
    const badge = item.badge ? t(cardStyle === 'gold' ? 'popular' : 'fast') : '';
    const badgeIcon = cardStyle === 'gold'
      ? '<path d="M12 2c1 5 7 7 7 13a7 7 0 1 1-14 0c0-3 1-5 3-7 0 3 1 4 2 4 2-3 2-6 2-10Z"/>'
      : '<path d="M13 2 5 13h6l-1 9 9-12h-6l1-8Z"/>';
    const price = item.id === 'gold_rinok' ? item.per_100 : item.id === 'gold_id' ? item.options[0][2] : null;
    return `
      <button class="product-card ${cardStyle}${badge ? ' with-pill' : ''}" data-product="${escape(item.id)}" type="button">
        ${badge ? `<span class="pill"><svg viewBox="0 0 24 24" aria-hidden="true">${badgeIcon}</svg>${escape(badge)}</span>` : ''}
        <span class="card-label">
          <strong class="card-name">${escape(item.title)}</strong>
          <span class="card-desc">${escape(subtitle(item))}</span>
        </span>
        <span class="card-art reference-art" aria-hidden="true"></span>
        <span class="card-arrow" aria-hidden="true">›</span>
        ${price === null ? '' : `<span class="card-price">100 Gold — ${amount(price)}</span>`}
      </button>`;
  }

  function render() {
    filters.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.category === state.category)));
    if (state.loading) {
      content.innerHTML = `<p class="shop-empty">${t('loading')}</p>`;
      return;
    }
    if (state.failed) {
      content.innerHTML = `<div class="shop-empty">${t('loadError')}<br><button class="show-all" type="button" id="retry-shop">${t('retry')}</button></div>`;
      return;
    }

    const query = search.value.trim().toLowerCase();
    const items = state.items.filter(item => {
      const groupMatches = state.category === 'all' || (state.category === 'games') === (item.group === 'games');
      const title = [item.title, item.subtitle, subtitle(item)].join(' ').toLowerCase();
      return groupMatches && query.split(/\s+/).every(word => title.includes(word));
    });
    const services = items.filter(item => item.group !== 'games');
    const games = items.filter(item => item.group === 'games');
    if (!items.length) {
      content.innerHTML = `<p class="shop-empty">${t('noResults')}</p>`;
      return;
    }

    const gamesMarkup = games.map(item => `
      <button class="game-card" type="button" data-product="${escape(item.id)}">
        ${gameArt.has(item.id)
          ? '<span class="game-art reference-art" aria-hidden="true"></span>'
          : `<img class="game-art" src="${escape(item.image)}" alt="">`}
        <span class="game-name">${escape(item.title)}</span>
      </button>`).join('');
    content.innerHTML = `
      ${services.length ? `<div class="product-grid">${services.map(card).join('')}</div>` : ''}
      ${games.length ? `<h2 class="section-title">${glyph('shop')} ${t('other')}
        ${state.category === 'all' && !query ? `<button type="button" class="show-all" data-category="games">${t('showAll')} →</button>` : ''}
      </h2><div class="game-grid">${gamesMarkup}</div>` : ''}`;
  }

  async function loadCatalog(refresh = false) {
    state.loading = true;
    state.failed = false;
    render();
    try {
      const response = await fetch('assets/donat/catalog.json?v=20261108-categories',refresh?{cache:'reload'}:undefined);
      if (!response.ok) throw new Error('Catalog unavailable');
      const data = await response.json();
      if (!Array.isArray(data.items)) throw new Error('Invalid catalog');
      state.items = data.items;
    } catch {
      state.failed = true;
    } finally {
      state.loading = false;
      render();
    }
  }

  function applyLanguage() {
    document.querySelectorAll('[data-shop-text]').forEach(element => {
      element.textContent = t(element.dataset.shopText);
    });
    search.placeholder = t('search');
    search.setAttribute('aria-label', t('search'));
    clear.setAttribute('aria-label', t('clear'));
    document.querySelector('#shop-filters').setAttribute('aria-label', t('filters'));
    render();
  }

  function quantityValid(order) {
    return Number.isSafeInteger(order.quantity) && order.quantity >= order.item.min && order.quantity <= order.item.max;
  }

  function total(order) {
    return order.item.kind === 'quantity'
      ? Math.ceil(order.quantity * order.item.per_100 / 100)
      : order.item.options.find(option => option[0] === order.option)[2];
  }

  function packageName(order) {
    return order.item.kind === 'quantity'
      ? money(order.quantity) + ' Gold'
      : optionLabel(order.item.options.find(option => option[0] === order.option)[1]);
  }

  function detailValid(order) {
    if (order.item.input === 'game_id') return /^[A-Za-z0-9_#-]{4,40}$/.test(order.detail);
    if (order.item.input === 'username') return /^@?[A-Za-z0-9_.]{3,32}$/.test(order.detail);
    return order.detail.length <= 64 && !/[<>\x00-\x1f]/.test(order.detail);
  }

  function priceSummary(value) {
    return `<div class="price-summary"><span>${t('price')}</span><strong id="selected-price">${amount(value)}</strong></div>`;
  }

  function productSheet(order) {
    const item = order.item;
    const isQuantity = item.kind === 'quantity';
    const choices = isQuantity
      ? `<label for="product-quantity">${t('quantity')} (${money(item.min)}–${money(item.max)})</label>
        <div class="qty">
          <button type="button" data-qty="-100" aria-label="−100 Gold">−</button>
          <input id="product-quantity" type="number" min="${item.min}" max="${item.max}" step="1" inputmode="numeric" value="${order.quantity}">
          <button type="button" data-qty="100" aria-label="+100 Gold">+</button>
        </div>`
      : `<label id="package-label">${t('select')}</label>
        <div class="variant-list" role="group" aria-labelledby="package-label">${item.options.map(([id, name, price]) => `
          <button type="button" class="variant" data-option="${escape(id)}" aria-pressed="${order.option === id}">
            <span>${escape(optionLabel(name))}</span><strong>${amount(price)}</strong>
          </button>`).join('')}</div>`;
    const label = t({ game_id: 'game', username: 'username', optional: 'optional' }[item.input]);
    const example = item.input === 'username' ? (item.id === 'roblox' ? 'Username' : '@username') : t('example');
    openSheet(item.title, `
      <p>${escape(subtitle(item))}</p>${choices}
      <label for="product-detail">${escape(label)}</label>
      <input id="product-detail" maxlength="64" placeholder="${escape(example)}" value="${escape(order.detail)}" autocomplete="off">
      ${priceSummary(total(order))}
      ${isQuantity ? `<p class="notice">${t('market')}</p>` : ''}
      <button class="action" type="button" id="product-next">${t('next')} →</button>`);

    const quantity = sheetBody.querySelector('#product-quantity');
    const detail = sheetBody.querySelector('#product-detail');
    const price = sheetBody.querySelector('#selected-price');
    const next = sheetBody.querySelector('#product-next');
    const update = () => {
      if (quantity) order.quantity = quantity.valueAsNumber;
      order.detail = detail.value.trim();
      const validQuantity = !isQuantity || quantityValid(order);
      price.textContent = validQuantity ? amount(total(order)) : '—';
      next.disabled = !validQuantity || !detailValid(order);
    };

    quantity?.addEventListener('input', update);
    detail.addEventListener('input', update);
    const options = [...sheetBody.querySelectorAll('[data-option]')];
    options.forEach(button => {
      button.onclick = () => {
        order.option = button.dataset.option;
        options.forEach(option => option.setAttribute('aria-pressed', String(button === option)));
        update();
      };
    });
    sheetBody.querySelectorAll('[data-qty]').forEach(button => {
      button.onclick = () => {
        const current = quantity.valueAsNumber || item.min;
        quantity.value = Math.max(item.min, Math.min(item.max, current + Number(button.dataset.qty)));
        update();
      };
    });
    next.onclick = () => paymentSheet(order);
    update();
  }

  function paymentSheet(order) {
    const ru=lang()==='ru';
    const balance=walletBalance(), enough=balance>=total(order);
    openSheet(t('pay'),`
      <p><strong>${escape(order.item.title)}</strong> · ${escape(packageName(order))}</p>
      ${priceSummary(total(order))}
      <p>${escape(t('balance'))} · ${amount(balance)}</p>
      ${canTransfer() ? `<button class="action" type="button" id="donat-uzcard">${ru?'Перевод на UZCARD':'UZCARD orqali o‘tkazma'}</button>` : ''}
      <button class="action" type="button" id="submit-order" ${!connected()||!enough?'disabled':''}>${escape(t('payBalance'))}</button>
      ${enough?'':`<button class="secondary" type="button" id="donat-topup">${escape(t('topup'))}</button>`}
      <button class="secondary" type="button" id="order-help">${ru?'Отправить заявку админу':'Adminga ariza yuborish'}</button>
      <button class="secondary" type="button" id="back-product">← ${t('back')}</button>`);
    const submit=sheetBody.querySelector('#submit-order');
    const help=sheetBody.querySelector('#order-help');
    submit.onclick=()=>submitOrder(order,submit);
    sheetBody.querySelector('#donat-uzcard')?.addEventListener('click', event => requestTransfer('donat/create',
      {...orderPayload(order,undefined,'uzcard'),expectedAmount:total(order)}, event.currentTarget, () => paymentSheet(order)));
    sheetBody.querySelector('#donat-topup')?.addEventListener('click',()=>openTopup(()=>paymentSheet(order)));
    help.onclick=()=>openOrderHelp(
      reason=>api('order-help',{...orderPayload(order,reason),kind:'donat',reason}),
      ()=>paymentSheet(order),
      [
        'ARSLAN BOOST · Donat Shop', `${order.item.title} · ${packageName(order)}`,
        order.detail, `${t('price')}: ${amount(total(order))}`
      ].filter(Boolean).join('\n'));
    sheetBody.querySelector('#back-product').onclick=()=>productSheet(order);
  }

  function orderPayload(order, helpReason, paymentMethod = 'balance') {
    const fields = {
      product: order.item.id,
      quantity: order.item.kind === 'quantity' ? order.quantity : undefined,
      option: order.option,
      detail: order.detail,
      paymentMethod
    };
    const key = JSON.stringify({...fields, helpReason});
    if (!order.requests.has(key)) {
      const bytes = crypto.getRandomValues(new Uint8Array(16));
      order.requests.set(key, Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join(''));
    }
    return { ...fields, lang: lang(), requestId: order.requests.get(key) };
  }

  async function copy(value) {
    try {
      await navigator.clipboard.writeText(value);
      toast(t('copied'));
    } catch {
      const field = document.createElement('textarea');
      field.value = value;
      field.readOnly = true;
      field.setAttribute('aria-label', t('copy'));
      sheetBody.append(field);
      field.focus();
      field.select();
      toast(t('copyHint'));
    }
  }

  async function submitOrder(order,submit) {
    if(submit.disabled)return;
    submit.disabled=true;
    try {
      await api('donat/create',{...orderPayload(order),expectedAmount:total(order)});
      await syncState();
      if(!submit.isConnected)return;
      showHistory();
      toast(t('paid'));
    } catch(error) {
      if(error.message==='insufficient_balance') {
        await syncState();
        if(submit.isConnected)paymentSheet(order);
        toast(t('walletShort'));
      } else if(error.message==='order_quote_changed'&&submit.isConnected) {
        closeSheet();
        loadCatalog(true);
        toast(t('quoteChanged'));
      } else if(submit.isConnected)toast(t('error'));
    } finally {submit.disabled=false;}
  }

  function partnerStats(data) {
    const statuses = {
      pending: t('waitingCommission'), available: t('availableCommission'), reversed: t('reversedCommission')
    };
    const history = (data.history || []).map(row => `
      <div class="partner-stat">
        <span>${row.kind === 'donat' ? 'Donat Shop' : 'Boost'} #${escape(row.orderId)} · ${escape(statuses[row.status] || row.status)}</span>
        <strong>${amount(row.commission)}</strong>
      </div>`).join('');
    return `
      <div class="partner-stats">
        <div class="partner-stat"><span>${t('clients')}</span><strong>${money(data.clients)}</strong></div>
        <div class="partner-stat"><span>${t('available')}</span><strong>${amount(data.available)}</strong></div>
        <div class="partner-stat"><span>${t('pending')}</span><strong>${amount(data.pending)}</strong></div>
      </div>
      ${data.url ? `<label for="partner-link">${t('link')}</label>
        <input id="partner-link" type="url" value="${escape(data.url)}" readonly>
        <button id="partner-copy" class="action" type="button">${t('copyLink')}</button>` : ''}
      <h3>${t('withdrawal')}</h3>
      <label for="partner-amount">${t('withdrawalAmount')}</label>
      <input id="partner-amount" type="number" min="10000" max="${Number(data.available)}" step="1" inputmode="numeric" placeholder="10000">
      <label for="partner-destination">${t('withdrawalDetails')}</label>
      <input id="partner-destination" maxlength="120" placeholder="+998…" autocomplete="off">
      <button class="secondary" id="partner-withdraw" type="button" ${data.available < 10000 ? 'disabled' : ''}>${t('apply')}</button>
      ${history ? `<h3>${t('commissions')}</h3><div class="partner-stats">${history}</div>` : ''}`;
  }

  async function openPartners() {
    const intro = `<p>${t('intro')}</p><div class="partner-facts">
      <span>50%</span><span>${t('delay')}</span><span>${t('minimum')}</span></div>`;
    const openInBot = () => {
      const link = botLink('partner');
      openSheet(t('partner'), intro + `<button class="action" type="button" id="partner-openbot"${link ? '' : ' disabled'}>${t('openBot')}</button>`);
      sheetBody.querySelector('#partner-openbot').onclick = () => openTelegram(link);
    };
    if (!connected()) {
      openInBot();
      return;
    }

    openSheet(t('partner'), intro + '<div id="partner-loading" aria-busy="true"></div>');
    const loading = sheetBody.querySelector('#partner-loading');
    try {
      const data = await api('referral/me');
      if (!loading.isConnected) return;
      if (data.status === 'pending' || data.status === 'suspended') {
        openSheet(t('partner'), intro + `<p class="notice">${t(data.status === 'pending' ? 'waiting' : 'disabled')}</p>`);
        return;
      }
      if (data.status === 'none' || data.status === 'rejected') {
        openSheet(t('partner'), intro + `
          ${data.status === 'rejected' ? `<p class="notice">${t('rejected')}</p>` : ''}
          <button class="action" type="button" id="partner-apply">${t('apply')}</button>`);
        const apply = sheetBody.querySelector('#partner-apply');
        apply.onclick = () => partnerRequest(apply, 'referral/apply', {});
        return;
      }
      openSheet(t('partner'), intro + partnerStats(data));
      const copyLink = sheetBody.querySelector('#partner-copy');
      if (copyLink) copyLink.onclick = () => copy(data.url);
      const withdraw = sheetBody.querySelector('#partner-withdraw');
      withdraw.onclick = () => {
        const amount = sheetBody.querySelector('#partner-amount').valueAsNumber;
        const destination = sheetBody.querySelector('#partner-destination').value.trim();
        if (!Number.isSafeInteger(amount) || amount < 10000 || amount > data.available || destination.length < 5) {
          toast(t('invalid'));
          return;
        }
        partnerRequest(withdraw, 'referral/withdraw', { amount, destination });
      };
    } catch (error) {
      if (!loading.isConnected) return;
      if (error.message === 'endpoint_missing') openInBot();
      else openSheet(t('partner'), intro + `<p class="notice">${t('error')}</p>`);
    }
  }

  async function partnerRequest(button, path, fields) {
    button.disabled = true;
    try {
      await api(path, fields);
      if (button.isConnected) {
        if (path === 'referral/withdraw') toast(t('withdrawalSent'));
        await openPartners();
      }
    } catch (error) {
      if (button.isConnected) {
        toast(t(error.message === 'insufficient_referral_balance' ? 'insufficient' : 'error'));
        button.disabled = false;
      }
    }
  }

  shopPage.addEventListener('click', event => {
    const button = event.target.closest('button');
    if (!button) return;
    if (button.dataset.category) {
      state.category = button.dataset.category;
      render();
      if (!button.isConnected) filters.find(filter => filter.dataset.category === state.category)?.focus();
    }
    if (button.dataset.product) {
      const item = state.items.find(product => product.id === button.dataset.product);
      if (item) productSheet({
        item, quantity: item.min, option: item.options?.[0]?.[0],
        detail: '', requests: new Map()
      });
    }
    if (button.id === 'retry-shop') loadCatalog();
  });
  search.addEventListener('input', () => {
    clear.hidden = !search.value;
    render();
  });
  clear.onclick = () => {
    search.value = '';
    clear.hidden = true;
    search.focus();
    render();
  };
  loadCatalog();

  return {
    applyLanguage,
    openPartners,
    optionLabel,
    productTitle: id => state.items.find(product => product.id === id)?.title || id
  };
};

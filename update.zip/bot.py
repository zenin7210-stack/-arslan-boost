"""Arslan Boost bot and authenticated Mini App API. Run: python bot.py."""
import asyncio
import base64
import json
import html
import logging
import os
import re
from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlsplit, quote

from aiohttp import web
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (CallbackQuery, Message, InlineKeyboardButton, InlineKeyboardMarkup,
                           FSInputFile, LabeledPrice, PreCheckoutQuery, WebAppInfo,
                           InputMediaPhoto, BusinessConnection, ForceReply)
from dotenv import load_dotenv
from referrals import Referrals
from service import (Store, ValidationError, RANKS, PRICES, MODES, integer, validate_init_data,
                     player_name, payment_tag, PAYMENT_TAGS, boost_amount,
                     CALIBRATION_LEGEND_PRICE, BOOST_MODE_SURCHARGE, MIN_BOOST_PRICE,
                     TEST_PROVIDERS, MAX_TOPUP_AMOUNT)

BASE = Path(__file__).resolve().parent
load_dotenv(BASE / '.env')
TOKEN = os.getenv('BOT_TOKEN', '')
ADMIN_ID = int(os.getenv('ADMIN_ID') or 0)
ADMIN_USERNAME = os.getenv('ADMIN_USERNAME', '').lstrip('@').strip()
APP_URL = os.getenv('MINIAPP_URL', '').strip()
BOT_USERNAME = os.getenv('BOT_USERNAME', '').lstrip('@').strip()
CARDS = {key: os.getenv(key.upper(), '').strip() for key in ('humo', 'uzcard')}
CARD_HOLDER=os.getenv('CARD_HOLDER','').strip()
UZCARD_TEST_MODE = os.getenv('UZCARD_TEST_MODE') == '1'
UZCARD_NUMBER = re.sub(r'[ -]', '', CARDS['uzcard'])
TEST_USERS = set()
db_path = Path(os.getenv('DB_PATH') or BASE / 'orders.sqlite3').resolve()
if UZCARD_TEST_MODE:
    if not ADMIN_ID or not re.fullmatch(r'[0-9]{16}', UZCARD_NUMBER) or not CARD_HOLDER:
        raise RuntimeError('Для закрытого теста задайте ADMIN_ID, UZCARD и CARD_HOLDER.')
    TEST_USERS = {ADMIN_ID} | {
        integer(value, 1, 2**63 - 1) for value in os.getenv('UZCARD_TEST_USERS', '').split()
    }
    test_path = Path(os.getenv('UZCARD_TEST_DB_PATH') or BASE / 'uzcard-test.sqlite3').resolve()
    if test_path == db_path:
        raise RuntimeError('Укажите отдельную базу данных для теста UZCARD.')
    db_path = test_path
STARS_TERMS_URL = os.getenv('STARS_TERMS_URL', '').strip()
TEST_PROVIDER_TOKENS = {}
for method in TEST_PROVIDERS:
    provider_token = os.getenv(f'{method.upper()}_PROVIDER_TEST_TOKEN', '').strip()
    if re.fullmatch(r'[0-9]+:TEST:[^\s:]+', provider_token):
        TEST_PROVIDER_TOKENS[method] = provider_token
if not re.fullmatch(r'https://[^\s<>]+', STARS_TERMS_URL):
    STARS_TERMS_URL = ''
store = Store(db_path, 0 if UZCARD_TEST_MODE else os.getenv('STARS_RATE_UZS') or 0,
              transfer_test=UZCARD_TEST_MODE)
referrals = Referrals(store)
dp = Dispatcher()
admin_notice_lock = asyncio.Lock()


class Flow(StatesGroup):
    game_id = State()
    receipt = State()
    donat_receipt = State()


TEXT = {
 'ru': {
  'welcome':'🔷 <b>Arslan Boost</b>\n\n🎮 Выберите режим:', 'mode':'Выберите режим:',
  'from':'Выберите текущий ранг:', 'to':'Выберите желаемый ранг:', 'game_id':'🆔 Отправьте игровой ID или ник:',
  'invalid':'Проверьте данные и попробуйте ещё раз. /start — начать заново.',
  'pay':'💳 Выберите способ оплаты:', 'open':'Открыть Mini App',
  'humo':'HUMO', 'uzcard':'UZCARD', 'terminal':'Банкомат / терминал', 'stars':'Telegram Stars', 'balance':'С баланса',
  'amount':'Сумма', 'currency':'сум', 'order':'Заказ', 'topup':'Пополнение баланса', 'id':'Игровой ID',
  'calculation':'Расчёт', 'payment_method':'Способ оплаты',
  'receipt':'После оплаты отправьте сюда фото или файл чека. Зачисление произойдёт только после подтверждения.',
  'no_card':'Реквизиты и условия оплаты уточните у администратора.', 'contact':'👤 Написать администратору',
  'receipt_saved':'Чек передан администратору. Ожидайте проверки.', 'wrong_receipt':'Отправьте фото или файл чека.',
  'paid':'✅ Оплата подтверждена. Заказ передан администратору.', 'credited':'✅ Оплата подтверждена. Баланс пополнен.',
  'rejected':'Оплата отклонена. Уточните причину у администратора.', 'already':'Платёж уже обработан.',
  'no_access':'Нет доступа', 'insufficient_balance':'На балансе недостаточно средств. Выберите другой способ оплаты.',
  'stars_not_configured':'Владелец ещё не настроил цену в Stars. Обратитесь к администратору.',
  'support':'По вопросам заказа и оплаты обратитесь к администратору.', 'calibration':'Калибровка',
  'balance_info':'Баланс', 'request':'Хочу оформить заказ. Подскажите условия оплаты.',
  'invoice':'Arslan Boost', 'invoice_desc':'Оплата заказа повышения ранга Standoff 2', 'invoice_topup':'Пополнение баланса Arslan Boost',
  'invalid_payment':'Платёж не прошёл проверку. Откройте новый счёт.', 'saved':'Сохранено',
 },
 'uz': {
  'welcome':'🔷 <b>Arslan Boost</b>\n\n🎮 Rejimni tanlang:', 'mode':'Rejimni tanlang:',
  'from':'Hozirgi rankingizni tanlang:', 'to':'Maqsad rankni tanlang:', 'game_id':'🆔 O‘yin ID yoki nickni yuboring:',
  'invalid':'Ma’lumotlarni tekshirib, qayta urinib ko‘ring. /start — qaytadan boshlash.',
  'pay':'💳 To‘lov usulini tanlang:', 'open':'Mini App’ni ochish',
  'humo':'HUMO', 'uzcard':'UZCARD', 'terminal':'Bankomat / terminal', 'stars':'Telegram Stars', 'balance':'Balansdan',
  'amount':'Summa', 'currency':'so‘m', 'order':'Buyurtma', 'topup':'Balansni to‘ldirish', 'id':'O‘yin ID',
  'calculation':'Hisob', 'payment_method':'To‘lov usuli',
  'receipt':'To‘lovdan keyin chek rasmini yoki faylini shu yerga yuboring. Mablag‘ tasdiqlangandan keyin hisoblanadi.',
  'no_card':'Rekvizit va to‘lov shartlarini administratordan oling.', 'contact':'👤 Administratorga yozish',
  'receipt_saved':'Chek administratorga yuborildi. Tekshiruvni kuting.', 'wrong_receipt':'Chekni rasm yoki fayl sifatida yuboring.',
  'paid':'✅ To‘lov tasdiqlandi. Buyurtma administratorga yuborildi.', 'credited':'✅ To‘lov tasdiqlandi. Balans to‘ldirildi.',
  'rejected':'To‘lov rad etildi. Sababini administratordan bilib oling.', 'already':'To‘lov allaqachon ko‘rib chiqilgan.',
  'no_access':'Ruxsat yo‘q', 'insufficient_balance':'Balansda mablag‘ yetarli emas. Boshqa to‘lov usulini tanlang.',
  'stars_not_configured':'Stars narxi hali belgilanmagan. Administratorga murojaat qiling.',
  'support':'Buyurtma va to‘lov bo‘yicha administratorga murojaat qiling.', 'calibration':'Kalibrovka',
  'balance_info':'Balans', 'request':'Buyurtma bermoqchiman. To‘lov shartlarini yuboring.',
  'invoice':'Arslan Boost', 'invoice_desc':'Standoff 2 rank oshirish buyurtmasi uchun to‘lov', 'invoice_topup':'Arslan Boost balansini to‘ldirish',
  'invalid_payment':'To‘lov tekshiruvdan o‘tmadi. Yangi hisob oching.', 'saved':'Saqlandi',
 }
}


def text(key, lang='uz'):
    return TEXT['ru' if lang == 'ru' else 'uz'].get(key, TEXT['uz']['invalid'])


def language(user):
    return 'ru' if getattr(user, 'language_code', '') == 'ru' else 'uz'


def user_data(user):
    return {'id': user.id, 'username': user.username or ''}


def fmt(amount):
    return f'{amount:,}'.replace(',', ' ')


def rank_name(index, lang='uz'):
    if index == 0:
        return 'Калибровка' if lang == 'ru' else 'Kalibrovka'
    return ('Kalibrovka', 'Bronza', 'Silver', 'Gold', 'Phoenix', 'Ranger',
            'Champion', 'Master', 'Elite', 'The Legend')[index]


def single(items):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=label, callback_data=payload)] for label, payload in items])


def admin_link(message=''):
    if not re.fullmatch(r'[a-zA-Z0-9_]{3,32}', ADMIN_USERNAME):
        return None
    return 'https://t.me/' + ADMIN_USERNAME + ('?text=' + quote(message, safe='') if message else '')


def contact_markup(lang='uz', message=''):
    url = admin_link(message)
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text=text('contact', lang), url=url)]]) if url else None


def modes_markup(lang='uz'):
    labels = {'wing':'Напарник','comp':'Сорев','duel':'Дуэль'} if lang=='ru' else {'wing':'Naparnik','comp':'Сорев','duel':'Duel'}
    return single([(label, 'mode:' + mode) for mode, label in labels.items()])


def payment_markup(lang):
    return single([(text('balance', lang), 'pay:balance')])


def summary(order, lang='uz'):
    modes = {'wing': 'Naparnik', 'comp': 'Сорев', 'duel': 'Duel'}
    return (f'Assalomu alaykum! Boost buyurtma bermoqchiman.\n'
            f'Rejim: {modes[order["mode"]]}\n'
            f'ID: {order["game_id"]}\n'
            f'{rank_name(order["current_rank"],"uz")} → {rank_name(order["target_rank"],"uz")}\n'
            f'Narx = {fmt(order["amount"])} so‘m')


def parse_deep_link(payload):
    if not payload.startswith('ab_') or len(payload) > 64:
        raise ValidationError('invalid_request')
    try:
        raw = payload[3:]
        parts = base64.urlsafe_b64decode(raw + '=' * (-len(raw) % 4)).decode('utf-8').split(',',7)
        method = {'h':'humo','u':'uzcard','t':'terminal','s':'stars','b':'balance'}
        if parts[0] == 'o' and len(parts) == 8:
            return 'order', {'mode':{'w':'wing','c':'comp','d':'duel'}[parts[1]],
                'fromIndex':parts[2], 'toIndex':parts[3], 'paymentMethod':method[parts[4]],
                'lang':'ru' if parts[5]=='r' else 'uz','gameId':parts[7], 'requestId':parts[6]}
        if parts[0] == 't' and len(parts) == 5:
            return 'topup', {'amount':parts[1], 'paymentMethod':method[parts[2]],
                'lang':'ru' if parts[3]=='r' else 'uz', 'requestId':parts[4]}
    except (ValueError, KeyError, UnicodeDecodeError, IndexError) as exc:
        raise ValidationError('invalid_request') from exc
    raise ValidationError('invalid_request')


async def notify_admin(bot, payment, paid=False):
    if not ADMIN_ID:
        return False
    if payment['order_id']:
        with store.connect() as con:
            order = dict(con.execute('SELECT * FROM orders WHERE id=?', (payment['order_id'],)).fetchone())
        message = f'🎮 Boost #{order["id"]}\n' + summary(order, 'ru')
    elif payment['donat_order_id']:
        from donat_catalog import PRODUCTS
        order = store.donat_order(payment['donat_order_id'])
        product = PRODUCTS.get(order['product'], {}).get('title', order['product'])
        message = (f'🛒 Donat Shop #{order["id"]}\n{product} · {order["option_label"]}\n'
                   f'Данные: {order["detail"]}\n💰 {fmt(order["amount"])} UZS')
    else:
        message = f'Пополнение #{payment["id"]}\n💰 {fmt(payment["amount"])} сум\n💳 {payment["method"].upper()}'
    username = order['username'] if payment['order_id'] or payment['donat_order_id'] else ''
    if username:
        username = ' · @' + username
    message += (f'\n👤 Telegram ID: {payment["user_id"]}{username}'
                f'\n💳 Платёж #{payment["id"]} · {payment["method"].upper()}\n'
                + ('✅ Оплата подтверждена' if paid else '⏳ Ожидает проверки'))
    if UZCARD_TEST_MODE:
        message = '🧪 Тестовая заявка\n\n' + message
    markup = None
    if not paid and payment['receipt_file_id']:
        approve = '✅ Подтвердить и взять в работу' if UZCARD_TEST_MODE and payment['kind'] != 'topup' else '✅ Подтвердить оплату'
        markup = single([(approve, f'approve:{payment["id"]}'),
                         ('❌ Отклонить', f'reject:{payment["id"]}')])
    if paid and payment['order_id']:
        markup = single([('▶ В работу', f'boost_work:{payment["order_id"]}')])
    try:
        if not paid and payment['receipt_file_id']:
            if payment['receipt_type'] == 'photo':
                await bot.send_photo(ADMIN_ID, payment['receipt_file_id'], caption=message, reply_markup=markup)
            else:
                await bot.send_document(ADMIN_ID, payment['receipt_file_id'], caption=message, reply_markup=markup)
        else:
            await bot.send_message(ADMIN_ID, message, reply_markup=markup)
    except Exception:
        logging.exception('Could not notify the configured admin')
        return False
    return True


async def notify_pending_payment(bot, payment_id):
    async with admin_notice_lock:
        payment = store.payment(payment_id)
        if payment['admin_notice_pending'] and await notify_admin(bot, payment, paid=payment['status']=='paid'):
            store.mark_admin_notified(payment_id)


def invoice_args(payment, lang='uz'):
    if payment['kind'] == 'provider_test':
        method = payment['method']
        return dict(title=f'{method.upper()} TEST',
                    description='Тестовый счёт' if lang == 'ru' else 'Sinov hisobi',
                    payload=f'ab:{payment["id"]}', provider_token=TEST_PROVIDER_TOKENS[method],
                    currency='UZS', prices=[LabeledPrice(label='TEST', amount=payment['amount'] * 100)])
    return dict(title=text('invoice',lang), description=text('invoice_topup' if payment['kind']=='topup' else 'invoice_desc',lang),
                payload=f'ab:{payment["id"]}', provider_token='', currency='XTR',
                prices=[LabeledPrice(label=text('amount',lang), amount=payment['stars'])])


async def deliver_payment(message, bot, state, payment, lang='uz', order=None, new=True):
    await state.update_data(payment_id=payment['id'], lang=lang)
    if payment['method'] == 'balance':
        await notify_pending_payment(bot, payment['id'])
    elif new:
        await notify_admin(bot, payment, payment['status']=='paid')
    if payment['status'] == 'paid':
        if payment['kind']=='order':await notify_partner_paid(bot,'boost',payment['order_id'])
        await state.clear()
        return await message.answer(text('credited' if payment['kind']=='topup' else 'paid', lang))
    if payment['method'] == 'stars':
        await state.set_state(None)
        return await bot.send_invoice(chat_id=message.chat.id, **invoice_args(payment,lang), start_parameter=f'pay_{payment["id"]}')
    await state.set_state(Flow.receipt)
    description = summary(order,lang) if order else f'{text("topup",lang)} #{payment["id"]}\n💰 {fmt(payment["amount"])} {text("currency",lang)}'
    card = CARDS.get(payment['method'])
    description += '\n\n' + (f'{payment["method"].upper()}: {card}' if card else text('no_card',lang))
    description += '\n\n' + text('receipt',lang)
    draft = (summary(order,lang) if order else description) + '\n\n' + PAYMENT_TAGS[payment['method']]
    await message.answer(description, reply_markup=contact_markup(lang,draft))


connections={}


@dp.business_connection()
async def business_connection(connection:BusinessConnection):
    connections[connection.id]=connection


@dp.business_message(F.text)
async def business_auto_reply(message:Message,bot:Bot):
    """Reply only in explicitly connected admin business chats, with configured details."""
    if not ADMIN_ID or os.getenv('BUSINESS_AUTOREPLY','1')!='1' or not message.business_connection_id:
        return
    method=payment_tag(message.text)
    if not method or not message.from_user or message.from_user.id==ADMIN_ID or message.from_user.is_bot:
        return
    if method != 'stars' and message.from_user.id not in TEST_USERS:
        return
    connection=connections.get(message.business_connection_id)
    if connection is None:
        connection=await bot.get_business_connection(message.business_connection_id)
        connections[connection.id]=connection
    if (connection.user.id!=ADMIN_ID or not connection.is_enabled
            or not connection.rights or not connection.rights.can_reply):
        return
    if method in ('humo','uzcard'):
        card=CARDS.get(method)
        if not card:
            return
        reply=f'💳 <b>{method.upper()} orqali to‘lov</b>\n\n<code>{html.escape(card)}</code>'
        if CARD_HOLDER:
            reply+='\n👤 '+html.escape(CARD_HOLDER)
        reply+='\n\nTo‘lovdan so‘ng chekni shu chatga yuboring.'
    elif method=='terminal':
        instructions=os.getenv('TERMINAL_INSTRUCTIONS','').strip()
        if not instructions:
            return
        reply='🏧 <b>Terminal / Bankomat</b>\n\n'+html.escape(instructions)
    else:
        if not BOT_USERNAME:
            return
        reply='⭐️ Telegram Stars orqali to‘lov uchun botda hisobni oching:\nhttps://t.me/'+BOT_USERNAME
    if not store.claim_business_reply(message.business_connection_id,message.chat.id,message.message_id):
        return
    try:
        await bot.send_message(message.chat.id,reply,parse_mode='HTML',business_connection_id=message.business_connection_id)
    except Exception:
        store.release_business_reply(message.business_connection_id,message.chat.id,message.message_id)
        logging.exception('Could not send business payment details')


@dp.message(CommandStart())
async def start(message: Message, state: FSMContext, bot: Bot):
    await state.clear()
    if UZCARD_TEST_MODE and message.from_user.id not in TEST_USERS:
        return await message.answer('Mini-ilova yopiq sinovda. / Mini App проходит закрытый тест.')
    lang = store.profile(message.from_user.id)['lang']
    payload = (message.text or '').split(maxsplit=1)
    if len(payload) == 2 and re.fullmatch(r'check_[0-9]{1,18}', payload[1]):
        if message.chat.type != 'private' or message.from_user.id not in TEST_USERS:
            return
        try:
            payment = store.payment(payment_id=int(payload[1][6:]))
            if payment['user_id'] != message.from_user.id or payment['method'] != 'uzcard':
                raise ValidationError('payment_not_found')
        except ValidationError:
            return await message.answer(text('invalid', lang))
        if payment['status'] != 'pending':
            return await message.answer(text('already', lang))
        if payment['receipt_file_id']:
            await notify_pending_payment(bot, payment['id'])
            return await message.answer(text('receipt_saved', lang))
        hint = ('Ответьте на это сообщение фото тестового чека или PDF. Перевод не требуется.'
                if lang == 'ru' else 'Shu xabarga javoban sinov cheki rasmini yoki PDF faylini yuboring. Pul o‘tkazish shart emas.')
        return await message.answer(f'🧾 UZCARD #{payment["id"]}\n'
                                    f'{fmt(payment["amount"])} {text("currency",lang)}\n\n{hint}',
                                    reply_markup=ForceReply(force_reply=True))
    if len(payload) == 2 and payload[1] == 'partner':
        await partner_command(message, bot)
        return
    if len(payload)==2 and payload[1].startswith('ref_'):
        code=payload[1][4:]
        success=referrals.bind(message.from_user.id,code)
        await message.answer('✅ Hamkor havolasi saqlandi. / Партнёрская ссылка учтена.' if success
                             else 'Havola allaqachon biriktirilgan yoki noto‘g‘ri. / Ссылка уже привязана либо недействительна.')
        # Continue regular /start so the buyer can reach the same shop.
    if len(payload)==2 and re.fullmatch(r'ds_[0-9]{1,18}',payload[1]):
        try:
            order_id=int(payload[1][3:]);order=store.donat_order(order_id,message.from_user.id)
        except ValidationError:
            await message.answer('Buyurtma topilmadi / Заказ не найден.');return
        if order['method'] == 'stars' or order['status'] in ('paid','rejected','fulfilled'):
            await message.answer('Buyurtma holati / Статус заказа: '+order['status']);return
        await state.set_state(Flow.donat_receipt)
        await state.update_data(donat_order_id=order_id,lang=order['lang'])
        await message.answer('🧾 Donat Shop — #'+str(order_id)+'\n'+html.escape(order['product'])+' · '+html.escape(order['option_label'])+
            '\n'+fmt(order['amount'])+' UZS\n\nTo‘lov rekvizitlarini admin @khblyv dan oling. To‘lovdan SO‘NG chek rasmini shu yerga yuboring.\n'
            'Реквизиты уточните у администратора @khblyv. После оплаты отправьте сюда чек.\n'
            'Оплата будет подтверждена только после проверки администратором.')
        return
    if len(payload) == 2 and payload[1].startswith('ab_'):
        try:
            kind, data = parse_deep_link(payload[1]); lang = data['lang']
            if kind != 'order' or data.get('paymentMethod') != 'balance':
                raise ValidationError('invalid_payment_method')
            order, new = store.create_order(user_data(message.from_user), data)
            if new: referrals.track_order('boost',order['id'])
            payment = store.payment(order_id=order['id'])
            await deliver_payment(message,bot,state,payment,lang,order,new)
        except ValidationError as exc:
            await message.answer(text(str(exc),lang))
        return
    await state.update_data(lang=lang)
    if APP_URL and message.chat.type == 'private':
        app_url = urlsplit(APP_URL)
        query = dict(parse_qsl(app_url.query, keep_blank_values=True))
        query['section'] = 'donat'
        shop_url = app_url._replace(query=urlencode(query)).geturl()
        keyboard=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=text('open', lang),web_app=WebAppInfo(url=APP_URL))],
            [InlineKeyboardButton(text='Donat Shop',web_app=WebAppInfo(url=shop_url))]
        ])
        await message.answer('Arslan Boost', reply_markup=keyboard)
    caption='🤖 Assalomu alaykum! Arslan Boost botiga xush kelibsiz!\n\n🎮 Standoff 2 rank oshirish xizmati.\n\n👇 Tilni tanlang / Выберите язык:'
    markup=InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text='🇺🇿 O‘zbekcha',callback_data='setlang:uz'),
        InlineKeyboardButton(text='🇷🇺 Русский',callback_data='setlang:ru')]])
    await message.answer_photo(banner_media(lang),caption=caption,reply_markup=markup)


def banner_media(lang):
    configured=os.getenv('BANNER_FILE_ID_'+lang.upper()) or os.getenv('BANNER_URL_'+lang.upper())
    return configured or FSInputFile(BASE/'assets/hero-banner-hd.png')


@dp.callback_query(F.data.startswith('setlang:'))
async def choose_language(call:CallbackQuery,state:FSMContext):
    lang=call.data.split(':',1)[1]
    if lang not in ('ru','uz'):
        return await call.answer()
    store.profile(call.from_user.id,lang=lang);await state.update_data(lang=lang)
    caption=text('welcome',lang)
    if call.message.caption!=caption:
        await call.message.edit_media(InputMediaPhoto(media=banner_media(lang),caption=caption,parse_mode='HTML'))
    await call.message.answer(text('mode',lang),reply_markup=modes_markup(lang));await call.answer()


@dp.callback_query(F.data.startswith('access:'))
async def legacy_access(call: CallbackQuery, state: FSMContext):
    # Old inline buttons go directly to modes; the removed surcharge stays removed.
    lang=language(call.from_user);await state.update_data(lang=lang)
    await call.message.answer(text('mode',lang),reply_markup=modes_markup(lang)); await call.answer()


@dp.callback_query(F.data.startswith('mode:'))
async def choose_mode(call: CallbackQuery, state: FSMContext):
    mode=call.data.split(':',1)[1]
    if mode not in MODES:
        return await call.answer(text('invalid',language(call.from_user)),show_alert=True)
    data=await state.get_data();lang=data.get('lang',language(call.from_user))
    await state.clear();await state.update_data(mode=mode,lang=lang)
    markup=single([(rank_name(i,lang),f'from:{i}') for i in range(len(RANKS)-1)])
    image=BASE/'assets/ranks.webp'
    if image.is_file():
        await call.message.answer_photo(FSInputFile(image),caption=text('from',lang),reply_markup=markup)
    else:
        await call.message.answer(text('from',lang),reply_markup=markup)
    await call.answer()


@dp.callback_query(F.data.startswith('from:'))
async def choose_from(call: CallbackQuery, state: FSMContext):
    data=await state.get_data();lang=data.get('lang',language(call.from_user))
    try:
        index=integer(call.data.split(':',1)[1],0,len(RANKS)-2)
        if data.get('mode') not in MODES:
            raise ValidationError('invalid')
    except ValidationError:
        return await call.answer(text('invalid',lang),show_alert=True)
    await state.update_data(start=index)
    await call.message.answer(text('to',lang),reply_markup=single([(rank_name(i,lang),f'to:{i}') for i in range(index+1,len(RANKS))]));await call.answer()


@dp.callback_query(F.data.startswith('to:'))
async def choose_to(call: CallbackQuery, state: FSMContext):
    data=await state.get_data();lang=data.get('lang',language(call.from_user))
    try:
        index=integer(call.data.split(':',1)[1],1,len(RANKS)-1)
        if 'start' not in data or index<=data['start'] or data.get('mode') not in MODES:
            raise ValidationError('invalid')
    except ValidationError:
        return await call.answer(text('invalid',lang),show_alert=True)
    await state.update_data(end=index);await state.set_state(Flow.game_id)
    await call.message.answer(text('game_id',lang));await call.answer()


@dp.message(Flow.game_id,F.text,~F.text.startswith('/'))
async def receive_id(message: Message, state: FSMContext):
    data=await state.get_data();lang=data.get('lang','uz'); game_id=(message.text or '').strip()
    try:
        game_id=player_name(game_id)
    except ValidationError:
        return await message.answer(text('game_id',lang))
    store.profile(message.from_user.id,game_id=game_id,lang=lang)
    await state.update_data(game_id=game_id);await state.set_state(None)
    amount=boost_amount(data['start'], data['end'], data['mode'])
    low, high = store.boost_eta()
    estimate = ''
    if low is not None:
        hours = str(low) if low == high else f'{low}–{high}'
        estimate = (f'\n⏱ Примерный срок после оплаты — {hours} ч' if lang == 'ru'
                    else f'\n⏱ To‘lovdan keyin taxminan {hours} soat')
    await message.answer(f'🏅 {rank_name(data["start"],lang)} → {rank_name(data["end"],lang)}\n'
                         f'🆔 {game_id}\n💰 {fmt(amount)} {text("currency",lang)}{estimate}\n\n{text("pay",lang)}',reply_markup=payment_markup(lang))


@dp.callback_query(F.data.startswith('pay:'))
async def choose_payment(call: CallbackQuery,state:FSMContext,bot:Bot):
    data=await state.get_data();lang=data.get('lang',language(call.from_user))
    try:
        if not {'mode','start','end','game_id'}<=data.keys():
            raise ValidationError('invalid')
        method=call.data.split(':',1)[1];key=data.get('draft_key') or os.urandom(12).hex()
        if method != 'balance' or (UZCARD_TEST_MODE and call.from_user.id not in TEST_USERS):
            raise ValidationError('invalid_payment')
        await state.update_data(draft_key=key)
        order,new=store.create_order(user_data(call.from_user),dict(mode=data['mode'],fromIndex=data['start'],toIndex=data['end'],
            gameId=data['game_id'],paymentMethod=method,lang=lang,requestId=key+'_'+method))
        if new:referrals.track_order('boost',order['id'])
        payment=store.payment(order_id=order['id']);await call.answer()
        await deliver_payment(call.message,bot,state,payment,lang,order,new)
    except ValidationError as exc:
        await call.answer(text(str(exc),lang),show_alert=True)


@dp.message(F.web_app_data)
async def web_app_order(message:Message,state:FSMContext,bot:Bot):
    try:
        data=json.loads(message.web_app_data.data)
        if data.get('paymentMethod') != 'balance' or (UZCARD_TEST_MODE and message.from_user.id not in TEST_USERS):
            raise ValidationError('invalid_payment')
        if data.get('type')=='donat_order':
            order,new=store.create_donat_order(user_data(message.from_user),data)
            if new: referrals.track_order('donat',order['id'])
            await notify_pending_payment(bot, store.payment(donat_order_id=order['id'])['id'])
            await notify_partner_paid(bot,'donat',order['id'])
            return await message.answer(text('paid',order['lang']))
        if data.get('type')=='topup':
            raise ValidationError('invalid_payment_method')
        order,new=store.create_order(user_data(message.from_user),data)
        payment=store.payment(order_id=order['id'])
        if new:referrals.track_order('boost',order['id'])
        await deliver_payment(message,bot,state,payment,data.get('lang','uz'),order,new)
    except (ValidationError,ValueError,TypeError,AttributeError):
        await message.answer(text('invalid',language(message.from_user)))


@dp.message(Flow.donat_receipt, F.photo | F.document)
async def donat_receipt(message:Message,state:FSMContext,bot:Bot):
    data=await state.get_data();oid=data.get('donat_order_id')
    file_id=message.photo[-1].file_id if message.photo else message.document.file_id
    kind='photo' if message.photo else 'document'
    if not oid or not store.attach_donat_receipt(oid,message.from_user.id,file_id,kind):
        await message.answer('Buyurtma topilmadi yoki yakunlangan. / Заказ не найден или закрыт.');return
    order=store.donat_order(oid,message.from_user.id)
    await message.answer('✅ Chek qabul qilindi, admin tekshiradi. / Чек получен, администратор проверит.')
    if ADMIN_ID:
        try:
            markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text='✅ Подтвердить',callback_data=f'dsapprove:{oid}'),
                InlineKeyboardButton(text='❌ Отклонить',callback_data=f'dsreject:{oid}')
            ]])
            await bot.send_message(ADMIN_ID,f'🧾 Donat Shop # {oid}\n{html.escape(order["product"])} — {html.escape(order["option_label"])}\n'
                f'Сумма: {fmt(order["amount"])} UZS\nМетод: {html.escape(order["method"])}\n'
                f'Покупатель: {message.from_user.id}\nДанные: {html.escape(order["detail"])}',
                parse_mode='HTML',reply_markup=markup)
            await message.copy_to(ADMIN_ID)
        except Exception:
            logging.exception('Could not forward Donat receipt')
    await state.clear()

@dp.message(Flow.donat_receipt, ~F.text.startswith('/'))
async def donat_wrong_receipt(message:Message):
    await message.answer('Chek rasmini yuboring / Отправьте фото или файл чека.')

@dp.callback_query(F.data.startswith(('dsapprove:','dsreject:')))
async def donat_admin_action(call:CallbackQuery,bot:Bot):
    if call.from_user.id!=ADMIN_ID or ADMIN_ID==0:
        return await call.answer('Нет доступа',show_alert=True)
    try:
        kind,raw=call.data.split(':',1);oid=integer(raw,1,2**63-1)
        changed=store.decide_donat(oid,kind=='dsapprove');order=store.donat_order(oid)
    except ValidationError:
        return await call.answer('Неверный заказ',show_alert=True)
    if changed and kind=='dsapprove':
        await notify_partner_paid(bot,'donat',oid)
    if changed:
        try:
            await bot.send_message(order['user_id'],
                f'Donat Shop #{oid}: '+('✅ Оплата подтверждена. Заказ передан в работу.' if kind=='dsapprove' else '❌ Оплата не подтверждена. Обратитесь к администратору.'))
        except Exception:logging.exception('Could not notify Donat buyer')
    await call.message.edit_reply_markup(reply_markup=None)
    await call.answer('Сохранено' if changed else 'Уже обработано')

@dp.message(F.photo | F.document, F.chat.type == 'private', F.reply_to_message.text.startswith('🧾 UZCARD #'))
async def uzcard_receipt(message: Message, bot: Bot):
    buyer_id = message.from_user.id
    replied = message.reply_to_message
    if buyer_id not in TEST_USERS or not replied.from_user or replied.from_user.id != bot.id:
        return
    match = re.match(r'^🧾 UZCARD #([0-9]{1,18})\n', replied.text or '')
    if not match:
        return
    lang = store.profile(buyer_id)['lang']
    if message.document and (message.document.mime_type not in ('image/jpeg', 'image/png', 'application/pdf')
                             or (message.document.file_size or 0) > 10_000_000):
        return await message.answer('JPEG, PNG yoki PDF (10 MB gacha).' if lang == 'uz' else 'Пришлите JPEG, PNG или PDF до 10 МБ.')
    media = message.photo[-1] if message.photo else message.document
    payment_id = int(match[1])
    try:
        payment = store.payment(payment_id=payment_id)
        if payment['method'] != 'uzcard' or payment['user_id'] != buyer_id:
            raise ValidationError('invalid_payment')
        if not store.attach_receipt(payment_id, buyer_id, media.file_id,
                                    'photo' if message.photo else 'document', media.file_unique_id):
            return await message.answer(text('already', lang))
    except ValidationError as exc:
        if str(exc) == 'receipt_used':
            return await message.answer('Bu chek boshqa arizaga biriktirilgan.' if lang == 'uz' else 'Этот чек уже прикреплён к другой заявке.')
        return await message.answer(text('invalid_payment', lang))
    await notify_pending_payment(bot, payment_id)
    await message.answer('✅ Chek saqlandi. Admin tasdig‘ini kuting.' if lang == 'uz'
                         else '✅ Чек сохранён. Ожидайте подтверждения администратора.')


@dp.message(Flow.receipt,F.photo|F.document)
async def receipt(message:Message,state:FSMContext,bot:Bot):
    data=await state.get_data();lang=data.get('lang','uz');file_id=message.photo[-1].file_id if message.photo else message.document.file_id
    if not data.get('payment_id') or not store.attach_receipt(data['payment_id'],message.from_user.id,file_id,'photo' if message.photo else 'document'):
        return await message.answer(text('invalid',lang))
    await message.answer(text('receipt_saved',lang))
    await notify_pending_payment(bot, data['payment_id'])
    await state.clear()


@dp.message(Flow.receipt,~F.successful_payment,~F.web_app_data,~F.text.startswith('/'))
async def wrong_receipt(message:Message,state:FSMContext):
    data=await state.get_data();await message.answer(text('wrong_receipt',data.get('lang','uz')))


@dp.message(F.photo | F.document, F.chat.type == 'private')
async def receipt_without_order(message: Message):
    if message.from_user.id in TEST_USERS:
        lang = store.profile(message.from_user.id)['lang']
        await message.answer('Mini-ilovada to‘lovni oching va botdagi ariza xabariga javob bering.'
                             if lang == 'uz' else 'Откройте платёж в Mini App и ответьте на сообщение с номером заявки.')


@dp.pre_checkout_query()
async def pre_checkout(query:PreCheckoutQuery):
    try:
        if not re.fullmatch(r'ab:\d+',query.invoice_payload):
            raise ValidationError('invalid_payment')
        payment_id = int(query.invoice_payload.split(':')[1])
        payment = store.payment(payment_id=payment_id)
        method = payment['method']
        if method != 'stars' and (query.from_user.id != ADMIN_ID or method not in TEST_PROVIDER_TOKENS):
            raise ValidationError('invalid_payment')
        store.check_telegram_payment(payment_id, query.from_user.id, query.currency, query.total_amount, query.id, method)
    except ValidationError:
        return await query.answer(ok=False,error_message=text('invalid_payment',language(query.from_user)))
    await query.answer(ok=True)


@dp.message(F.successful_payment)
async def successful_payment(message:Message,bot:Bot):
    successful=message.successful_payment;lang=language(message.from_user)
    try:
        if not re.fullmatch(r'ab:\d+',successful.invoice_payload):
            raise ValidationError('invalid_payment')
        payment_id=int(successful.invoice_payload.split(':')[1])
        payment = store.payment(payment_id=payment_id)
        changed = store.settle_telegram_payment(
            payment_id, message.from_user.id, successful.currency, successful.total_amount,
            successful.telegram_payment_charge_id, payment['method'])
    except ValidationError:
        logging.exception('Payment verification failed')
        return await message.answer(text('invalid_payment',lang),reply_markup=contact_markup(lang))
    if changed and payment['kind'] != 'provider_test':
        payment=store.payment(payment_id)
        await notify_admin(bot,payment,paid=True)
        if payment['kind']=='order':
            await notify_partner_paid(bot,'boost',payment['order_id'])
        elif payment['kind']=='donat':
            await notify_partner_paid(bot,'donat',payment['donat_order_id'])
        await message.answer(text('credited' if payment['kind']=='topup' else 'paid',lang))


@dp.callback_query(F.data.startswith(('approve:','reject:')))
async def admin_action(call:CallbackQuery,bot:Bot):
    if not ADMIN_ID or call.from_user.id!=ADMIN_ID:
        return await call.answer(text('no_access',language(call.from_user)),show_alert=True)
    try:
        action,payment_id=call.data.split(':',1);payment_id=integer(payment_id,1,2**63-1)
        payment = store.payment(payment_id)
        if not payment['receipt_file_id']:
            return await call.answer('Чек ещё не получен', show_alert=True)
        changed = store.decide_manual(payment_id, action == 'approve')
    except ValidationError:
        return await call.answer('Неверный платёж',show_alert=True)
    await call.answer(text('saved' if changed else 'already','ru'))
    markup = single([('▶ В работу', f'boost_work:{payment["order_id"]}')]) if changed and action=='approve' and payment['order_id'] and not UZCARD_TEST_MODE else None
    try:
        await call.message.edit_reply_markup(reply_markup=markup)
    except Exception:
        logging.exception('Could not update admin payment buttons')
    if changed and action == 'approve' and payment['kind'] != 'topup':
        kind = 'boost' if payment['kind'] == 'order' else 'donat'
        await notify_partner_paid(bot, kind, payment['order_id'] or payment['donat_order_id'])
    if changed:
        lang = store.profile(payment['user_id'])['lang']
        key = 'rejected' if action == 'reject' else 'credited' if payment['kind'] == 'topup' else 'paid'
        message = text(key, lang)
        if UZCARD_TEST_MODE and key == 'paid':
            message = ('✅ Sinov to‘lovi tasdiqlandi. Buyurtma bajarilmoqda.' if lang == 'uz'
                       else '✅ Тестовая оплата подтверждена. Заказ в работе.')
        elif UZCARD_TEST_MODE and key == 'credited':
            message = '✅ Sinov balansi to‘ldirildi.' if lang == 'uz' else '✅ Тестовый баланс пополнен.'
        try:
            await bot.send_message(payment['user_id'], message, reply_markup=contact_markup(lang))
        except Exception:
            logging.exception('Could not notify buyer about manual payment')


@dp.message(Command('terms'))
async def payment_terms(message: Message):
    if STARS_TERMS_URL:
        await message.answer(STARS_TERMS_URL)
    else:
        await message.answer('Shartlar / Условия: @' + ADMIN_USERNAME if ADMIN_USERNAME else 'Shartlar / Условия пока недоступны.')


@dp.message(Command('support','paysupport'))
async def support(message:Message):
    lang=language(message.from_user);await message.answer(text('support',lang),reply_markup=contact_markup(lang))


@dp.message(Command('balance'))
async def balance(message:Message):
    lang=language(message.from_user);amount=store.state(message.from_user.id)['balance']
    await message.answer(f'{text("balance_info",lang)}: {fmt(amount)} {text("currency",lang)}')


@dp.message(Command('credit'))
async def credit(message:Message,bot:Bot):
    if message.from_user.id!=ADMIN_ID:
        return
    try:
        _,user_id,amount=message.text.split();changed=store.credit(user_id,amount,f'{message.chat.id}:{message.message_id}')
    except (ValueError,ValidationError):
        return await message.answer('/credit TELEGRAM_ID СУММА_В_СУМАХ')
    await message.answer('Баланс пополнен.' if changed else 'Операция уже выполнена.')
    if changed:
        try:
            await bot.send_message(int(user_id),text('credited','uz'))
        except Exception:
            logging.exception('Could not deliver balance notification')


@dp.message(Command('admin'))
async def admin(message:Message):
    if message.from_user.id!=ADMIN_ID:
        return
    with store.connect() as con:
        orders=con.execute('SELECT COUNT(*) FROM orders').fetchone()[0]
        pending=con.execute("SELECT COUNT(*) FROM payments WHERE status='pending'").fetchone()[0]
        paid=con.execute("SELECT COUNT(*) FROM payments WHERE status='paid'").fetchone()[0]
    await message.answer(f'Arslan Boost\nЗаказов: {orders}\nОжидают оплаты: {pending}\nОплачено: {paid}\n\n/credit TELEGRAM_ID СУММА — пополнить баланс вручную')


async def notify_partner_paid(bot, kind, order_id):
    partner_id=referrals.claim_paid_notice(kind,order_id)
    if not partner_id:return
    try:
        await bot.send_message(partner_id,
            '✅ Hamkoringiz orqali xarid tasdiqlandi! / Покупка по вашей ссылке подтверждена.\n'
            'Комиссия будет рассчитана от чистой прибыли после выполнения заказа и станет доступна через 24 часа.\n'
            'Проверка: /partner')
    except Exception:logging.exception('Could not notify referral partner about paid order')


async def send_withdrawal_admin(bot, row):
    if not ADMIN_ID:return
    markup=InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text='✅ Выплачено',callback_data=f'refpay:{row["id"]}'),
        InlineKeyboardButton(text='❌ Отказать',callback_data=f'refdeny:{row["id"]}')]])
    await bot.send_message(ADMIN_ID,
      f'💸 Заявка #{row["id"]} на выплату партнёру {row["partner_id"]}\n'
      f'Сумма: {fmt(row["amount"])} UZS\n'
      f'Реквизиты: {html.escape(row["destination"])}\n'
      'Кнопку «Выплачено» нажмите ТОЛЬКО после реального перевода.',parse_mode='HTML',reply_markup=markup)


@dp.message(Command('partner'))
async def partner_command(message:Message,bot:Bot):
    data=referrals.dashboard(message.from_user.id,BOT_USERNAME)
    if data['status']=='none':
        await message.answer('🤝 Hamkorlik / Партнёрская программа\n'
          '50% от чистой прибыли с заказов клиентов по вашей ссылке.\n'
          'Начисление спустя 24 часа после выполнения заказа. Вывод от 10 000 сум.\n'
          'Подать заявку: /partner_apply')
    elif data['status']=='pending':
        await message.answer('⏳ Заявка на партнёрство рассматривается администратором.')
    elif data['status']=='rejected':
        await message.answer('Заявка отклонена. Повторная заявка: /partner_apply')
    elif data['status']=='suspended':
        await message.answer('Партнёрский аккаунт временно отключён.')
    else:
        await message.answer('🤝 Hamkor / Партнёр\n'
            f'Ваша ссылка: {data["url"] or "Настройте BOT_USERNAME"}\n'
            f'Клиентов: {data["clients"]} · Выполненных заказов: {data["fulfilledOrders"]}\n'
            f'Доступно: {fmt(data["available"])} UZS\n'
            f'Ожидает 24 часа: {fmt(data["pending"])} UZS\n'
            'Вывод: /withdraw СУММА РЕКВИЗИТЫ (минимум 10 000 сум)\n'
            'Данные покупателей и балансы других партнёров недоступны.')


@dp.message(Command('partner_apply'))
async def partner_apply_command(message:Message,bot:Bot):
    status,new=referrals.apply(user_data(message.from_user))
    if new and ADMIN_ID:
        markup=InlineKeyboardMarkup(inline_keyboard=[[
           InlineKeyboardButton(text='✅ Одобрить',callback_data=f'refapprove:{message.from_user.id}'),
           InlineKeyboardButton(text='❌ Отказать',callback_data=f'refreject:{message.from_user.id}')]])
        await bot.send_message(ADMIN_ID,
            f'🤝 Заявка блогера: {message.from_user.id} (@{html.escape(message.from_user.username or "")})',
            reply_markup=markup)
    await message.answer('✅ Заявка отправлена.' if new else
                         'Заявка уже подана или вы уже партнёр. /partner')


@dp.callback_query(F.data.startswith(('refapprove:','refreject:')))
async def approve_partner_action(call:CallbackQuery,bot:Bot):
    if call.from_user.id!=ADMIN_ID or ADMIN_ID==0:return await call.answer('Нет доступа',show_alert=True)
    try:
        cmd,uid=call.data.split(':',1)
        uid=integer(uid,1,2**63-1)
        result=referrals.approve(uid,cmd=='refapprove')
    except ValidationError:return await call.answer('Неверная заявка',show_alert=True)
    if result:
        try:await bot.send_message(uid,
            '✅ Партнёрство одобрено! Ссылка и баланс: /partner' if result=='approved'
            else 'Заявка на партнёрство отклонена.')
        except Exception:logging.exception('Could not notify applicant')
    await call.message.edit_reply_markup(reply_markup=None)
    await call.answer('Готово' if result else 'Уже обработано')


@dp.message(Command('withdraw'))
async def partner_withdraw_command(message:Message,bot:Bot):
    args=(message.text or '').split(maxsplit=2)
    if len(args)<3:
        return await message.answer('Формат: /withdraw 10000 НОМЕР_КАРТЫ_ИЛИ_ТЕЛЕФОН\n'
                                    'Минимум 10 000 сум. Реквизиты отправляйте только в ЛС бота.')
    try:oid=referrals.withdraw(message.from_user.id,args[1],args[2])
    except ValidationError as exc:return await message.answer('Нельзя создать заявку: '+str(exc))
    row=referrals.withdrawal(oid)
    if ADMIN_ID:
        try:await send_withdrawal_admin(bot,row)
        except Exception:logging.exception('Withdrawal admin notification failed')
    await message.answer(f'✅ Заявка #{oid} на {fmt(row["amount"])} сум создана. Ожидайте ручного перевода.')


@dp.callback_query(F.data.startswith(('refpay:','refdeny:')))
async def partner_withdraw_action(call:CallbackQuery,bot:Bot):
    if call.from_user.id!=ADMIN_ID or ADMIN_ID==0:return await call.answer('Нет доступа',show_alert=True)
    try:
        cmd,oid=call.data.split(':',1)
        row=referrals.decide_withdraw(oid,cmd=='refpay')
    except ValidationError:return await call.answer('Неверная заявка',show_alert=True)
    if row:
        try:await bot.send_message(row['partner_id'],
             f'Заявка на вывод #{row["id"]}: '+('✅ выплачено' if cmd=='refpay' else '❌ отклонена'))
        except Exception:logging.exception('Could not notify about withdrawal')
    await call.message.edit_reply_markup(reply_markup=None)
    await call.answer('Сохранено' if row else 'Уже обработано')


@dp.message(Command('boost_eta'))
async def admin_boost_eta(message: Message):
    if not ADMIN_ID or message.from_user.id != ADMIN_ID:
        return
    args = (message.text or '').split()[1:]
    try:
        if args == ['off']:
            store.set_boost_eta()
            return await message.answer('Срок скрыт.')
        if len(args) in (1, 2):
            store.set_boost_eta(args[0], args[-1])
            low, high = store.boost_eta()
            hours = str(low) if low == high else f'{low}–{high}'
            return await message.answer(f'Примерный срок буста: {hours} ч после оплаты.')
    except ValidationError:
        pass
    await message.answer('/boost_eta 24 48 — срок в часах\n/boost_eta off — скрыть срок')


async def notify_boost_progress(bot, order, completed=False):
    if order['lang'] == 'ru':
        status = 'выполнен' if completed else 'в работе'
        message = f'Буст #{order["id"]} {status}.'
    else:
        status = 'bajarildi' if completed else 'bajarilmoqda'
        message = f'Boost #{order["id"]} {status}.'
    try:
        await bot.send_message(order['user_id'], message)
    except Exception:
        logging.exception('Could not notify buyer about boost status')


@dp.callback_query(F.data.startswith('boost_work:'))
async def admin_boost_work(call: CallbackQuery, bot: Bot):
    if not ADMIN_ID or call.from_user.id != ADMIN_ID:
        return await call.answer('Нет доступа', show_alert=True)
    try:
        order = store.start_boost(call.data.split(':', 1)[1])
    except ValidationError:
        return await call.answer('Неверный заказ', show_alert=True)
    if order:
        await notify_boost_progress(bot, order)
        await call.message.edit_reply_markup(reply_markup=None)
    await call.answer('В работе' if order else 'Статус уже изменён')


@dp.message(Command('delivered'))
async def admin_delivered_command(message:Message,bot:Bot):
    if message.from_user.id!=ADMIN_ID or ADMIN_ID==0:return
    args=(message.text or '').split()
    if len(args)!=4:
        return await message.answer('/delivered donat 123 9000\n'
            'Укажите тип donat/boost, номер заказа и фактический закуп в сумах.')
    try:
        result=referrals.fulfilled(args[1],args[2],args[3])
    except ValidationError as exc:return await message.answer('Заказ не завершён: '+str(exc))
    if not result['new']:return await message.answer('Этот заказ уже завершён.')
    await message.answer('✅ Выполнение отмечено. '+
           ('Комиссия партнёра: '+fmt(result['commission'])+' UZS, станет доступна через 24 часа.'
            if result.get('partner_id') else 'Партнёра по заказу нет.'))
    if args[1] == 'boost':
        await notify_boost_progress(bot, {**result, 'id':args[2]}, completed=True)
    if result.get('partner_id'):
        try:await bot.send_message(result['partner_id'],
            f'✅ Заказ выполнен. Комиссия {fmt(result["commission"])} UZS ожидает 24 часа. /partner')
        except Exception:logging.exception('Could not notify fulfilled referral')


@dp.message(Command('refcancel'))
async def admin_refcancel_command(message:Message):
    if message.from_user.id!=ADMIN_ID or ADMIN_ID==0:return
    args=(message.text or '').split()
    if len(args)!=3:return await message.answer('/refcancel donat 123')
    try:done=referrals.reverse(args[1],args[2])
    except ValidationError as exc:return await message.answer(str(exc))
    await message.answer('✅ Возврат и отмена комиссии сохранены.' if done else 'Уже отменено.')


async def referral_settlement_worker(bot):
    while True:
        if ADMIN_ID:
            try:
                for payment_id in store.pending_admin_notices():
                    await notify_pending_payment(bot, payment_id)
            except Exception:
                logging.exception('Could not process paid order notices')
        try:
            for item in referrals.release_due():
                try:await bot.send_message(item['partner_id'],
                    f'💰 Доступна комиссия: +{fmt(item["amount"])} UZS. Баланс и вывод: /partner')
                except Exception:logging.exception('Could not notify new referral earnings')
        except Exception:logging.exception('Referral settlement worker failed')
        await asyncio.sleep(60)


def create_app(bot):
    origin=os.getenv('ALLOWED_ORIGIN','').strip() or (f'{urlsplit(APP_URL).scheme}://{urlsplit(APP_URL).netloc}' if APP_URL else '')

    @web.middleware
    async def middleware(request,handler):
        if request.method=='OPTIONS':
            response=web.Response(status=204)
        else:
            try:
                response=await handler(request)
            except ValidationError as exc:
                response=web.json_response({'error':str(exc)},status=401 if str(exc) in ('unauthorized','session_expired') else 400)
            except (json.JSONDecodeError,UnicodeDecodeError):
                response=web.json_response({'error':'invalid_json'},status=400)
        if origin and request.headers.get('Origin')==origin:
            response.headers['Access-Control-Allow-Origin']=origin;response.headers['Vary']='Origin'
            response.headers['Access-Control-Allow-Headers']='Content-Type, X-Telegram-Init-Data'
            response.headers['Access-Control-Allow-Methods']='GET, POST, OPTIONS'
        response.headers['Cache-Control']='no-store' if request.path.startswith('/api/') else 'no-cache'
        return response

    app=web.Application(middlewares=[middleware],client_max_size=16000)

    help_lock = asyncio.Lock()

    def require_method(data, method):
        if not isinstance(data, dict):
            raise ValidationError('invalid_request')
        if data.get('paymentMethod') != method:
            raise ValidationError('invalid_payment_method')

    def require_stars_terms(data):
        require_method(data, 'stars')
        if not STARS_TERMS_URL or not store.stars_rate:
            raise ValidationError('stars_not_configured')
        if data.get('acceptTerms') is not True:
            raise ValidationError('terms_required')

    async def public_config(request):
        return web.json_response({'arslanBoostApi':True,'supportUrl':admin_link(),
            'botUrl':'https://t.me/'+BOT_USERNAME if BOT_USERNAME else None,
            'starsRate':store.stars_rate if STARS_TERMS_URL else 0,
            'starsMax':store.max_topup_stars if STARS_TERMS_URL else 0,
            'termsUrl':STARS_TERMS_URL,'prices':list(PRICES),
            'calibrationLegendPrice':CALIBRATION_LEGEND_PRICE,'boostModeSurcharge':BOOST_MODE_SURCHARGE,
            'minBoostPrice':MIN_BOOST_PRICE,'boostEta':store.boost_eta(),
            'banners':{'uz':os.getenv('BANNER_URL_UZ') or 'assets/hero-banner-hd.png',
                       'ru':os.getenv('BANNER_URL_RU') or 'assets/hero-banner-hd.png'}})

    def authenticate(request):
        user = validate_init_data(request.headers.get('X-Telegram-Init-Data',''), TOKEN)
        if UZCARD_TEST_MODE and user['id'] not in TEST_USERS:
            raise ValidationError('test_access_required')
        return user

    def order_method(user, data):
        if not isinstance(data, dict):
            raise ValidationError('invalid_request')
        method = data.get('paymentMethod')
        if method == 'balance' or (method == 'uzcard' and user['id'] in TEST_USERS):
            return method
        raise ValidationError('invalid_payment_method')

    def transfer_details(payment):
        status = payment['status']
        if status == 'pending' and payment['receipt_file_id']:
            status = 'review'
        result = {'id': payment['id'], 'amount': payment['amount'], 'status': status,
                  'kind': payment['kind'], 'orderId': payment['order_id'] or payment['donat_order_id']}
        if status == 'pending':
            result.update(cardNumber=' '.join(UZCARD_NUMBER[i:i+4] for i in range(0, 16, 4)),
                          cardHolder=CARD_HOLDER, receiptLink=f'https://t.me/{BOT_USERNAME}?start=check_{payment["id"]}')
        return result

    async def transfer_status(request):
        user = authenticate(request)
        data = await request.json()
        if user['id'] not in TEST_USERS or not isinstance(data, dict):
            raise ValidationError('invalid_payment_method')
        payment = store.payment(payment_id=integer(data.get('paymentId'), 1, 2**63 - 1))
        if payment['user_id'] != user['id'] or payment['method'] != 'uzcard':
            raise ValidationError('payment_not_found')
        return web.json_response(transfer_details(payment))

    async def state_endpoint(request):
        user = authenticate(request)
        state = store.state(user['id'])
        state['uzcardTest'] = user['id'] in TEST_USERS
        if user['id'] == ADMIN_ID and not UZCARD_TEST_MODE:
            state['testProviders'] = list(TEST_PROVIDER_TOKENS)
        return web.json_response(state)

    async def profile_endpoint(request):
        user=authenticate(request);data=await request.json()
        if not isinstance(data,dict):
            raise ValidationError('invalid_request')
        return web.json_response(store.profile(user['id'],game_id=data.get('gameId'),lang=data.get('lang')))

    async def checkout(request):
        user=authenticate(request);data=await request.json()
        method = order_method(user, data)
        data['expectedAmount'] = integer(data.get('expectedAmount'), 1, MAX_TOPUP_AMOUNT)
        order, _ = store.create_order(user, data)
        payment = store.payment(order_id=order['id'])
        result = {'id':order['id'], 'amount':order['amount'], 'status':order['status'],
                  'boostEta':[order['eta_min_hours'],order['eta_max_hours']]}
        if method == 'uzcard':
            result['transfer'] = transfer_details(payment)
        else:
            await notify_pending_payment(bot, payment['id'])
            await notify_partner_paid(bot,'boost',order['id'])
        return web.json_response(result)

    async def donat_catalog(request):
        from donat_catalog import CATALOG
        return web.json_response(CATALOG)

    async def donat_state(request):
        user=authenticate(request)
        return web.json_response({'orders':store.donat_state(user['id'])})

    async def donat_create(request):
        user=authenticate(request)
        data=await request.json()
        method = order_method(user, data)
        data['expectedAmount'] = integer(data.get('expectedAmount'), 1, MAX_TOPUP_AMOUNT)
        order, _ = store.create_donat_order(user, data)
        payment = store.payment(donat_order_id=order['id'])
        result = {'id':order['id'], 'amount':order['amount'], 'status':order['status']}
        if method == 'uzcard':
            result['transfer'] = transfer_details(payment)
        else:
            await notify_pending_payment(bot, payment['id'])
            await notify_partner_paid(bot,'donat',order['id'])
        return web.json_response(result)

    async def order_help(request):
        user = authenticate(request)
        data = await request.json()
        if not ADMIN_ID:
            raise ValidationError('admin_unavailable')
        async with help_lock:
            row = store.save_order_help(user,data)
            if not row['notified']:
                details = json.loads(row['details'])
                if row['kind'] == 'boost':
                    service = (f'Boost · {MODES[details["mode"]]} · '
                               f'{RANKS[details["start"]]} → {RANKS[details["end"]]}\n'
                               f'Игровой ID: {details["game_id"]}')
                else:
                    service = f'Donat Shop · {details["title"]} · {details["label"]}\nДанные: {details["detail"]}'
                username = f' · @{row["username"]}' if row['username'] else ''
                try:
                    await bot.send_message(ADMIN_ID,
                        f'Заявка админу #{row["id"]}\n{service}\n'
                        f'Сумма заказа: {fmt(details["amount"])} UZS\nTelegram ID: {row["user_id"]}{username}\n'
                        + ('Клиенту доступен только банкомат.' if details.get('reason') == 'atm'
                           else 'Запрос помощи с заказом.'))
                except Exception as exc:
                    logging.exception('Could not send order help request')
                    raise ValidationError('admin_unavailable') from exc
                store.mark_order_help_sent(row['id'])
        return web.json_response({'id':row['id']})

    async def ref_me(request):
        user=authenticate(request)
        return web.json_response(referrals.dashboard(user['id'],BOT_USERNAME))

    async def ref_apply(request):
        user=authenticate(request)
        status,new=referrals.apply(user)
        if new and ADMIN_ID:
            markup=InlineKeyboardMarkup(inline_keyboard=[[
              InlineKeyboardButton(text='✅ Одобрить',callback_data=f'refapprove:{user["id"]}'),
              InlineKeyboardButton(text='❌ Отказать',callback_data=f'refreject:{user["id"]}')]])
            try:
                await bot.send_message(ADMIN_ID,f'📨 Заявка на партнёрство: {user["id"]} (@{html.escape(user.get("username", ""))})',reply_markup=markup)
            except Exception:logging.exception('Partner application notification failed')
        return web.json_response({'status':status,'new':new})

    async def ref_withdraw(request):
        user=authenticate(request);data=await request.json()
        if not isinstance(data,dict):raise ValidationError('invalid_request')
        oid=referrals.withdraw(user['id'],data.get('amount'),data.get('destination'))
        if ADMIN_ID:
            record=referrals.withdrawal(oid)
            try:await send_withdrawal_admin(bot,record)
            except Exception:logging.exception('Could not send payout request to admin')
        return web.json_response({'id':oid,'status':'pending'})

    async def topup(request):
        user=authenticate(request);data=await request.json()
        if isinstance(data, dict) and data.get('paymentMethod') == 'uzcard':
            if user['id'] not in TEST_USERS:
                raise ValidationError('invalid_payment_method')
            payment, _ = store.create_topup(user, data)
            return web.json_response({'transfer': transfer_details(payment)})
        require_stars_terms(data)
        payment,_=store.create_topup(user,data)
        result={'id':payment['id'],'amount':payment['amount'],'stars':payment['stars'],'method':payment['method'],'status':payment['status']}
        if payment['status']=='pending':
            result['invoiceLink']=await bot.create_invoice_link(**invoice_args(payment,data.get('lang','uz')))
        return web.json_response(result)

    async def payment_test(request):
        user = authenticate(request)
        if user['id'] != ADMIN_ID or UZCARD_TEST_MODE:
            raise web.HTTPForbidden()
        data = await request.json()
        if not isinstance(data, dict) or data.get('action') not in ('create', 'status'):
            raise ValidationError('invalid_request')
        method = data.get('method')
        if not isinstance(method, str) or method not in TEST_PROVIDER_TOKENS:
            raise ValidationError('invalid_payment_method')
        key = data.get('requestId')
        if not key:
            raise ValidationError('invalid_request')
        create = data['action'] == 'create'
        payment = store.provider_test(user['id'], method, key, create=create)
        result = {'status': payment['status'], 'amount': payment['amount']}
        if create and payment['status'] == 'pending':
            result['invoiceLink'] = await bot.create_invoice_link(**invoice_args(payment, data.get('lang')))
        return web.json_response(result)

    async def index(request):
        return web.FileResponse(BASE/'index.html')

    async def static_file(request):
        name=request.match_info['name']
        if name not in ('app.js','app.css','config.js','donat.html'):
            raise web.HTTPNotFound()
        return web.FileResponse(BASE/name)

    app.router.add_get('/api/config',public_config);app.router.add_post('/api/state',state_endpoint)
    app.router.add_post('/api/profile',profile_endpoint)
    app.router.add_post('/api/order-help',order_help)
    app.router.add_post('/api/checkout',checkout);app.router.add_post('/api/topup',topup)
    app.router.add_post('/api/transfer', transfer_status)
    app.router.add_post('/api/payment-test', payment_test)
    app.router.add_get('/api/donat/catalog',donat_catalog)
    app.router.add_post('/api/referral/me',ref_me)
    app.router.add_post('/api/referral/apply',ref_apply)
    app.router.add_post('/api/referral/withdraw',ref_withdraw)
    app.router.add_post('/api/donat/state',donat_state);app.router.add_post('/api/donat/create',donat_create)
    async def options(request):
        return web.Response(status=204)
    app.router.add_route('OPTIONS','/api/{path:.*}',options)
    app.router.add_get('/',index);app.router.add_get('/index.html',index)
    app.router.add_static('/assets/',BASE/'assets',show_index=False,follow_symlinks=False)
    app.router.add_get('/{name}',static_file)
    return app


async def main():
    global BOT_USERNAME
    if not TOKEN or TOKEN=='PASTE_BOTFATHER_TOKEN_HERE':
        raise RuntimeError('Укажите BOT_TOKEN в .env на сервере')
    bot=Bot(TOKEN);runner=None;referral_task=None
    try:
        me=await bot.get_me();BOT_USERNAME=me.username
        if os.getenv('ENABLE_HTTP','1')=='1':
            runner=web.AppRunner(create_app(bot));await runner.setup()
            await web.TCPSite(runner,os.getenv('HTTP_HOST','0.0.0.0'),int(os.getenv('PORT') or os.getenv('HTTP_PORT') or 8080)).start()
        await bot.delete_webhook(drop_pending_updates=False)
        referral_task=asyncio.create_task(referral_settlement_worker(bot))
        await dp.start_polling(bot,close_bot_session=False)
    finally:
        if referral_task:referral_task.cancel()
        if runner:
            await runner.cleanup()
        await bot.session.close()


if __name__=='__main__':
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main())

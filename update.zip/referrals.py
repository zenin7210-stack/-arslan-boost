"""Server-owned affiliate program for Arslan Boost (referrals, profits, payouts).

No earnings are created from client-supplied payment status or profit.
Each payment must be confirmed and each order must be fulfilled by an admin.
"""
import re
import secrets
import time
from datetime import datetime, timezone

from service import ValidationError, integer

MIN_WITHDRAW = 10_000
SHARE_NUM = 1
SHARE_DEN = 2
KINDS = {'donat': 'donat_orders', 'boost': 'orders'}


def utc_now():
    return datetime.now(timezone.utc).isoformat()


class Referrals:
    def __init__(self, store):
        self.store = store
        self.init_db()

    def init_db(self):
        with self.store.connect() as con:
            con.execute('''CREATE TABLE IF NOT EXISTS ref_applications (
                user_id INTEGER PRIMARY KEY, username TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected')),
                created_at TEXT NOT NULL, reviewed_at TEXT)''')
            con.execute('''CREATE TABLE IF NOT EXISTS ref_partners (
                user_id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE,
                active INTEGER NOT NULL DEFAULT 1, approved_at TEXT NOT NULL)''')
            con.execute('''CREATE TABLE IF NOT EXISTS ref_bindings (
                buyer_id INTEGER PRIMARY KEY, partner_id INTEGER NOT NULL,
                joined_at TEXT NOT NULL)''')
            con.execute('CREATE INDEX IF NOT EXISTS ref_bindings_partner ON ref_bindings(partner_id)')
            con.execute('''CREATE TABLE IF NOT EXISTS ref_order_links (
                kind TEXT NOT NULL, order_id INTEGER NOT NULL, partner_id INTEGER NOT NULL,
                PRIMARY KEY(kind,order_id))''')
            con.execute('''CREATE TABLE IF NOT EXISTS ref_earnings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kind TEXT NOT NULL, order_id INTEGER NOT NULL, partner_id INTEGER NOT NULL,
                amount INTEGER NOT NULL, cost INTEGER NOT NULL, profit INTEGER NOT NULL,
                commission INTEGER NOT NULL, created_at TEXT NOT NULL,
                available_at REAL NOT NULL, credited_at TEXT,
                status TEXT NOT NULL CHECK(status IN ('pending','available','reversed')),
                UNIQUE(kind,order_id))''')
            con.execute('CREATE INDEX IF NOT EXISTS ref_due ON ref_earnings(status,available_at)')
            con.execute('''CREATE TABLE IF NOT EXISTS ref_withdrawals (
                id INTEGER PRIMARY KEY AUTOINCREMENT, partner_id INTEGER NOT NULL,
                amount INTEGER NOT NULL, destination TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('pending','paid','rejected')),
                created_at TEXT NOT NULL, reviewed_at TEXT)''')
            con.execute('CREATE INDEX IF NOT EXISTS ref_withdrawals_partner ON ref_withdrawals(partner_id)')
            con.execute('''CREATE TABLE IF NOT EXISTS ref_payment_notices (
                kind TEXT NOT NULL, order_id INTEGER NOT NULL,
                PRIMARY KEY(kind,order_id))''')

    def apply(self, user):
        uid = integer(user['id'],1,2**63-1)
        username = str(user.get('username') or '')[:64]
        with self.store.connect() as con:
            if con.execute('SELECT 1 FROM ref_partners WHERE user_id=?',(uid,)).fetchone():
                return 'approved',False
            row=con.execute('SELECT status FROM ref_applications WHERE user_id=?',(uid,)).fetchone()
            if row and row['status']=='pending':
                return 'pending',False
            con.execute('''INSERT INTO ref_applications(user_id,username,status,created_at)
                VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET
                username=excluded.username,status='pending',created_at=excluded.created_at,reviewed_at=NULL''',
                (uid,username,'pending',utc_now()))
            return 'pending',True

    def approve(self, uid, yes=True):
        uid=integer(uid,1,2**63-1)
        with self.store.connect() as con:
            application=con.execute('SELECT * FROM ref_applications WHERE user_id=?',(uid,)).fetchone()
            if not application or application['status']!='pending':
                return None
            if yes:
                # Server-generated unguessable code. No changing or recycling existing codes.
                for _ in range(8):
                    code=secrets.token_urlsafe(9).rstrip('=')
                    if not con.execute('SELECT 1 FROM ref_partners WHERE code=?',(code,)).fetchone():break
                else:raise ValidationError('code_unavailable')
                con.execute('INSERT OR IGNORE INTO ref_partners(user_id,code,approved_at) VALUES(?,?,?)',
                            (uid,code,utc_now()))
            con.execute('UPDATE ref_applications SET status=?,reviewed_at=? WHERE user_id=?',
                        ('approved' if yes else 'rejected',utc_now(),uid))
            return 'approved' if yes else 'rejected'

    def bind(self, buyer_id, code):
        """Claim first approved referrer permanently. Never allow self-referral."""
        buyer_id=integer(buyer_id,1,2**63-1)
        if not isinstance(code,str) or not re.fullmatch(r'[A-Za-z0-9_-]{8,40}',code):
            return False
        with self.store.connect() as con:
            partner=con.execute('SELECT user_id FROM ref_partners WHERE code=? AND active=1',(code,)).fetchone()
            if not partner or partner['user_id']==buyer_id:return False
            added=con.execute('INSERT OR IGNORE INTO ref_bindings VALUES (?,?,?)',
                              (buyer_id,partner['user_id'],utc_now())).rowcount
            return bool(added)

    def partner_for(self, buyer_id):
        with self.store.connect() as con:
            row=con.execute('SELECT partner_id FROM ref_bindings WHERE buyer_id=?',(buyer_id,)).fetchone()
            return int(row['partner_id']) if row else None

    def track_order(self, kind, order_id):
        """Snapshot attribution only if customer was bound before order creation."""
        table=self._table(kind)
        order_id=integer(order_id,1,2**63-1)
        with self.store.connect() as con:
            order=con.execute(f'SELECT user_id,created_at FROM {table} WHERE id=?',(order_id,)).fetchone()
            if not order:return None
            con.execute(f'''INSERT OR IGNORE INTO ref_order_links(kind,order_id,partner_id)
              SELECT ?,?,b.partner_id FROM ref_bindings b
              JOIN ref_partners p ON p.user_id=b.partner_id
              WHERE b.buyer_id=? AND b.joined_at<=? AND b.partner_id<>? AND p.active=1''',
              (kind,order_id,order['user_id'],order['created_at'],order['user_id']))
            link=con.execute('SELECT partner_id FROM ref_order_links WHERE kind=? AND order_id=?',(kind,order_id)).fetchone()
            return link['partner_id'] if link else None

    def claim_paid_notice(self,kind,order_id):
        """Prevent duplicate partner notifications after an actual confirmed payment."""
        table=self._table(kind);order_id=integer(order_id,1,2**63-1)
        self.track_order(kind,order_id)
        with self.store.connect() as con:
            row=con.execute(f'SELECT status FROM {table} WHERE id=?',(order_id,)).fetchone()
            if not row or row['status'] not in ('paid','in_progress','fulfilled'):return None
            link=con.execute('SELECT partner_id FROM ref_order_links WHERE kind=? AND order_id=?',(kind,order_id)).fetchone()
            if not link:return None
            if not con.execute('INSERT OR IGNORE INTO ref_payment_notices VALUES(?,?)',(kind,order_id)).rowcount:
                return None
            return int(link['partner_id'])

    def fulfilled(self,kind,order_id,cost,now=None):
        """Administrator verifies product delivered and logs real purchase cost.
        This is the sole method that creates pending commission.
        """
        table=self._table(kind)
        order_id=integer(order_id,1,2**63-1)
        cost=integer(cost,0,100_000_000_000)
        now=time.time() if now is None else float(now)
        self.track_order(kind,order_id)
        with self.store.connect() as con:
            row=con.execute(f'SELECT amount,status,user_id,lang FROM {table} WHERE id=?',(order_id,)).fetchone()
            if not row:raise ValidationError('order_not_found')
            if row['status']=='fulfilled':return {'new':False,'commission':0,'partner_id':None}
            if row['status'] not in ('paid','in_progress'):
                raise ValidationError('order_not_paid')
            con.execute(f"UPDATE {table} SET status='fulfilled' WHERE id=?",(order_id,))
            link=con.execute('SELECT partner_id FROM ref_order_links WHERE kind=? AND order_id=?',(kind,order_id)).fetchone()
            commission=0;partner_id=None
            if link:
                partner_id=int(link['partner_id'])
                profit=max(0,row['amount']-cost)
                commission=(profit*SHARE_NUM)//SHARE_DEN
                con.execute('''INSERT OR IGNORE INTO ref_earnings
                    (kind,order_id,partner_id,amount,cost,profit,commission,created_at,available_at,status)
                    VALUES(?,?,?,?,?,?,?,?,?,'pending')''',
                    (kind,order_id,partner_id,row['amount'],cost,profit,commission,utc_now(),now+86400))
            return {'new':True,'partner_id':partner_id,'commission':commission,'due_at':now+86400, 'user_id':row['user_id'], 'lang':row['lang']}

    def release_due(self,now=None):
        """Idempotent scheduled settlement; safe over bot restarts."""
        now=time.time() if now is None else float(now)
        with self.store.connect() as con:
            rows=con.execute("SELECT partner_id,SUM(commission) AS total FROM ref_earnings WHERE status='pending' AND available_at<=? GROUP BY partner_id",(now,)).fetchall()
            con.execute("UPDATE ref_earnings SET status='available',credited_at=? WHERE status='pending' AND available_at<=?",(utc_now(),now))
            return [{'partner_id':r['partner_id'],'amount':int(r['total'])} for r in rows if r['total']>0]

    def reverse(self,kind,order_id):
        """Admin-approved refund/cancellation reverses accrued commission even after settlement.
        An already paid withdrawal can cause temporary negative available balance; future earnings offset it.
        """
        table=self._table(kind);order_id=integer(order_id,1,2**63-1)
        with self.store.connect() as con:
            row=con.execute(f'SELECT status FROM {table} WHERE id=?',(order_id,)).fetchone()
            if not row:raise ValidationError('order_not_found')
            if row['status'] in ('refunded','rejected'):return False
            con.execute(f"UPDATE {table} SET status='refunded' WHERE id=?",(order_id,))
            con.execute("UPDATE ref_earnings SET status='reversed' WHERE kind=? AND order_id=? AND status<>'reversed'",(kind,order_id))
            # A cancellation can reduce the balance below already reserved withdrawal requests.
            # Cancel the newest pending payouts until remaining reservations are covered.
            partner=con.execute('SELECT partner_id FROM ref_order_links WHERE kind=? AND order_id=?',(kind,order_id)).fetchone()
            if partner:
                uid=partner['partner_id']
                paid=con.execute("SELECT COALESCE(SUM(amount),0) FROM ref_withdrawals WHERE partner_id=? AND status='paid'",(uid,)).fetchone()[0]
                pending=list(con.execute("SELECT id,amount FROM ref_withdrawals WHERE partner_id=? AND status='pending' ORDER BY id DESC",(uid,)))
                earned=con.execute("SELECT COALESCE(SUM(commission),0) FROM ref_earnings WHERE partner_id=? AND status='available'",(uid,)).fetchone()[0]
                total=int(paid)+sum(r['amount'] for r in pending)
                for request in pending:
                    if total<=earned:break
                    con.execute("UPDATE ref_withdrawals SET status='rejected',reviewed_at=? WHERE id=?",(utc_now(),request['id']))
                    total-=request['amount']
            return True

    @staticmethod
    def _balances(con,user_id):
        earned=con.execute("SELECT COALESCE(SUM(commission),0) FROM ref_earnings WHERE partner_id=? AND status='available'",(user_id,)).fetchone()[0]
        pending=con.execute("SELECT COALESCE(SUM(commission),0) FROM ref_earnings WHERE partner_id=? AND status='pending'",(user_id,)).fetchone()[0]
        withdrawals=con.execute("SELECT COALESCE(SUM(amount),0) FROM ref_withdrawals WHERE partner_id=? AND status IN ('pending','paid')",(user_id,)).fetchone()[0]
        available=max(0,int(earned)-int(withdrawals))
        return {'available':available,'pending':int(pending),'earned':int(earned),'withdrawnOrReserved':int(withdrawals)}

    def dashboard(self,user_id,bot_username=''):
        user_id=integer(user_id,1,2**63-1)
        with self.store.connect() as con:
            partner=con.execute('SELECT * FROM ref_partners WHERE user_id=?',(user_id,)).fetchone()
            app=con.execute('SELECT status FROM ref_applications WHERE user_id=?',(user_id,)).fetchone()
            if not partner:
                return {'status':app['status'] if app else 'none','sharePercent':50,'minWithdraw':MIN_WITHDRAW}
            balances=self._balances(con,user_id)
            buyers=con.execute('SELECT COUNT(*) FROM ref_bindings WHERE partner_id=?',(user_id,)).fetchone()[0]
            completed=con.execute("SELECT COUNT(*) FROM ref_earnings WHERE partner_id=? AND status <> 'reversed'",(user_id,)).fetchone()[0]
            history=[{'kind':r['kind'],'orderId':r['order_id'],'commission':r['commission'], 'status':r['status']}
                for r in con.execute('SELECT kind,order_id,commission,status FROM ref_earnings WHERE partner_id=? ORDER BY id DESC LIMIT 15',(user_id,))]
            wd=[{'id':r['id'],'amount':r['amount'],'status':r['status']}
                for r in con.execute('SELECT id,amount,status FROM ref_withdrawals WHERE partner_id=? ORDER BY id DESC LIMIT 10',(user_id,))]
            return {'status':'approved' if partner['active'] else 'suspended','code':partner['code'],
                    'url':f'https://t.me/{bot_username}?start=ref_{partner["code"]}' if re.fullmatch(r'[A-Za-z0-9_]{5,32}',bot_username) else None,
                    'sharePercent':50,'minWithdraw':MIN_WITHDRAW,'clients':buyers,'fulfilledOrders':completed,
                    **balances,'history':history,'withdrawals':wd}

    def withdraw(self,user_id,amount,destination):
        user_id=integer(user_id,1,2**63-1)
        amount=integer(amount,MIN_WITHDRAW,100_000_000_000)
        if not isinstance(destination,str) or not 5<=len(destination.strip())<=120 or any(ord(c)<32 for c in destination):
            raise ValidationError('invalid_payout_details')
        with self.store.connect() as con:
            partner=con.execute('SELECT active FROM ref_partners WHERE user_id=?',(user_id,)).fetchone()
            if not partner or not partner['active']:raise ValidationError('not_partner')
            if self._balances(con,user_id)['available']<amount:raise ValidationError('insufficient_referral_balance')
            cursor=con.execute('INSERT INTO ref_withdrawals(partner_id,amount,destination,status,created_at) VALUES(?,?,?, ?,?)',
                (user_id,amount,destination.strip(),'pending',utc_now()))
            return int(cursor.lastrowid)

    def decide_withdraw(self,request_id,approve):
        request_id=integer(request_id,1,2**63-1)
        with self.store.connect() as con:
            row=con.execute('SELECT * FROM ref_withdrawals WHERE id=?',(request_id,)).fetchone()
            if not row:raise ValidationError('withdraw_not_found')
            if row['status']!='pending':return None
            con.execute('UPDATE ref_withdrawals SET status=?,reviewed_at=? WHERE id=?',
                        ('paid' if approve else 'rejected',utc_now(),request_id))
            return dict(row)

    def withdrawal(self,request_id):
        request_id=integer(request_id,1,2**63-1)
        with self.store.connect() as con:
            row=con.execute('SELECT * FROM ref_withdrawals WHERE id=?',(request_id,)).fetchone()
            if not row:raise ValidationError('withdraw_not_found')
            return dict(row)

    def applications(self):
        with self.store.connect() as con:
            return [dict(r) for r in con.execute("SELECT user_id,username,created_at FROM ref_applications WHERE status='pending' ORDER BY created_at LIMIT 50")]

    @staticmethod
    def _table(kind):
        if kind not in KINDS:raise ValidationError('invalid_kind')
        return KINDS[kind]

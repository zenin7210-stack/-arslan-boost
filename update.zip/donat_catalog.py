"""Shared Donat Shop catalog and server-authoritative pricing."""
import json
import re
from pathlib import Path
from service import ValidationError, integer

CATALOG = json.loads((Path(__file__).resolve().parent / 'assets' / 'donat' / 'catalog.json').read_text(encoding='utf-8'))
PRODUCTS = {item['id']: item for item in CATALOG['items']}
METHODS = ('uzcard', 'humo', 'click', 'payme', 'paynet', 'terminal', 'stars', 'balance')


def normalize_order(data):
    if not isinstance(data, dict):
        raise ValidationError('invalid_order')
    product_id = data.get('product')
    product = PRODUCTS.get(product_id) if isinstance(product_id, str) else None
    if product is None:
        raise ValidationError('invalid_product')
    method = data.get('paymentMethod')
    if method not in METHODS:
        raise ValidationError('invalid_payment_method')
    if product['kind'] == 'quantity':
        quantity = integer(data.get('quantity'), product['min'], product['max'])
        amount = (quantity * product['per_100'] + 99) // 100
        label = f'{quantity:,} Gold'.replace(',', ' ')
        option = str(quantity)
    else:
        option = str(data.get('option', ''))
        matching = [o for o in product['options'] if o[0] == option]
        if not matching:
            raise ValidationError('invalid_option')
        label, amount = matching[0][1], matching[0][2]
    detail = str(data.get('detail', '')).strip()
    if len(detail) > 64 or any(ord(ch) < 32 or ch in '<>' for ch in detail):
        raise ValidationError('invalid_detail')
    if product['input'] == 'game_id' and not re.fullmatch(r'[a-zA-Z0-9_#-]{4,40}', detail):
        raise ValidationError('invalid_detail')
    if product['input'] == 'username' and not re.fullmatch(r'@?[a-zA-Z0-9_.]{3,32}', detail):
        raise ValidationError('invalid_detail')
    lang = 'ru' if data.get('lang') == 'ru' else 'uz'
    return {'product': product['id'], 'title': product['title'], 'option': option,
            'label': label, 'amount': amount, 'detail': detail, 'method': method, 'lang': lang}

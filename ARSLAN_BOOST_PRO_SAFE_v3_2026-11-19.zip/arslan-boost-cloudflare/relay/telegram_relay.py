"""Read only private credit notifications from explicitly pinned Telegram bot IDs."""
import argparse
import asyncio
import json
import logging
import os
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, HTTPRedirectHandler, build_opener

from dotenv import load_dotenv
from telethon import TelegramClient
from telethon.sessions import StringSession

HERE = Path(__file__).resolve().parent
POLL_SECONDS = 8
SECRET_PATTERN = re.compile(r"[A-Za-z0-9_-]{32,256}")
CREDIT_LINE = re.compile(
    r"^\s*(?:[+➕]|(?:пополнение|popolnenie|kirim|to['‘’]ldirish)\s*[:=]?\s*[+]?)"
    r"\s*[0-9][0-9 .,\u00a0\u202f]*\s*(?:UZS|сум(?:ов)?|so['‘’]m)\b",
    re.IGNORECASE | re.MULTILINE,
)
PRIVATE_CODE = re.compile(
    r"\botp\b|код подтверждения|verification code|tasdiqlash kodi|one.time password",
    re.IGNORECASE,
)


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def configuration():
    load_dotenv(HERE / ".env")
    api_id = int(os.getenv("TG_API_ID") or os.environ["API_ID"])
    api_hash = (os.getenv("TG_API_HASH") or os.environ["API_HASH"]).strip()
    session = Path(os.getenv("TELEGRAM_SESSION", ".private/owner")).expanduser()
    if not session.is_absolute():
        session = HERE / session
    session.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    # A StringSession stored as a Render secret works without a writable disk.
    # Never print it or commit it to a public repository.
    session_string = os.getenv("TG_SESSION", "").strip()
    return api_id, api_hash, session, session_string


def sources():
    configured = {}
    for slug, name in (("humo", "humocardbot"), ("cardxabar", "cardxabarbot")):
        key = slug.upper()
        peer = os.getenv(f"{key}_PEER_ID", "").strip()
        if not peer:
            continue
        secret = os.getenv(f"P2P_{key}_SECRET", "").strip()
        if not peer.isdigit() or int(peer) <= 0 or not SECRET_PATTERN.fullmatch(secret):
            raise ValueError(f"Check {key}_PEER_ID and P2P_{key}_SECRET.")
        configured[slug] = (name, int(peer), secret)
    if not configured:
        raise ValueError("Configure HUMO_PEER_ID or CARDXABAR_PEER_ID.")
    url = urlsplit(os.getenv("WORKER_URL", "").rstrip("/"))
    if (url.scheme != "https" or not url.hostname or url.username or url.password
            or url.path or url.query or url.fragment):
        raise ValueError("WORKER_URL must be the HTTPS origin of your Worker.")
    return url.geturl(), configured


def forward(url, secret, peer_id, message):
    text = message.raw_text
    if (message.out or message.fwd_from or not text or len(text) > 2500
            or PRIVATE_CODE.search(text) or not CREDIT_LINE.search(text.replace("\ufe0f", ""))):
        return True
    if os.getenv("RELAY_DRY_RUN", "1") == "1":
        logging.info("Read-only bank notification seen: peer=%s message=%s", peer_id, message.id)
        return True
    body = json.dumps({"eventId": f"tg:{peer_id}:{message.id}", "text": text}).encode()
    request = Request(url, data=body, headers={
        "Content-Type": "application/json",
        "Authorization": "Bearer " + secret,
    })
    try:
        with build_opener(NoRedirect).open(request, timeout=10) as response:
            result = json.load(response)
            if not result.get("accepted"):
                return False
            if not result.get("duplicate"):
                logging.info("Credit notice processed. Matched: %s", bool(result.get("matched")))
            return True
    except HTTPError as error:
        if error.code in (400, 422):
            try:
                reason = json.loads(error.read(1024)).get("error", "")
            except (ValueError, AttributeError):
                reason = ""
            if re.fullmatch(r"p2p_[a-z_]+", reason):
                logging.warning("Credit notice was ignored (%s).", reason)
                return True
        logging.warning("Worker returned HTTP %s.", error.code)
        return False
    except (URLError, OSError, ValueError):
        logging.warning("Worker unavailable. Will retry.")
        return False


async def run(args):
    api_id, api_hash, session, session_string = configuration()
    client = TelegramClient(StringSession(session_string) if session_string else str(session), api_id, api_hash)
    if args.peer_id:
        await client.start()
        try:
            name = {"humo": "humocardbot", "cardxabar": "cardxabarbot"}[args.peer_id]
            bot = await client.get_entity(name)
            if not getattr(bot, "bot", False):
                raise RuntimeError("Expected a Telegram bot.")
            print(f"@{bot.username}: {bot.id}")
        finally:
            await client.disconnect()
        return

    url, configured = sources()
    await client.connect()
    try:
        if not await client.is_user_authorized():
            raise RuntimeError("Run --peer-id interactively to authorize the local session.")
        me = await client.get_me()
        if me.bot:
            raise RuntimeError("Use the cardholder's authorized user session.")
        peers = {}
        for slug, (name, peer_id, secret) in configured.items():
            bot = await client.get_entity(name)
            if not getattr(bot, "bot", False) or bot.id != peer_id:
                raise RuntimeError(f"Telegram sender changed for {slug}. Verify its ID.")
            peers[slug] = (bot, secret)
        cursor_override = os.getenv("RELAY_CURSOR_PATH", "").strip()
        checkpoint_path = Path(cursor_override).expanduser() if cursor_override else session.with_suffix(".relay-cursors.json")
        checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
        checkpoint = json.loads(checkpoint_path.read_text()) if checkpoint_path.exists() else {}
        while True:
            for slug, (peer, secret) in peers.items():
                cursor_key = f"{me.id}:{peer.id}"
                minimum = datetime.now(timezone.utc) - timedelta(hours=24)
                if cursor_key not in checkpoint:
                    # Render can restart without a persistent disk. Recheck recent
                    # notifications; Cloudflare D1 deduplicates immutable message IDs.
                    recent = await client.get_messages(peer, limit=300)
                    backlog = [msg for msg in reversed(recent) if msg.date and msg.date >= minimum]
                    for msg in backlog:
                        ok = await asyncio.to_thread(forward, f"{url}/relay/{slug}", secret, peer.id, msg)
                        if not ok:
                            break
                        checkpoint[cursor_key] = msg.id
                        save_checkpoint(checkpoint_path, checkpoint)
                    if cursor_key not in checkpoint and recent:
                        # Do not silently skip a failed recent notification.
                        if backlog:
                            continue
                        checkpoint[cursor_key] = recent[0].id
                        save_checkpoint(checkpoint_path, checkpoint)
                    elif cursor_key not in checkpoint:
                        checkpoint[cursor_key] = 0
                        save_checkpoint(checkpoint_path, checkpoint)
                async for message in client.iter_messages(
                    peer, min_id=int(checkpoint[cursor_key]), reverse=True, limit=100
                ):
                    if message.date >= minimum:
                        ok = await asyncio.to_thread(forward, f"{url}/relay/{slug}", secret, peer.id, message)
                        if not ok:
                            break
                    checkpoint[cursor_key] = message.id
                    save_checkpoint(checkpoint_path, checkpoint)
            await asyncio.sleep(POLL_SECONDS)
    finally:
        await client.disconnect()


def save_checkpoint(path, checkpoint):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(checkpoint), encoding="utf-8")
    temporary.replace(path)


if __name__ == "__main__":
    if hasattr(os, "umask"):
        os.umask(0o077)
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    parser = argparse.ArgumentParser()
    parser.add_argument("--peer-id", choices=("humo", "cardxabar"))
    asyncio.run(run(parser.parse_args()))

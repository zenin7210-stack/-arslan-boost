"""One-time local authorisation for the cardholder's Telegram account.

Use only on your own trusted device. Do NOT paste any API credentials,
login codes, or session strings in ChatGPT, public code, or support chats.
"""
import asyncio
import getpass
import os
from pathlib import Path

from dotenv import load_dotenv
from telethon import TelegramClient
from telethon.sessions import StringSession

HERE = Path(__file__).resolve().parent


async def main():
    load_dotenv(HERE / ".env")
    raw_id = os.getenv("TG_API_ID") or os.getenv("API_ID") or input("Telegram API ID: ").strip()
    api_id = int(raw_id)
    api_hash = os.getenv("TG_API_HASH") or os.getenv("API_HASH") or getpass.getpass("Telegram API hash (hidden): ").strip()
    if api_id <= 0 or not api_hash:
        raise RuntimeError("An API ID and hash are required.")
    async with TelegramClient(StringSession(), api_id, api_hash) as client:
        await client.start(
            phone=lambda: input("Your Telegram phone number: ").strip(),
            code_callback=lambda: getpass.getpass("Telegram login code (hidden): ").strip(),
            password=lambda: getpass.getpass("2FA password, if requested (hidden): ").strip(),
        )
        me = await client.get_me()
        if me.bot:
            raise RuntimeError("Use your personal Telegram account, not a bot token.")
        session_string = client.session.save()
    output = Path.home() / ".arslan-telegram-session.env"
    fd = os.open(str(output), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write("TG_API_ID=" + str(api_id) + "\n")
        handle.write("TG_API_HASH=" + api_hash + "\n")
        handle.write("TG_SESSION=" + session_string + "\n")
    print(f"User {me.id} authorised. Secret session saved to {output}.")
    print("Copy values to Render private environment variables; never upload this file to GitHub.")


if __name__ == "__main__":
    asyncio.run(main())

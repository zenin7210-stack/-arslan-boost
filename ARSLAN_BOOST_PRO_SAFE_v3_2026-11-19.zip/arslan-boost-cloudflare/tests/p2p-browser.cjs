// Optional smoke test against a local HTTP server serving public/.
const assert = require('node:assert/strict');
const { chromium } = require(process.env.ARSLAN_PLAYWRIGHT || 'playwright');

async function run() {
  const browser = await chromium.launch({
    headless: true, executablePath: process.env.ARSLAN_CHROMIUM || undefined,
    args: ['--no-sandbox'],
  });
  try {
    const page = await browser.newPage({ viewport: { width: 390, height: 844 }, reducedMotion: 'reduce' });
    const failures = [];
    let nextStatus = 'pending';
    let checkedAt;
    let invoice;
    page.on('pageerror', error => failures.push(error.message));
    await page.route('https://telegram.org/js/telegram-web-app.js', route => route.fulfill({
      contentType: 'text/javascript',
      body: `window.Telegram = {WebApp:{
        initData:'fixture', initDataUnsafe:{user:{id:1,first_name:'Test'}}, ready(){}, expand(){}, openInvoice(){},
        openTelegramLink(url){ window.lastTelegramLink = url; }
      }};`,
    }));
    await page.route('**/api/**', route => {
      const path = new URL(route.request().url()).pathname;
      const now = Math.floor(Date.now() / 1000);
      const mock = {
        '/api/config': { arslanBoostApi: true, starsRate: 160, starsMax: 1000, termsUrl: 'https://example.com/terms' },
        '/api/state': { p2pPrivate: true, p2pMethods: ['uzcard', 'humo'], orders: [], payments: [], starsBalance: 0 },
        '/api/donat/state': { orders: [] },
        '/api/invoice/options': { balance: 0, methods: ['uzcard', 'humo'], minAmount: 10000, maxAmount: 100000000 },
      };
      let response = mock[path];
      if (path === '/api/invoice') {
        const data = route.request().postDataJSON();
        assert.equal(data.method, 'uzcard');
        if (data.amount === '10000') return route.fulfill({ status: 409, json: { error: 'p2p_amount_unavailable' } });
        assert.equal(data.amount, '100000');
        invoice = { id: 7, baseAmount: 100000, uniqueAmount: 100000, method: 'uzcard',
          status: 'pending', cardNumber: '0000000000000002', cardHolder: 'TEST',
          createdAt: now, expiresAt: now + 600, serverTime: now };
        response = invoice;
      }
      if (path === '/api/invoice/7/check') {
        checkedAt = now;
        response = { ...invoice, checkedAt, serverTime: now };
      }
      if (path === '/api/invoice/7/status') {
        assert.equal(route.request().method(), 'GET');
        response = { ...invoice, checkedAt, serverTime: now, status: nextStatus,
          balance: nextStatus === 'paid' ? 100000 : 0 };
      }
      if (path === '/api/invoice/7/receipt') {
        assert.fail('The automatic payment flow must not submit a receipt.');
      }
      return route.fulfill({ json: response || {}, status: response ? 200 : 404 });
    });
    await page.goto(process.env.ARSLAN_PREVIEW || 'http://127.0.0.1:8723');
    await page.locator('#donat.active .product-card').first().waitFor();
    assert.deepEqual(await page.locator('#donat .game-card').evaluateAll(cards => cards.map(card => card.dataset.product)),
      ['pubg_mobile', 'roblox', 'mobile_legends', 'brawl_stars']);
    await page.locator('#service-switch [data-service="home"]').click();
    await page.locator('#home [data-sheet="balance"]').click();
    await page.locator('[data-transfer-method="humo"]').click();
    await page.locator('[data-p2p-method="humo"][aria-pressed="true"]').waitFor();
    await page.locator('#p2p-back').click();
    await page.locator('[data-transfer-method="uzcard"]').click();
    await page.locator('[data-p2p-method="uzcard"][aria-pressed="true"]').waitFor();
    await page.locator('[data-p2p-amount="10000"]').click();
    await page.locator('#p2p-next').click();
    await page.locator('.p2p-feedback').getByText('Bu summa hozir band.', { exact: false }).waitFor();
    await page.locator('[data-p2p-amount="100000"]').click();
    await page.locator('#p2p-next').click();
    await page.getByText('100 000 so‘m', { exact: true }).waitFor();
    await page.getByText('0000 0000 0000 0002', { exact: true }).waitFor();
    assert.equal(await page.locator('#p2p-progress').getAttribute('max'), '600');
    assert.equal(await page.locator('#p2p-paid').textContent(), 'To‘ladim');
    await page.locator('#p2p-paid').click();
    await page.locator('.p2p-ring').waitFor();
    assert.equal(await page.locator('#p2p-receipt, #p2p-receipt-file').count(), 0);
    assert.equal(await page.evaluate(() => window.lastTelegramLink), undefined);
    nextStatus = 'paid';
    await page.locator('.p2p-check h3').getByText('Balans to‘ldirildi').waitFor();
    await page.locator('.p2p-check').getByText('100 000 so‘m', { exact: true }).waitFor();
    assert.deepEqual(failures, []);
    console.log('Mobile P2P form → To‘ladim → confirmed without a receipt passed');
  } finally {
    await browser.close();
  }
}

run().catch(error => { console.error(error); process.exitCode = 1; });

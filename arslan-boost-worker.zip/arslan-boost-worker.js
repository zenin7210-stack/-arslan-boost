var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// public/assets/donat/catalog.json
var catalog_default = {
  version: 3,
  items: [
    { id: "gold_rinok", title: "Gold (Rinok)", subtitle: "Skin orqali Gold", group: "core", image: "assets/donat/gold.webp", kind: "quantity", min: 100, max: 1e4, unit: "Gold", step: 100, input: "optional", badge: "Eng ommabop", options: [["100", "100 Gold", 11990], ["200", "200 Gold", 23990], ["500", "500 Gold", 59990], ["1000", "1 000 Gold", 119990], ["3000", "3 000 Gold", 359990], ["5000", "5 000 Gold", 599990], ["10000", "10 000 Gold", 1149990]] },
    { id: "gold_id", title: "Gold (ID)", subtitle: "ID orqali Gold", group: "core", image: "assets/donat/id.webp", kind: "options", max_packs: 99, unit: "Gold", input: "game_id", badge: "Tez va qulay", options: [["100", "100 Gold", 24990], ["200", "200 Gold", 47990], ["300", "300 Gold", 69990], ["500", "500 Gold", 95990], ["1000", "1 000 Gold", 159990], ["3000", "3 000 Gold", 369990]] },
    { id: "gold_pass", title: "Gold Pass", subtitle: "Standoff 2 Pass", group: "core", image: "assets/donat/pass.webp", kind: "options", input: "game_id", options: [["base", "Gold Pass", 108990], ["plus10", "Gold Pass +10", 198990], ["lvl1", "+1 LVL", 18990], ["lvl10", "+10 LVL", 134990], ["lvl20", "+20 LVL", 258990], ["lvl45", "+45 LVL", 448990]] },
    { id: "spin_coins", title: "Spin Coins", subtitle: "Spin valyutasi", group: "core", image: "assets/donat/coins.webp", kind: "options", max_packs: 99, unit: "Coins", input: "game_id", options: [["100", "100 Coins", 21990], ["500", "500 Coins", 98990], ["1000", "1 000 Coins", 189990], ["3000", "3 000 Coins", 428990]] },
    { id: "telegram_premium", title: "Telegram Premium", subtitle: "1 / 3 / 6 / 12 oy", group: "telegram", image: "assets/donat/premium.webp", kind: "options", input: "username", options: [["1", "1 oy", 44990], ["3", "3 oy (kirishsiz)", 169990], ["6", "6 oy (kirishsiz)", 229990], ["12gift", "12 oy (kirishsiz)", 419990], ["12", "12 oy", 299990]] },
    { id: "telegram_stars", title: "Telegram Stars", subtitle: "50 \u2013 1 000 Stars", group: "telegram", image: "assets/donat/stars.webp", kind: "quantity", min: 50, max: 1e3, unit: "Stars", step: 1, input: "username", options: [["50", "50 Stars", 12500], ["100", "100 Stars", 25e3], ["200", "200 Stars", 48e3], ["500", "500 Stars", 115e3], ["1000", "1 000 Stars", 23e4]] },
    { id: "pubg_mobile", title: "PUBG Mobile", subtitle: "UC", group: "games", image: "assets/donat/pubg.webp", kind: "options", max_packs: 99, unit: "UC", input: "game_id", options: [["60", "60 UC", 12990], ["120", "120 UC", 25990], ["180", "180 UC", 38990], ["325", "325 UC", 64990], ["660", "660 UC", 124990], ["985", "985 UC", 184990], ["1320", "1 320 UC", 239990], ["1800", "1 800 UC", 319900], ["2460", "2 460 UC", 439990], ["3850", "3 850 UC", 589990], ["5650", "5 650 UC", 899990], ["8100", "8 100 UC", 1159900]] },
    { id: "mobile_legends", title: "Mobile Legends", subtitle: "Diamond \xB7 GLOBAL", group: "games", image: "assets/donat/ml.webp", kind: "options", input: "game_id", options: [["86", "86 Diamond", 19990], ["172", "172 Diamond", 39990], ["257", "257 Diamond", 64990], ["344", "344 Diamond", 90990], ["429", "429 Diamond", 103990], ["514", "514 Diamond", 124990], ["600", "600 Diamond", 134990], ["706", "706 Diamond", 154990], ["963", "963 Diamond", 214990], ["1412", "1 412 Diamond", 299990], ["2367", "2 367 Diamond", 489990], ["2901", "2 901 Diamond", 584990], ["4738", "4 738 Diamond", 939990], ["double100", "50 + 50 Diamond (2\xD7)", 17990], ["double300", "150 + 150 Diamond (2\xD7)", 44990], ["double500", "250 + 250 Diamond (2\xD7)", 64990], ["double1000", "500 + 500 Diamond (2\xD7)", 139990], ["weekly", "Weekly Diamond Pass", 29900], ["twilight", "Twilight Pass", 119990]] },
    { id: "brawl_stars", title: "Brawl Stars", subtitle: "Gems / Pass", group: "games", image: "assets/donat/brawl.webp", kind: "options", input: "game_id", options: [["30", "30 Gems", 17990], ["80", "80 Gems", 44990], ["170", "170 Gems", 87990], ["360", "360 Gems", 171990], ["950", "950 Gems", 409990], ["2000", "2 000 Gems", 809990], ["pass", "Brawl Pass", 78990], ["passplus", "Brawl Pass Plus", 114990], ["propass", "PRO PASS", 184990]] },
    { id: "roblox", title: "Roblox", subtitle: "Robux", group: "games", image: "assets/donat/roblox.webp", kind: "options", input: "username", options: [["40", "40 Robux", 9990], ["80", "80 Robux", 18990], ["120", "120 Robux", 28990], ["160", "160 Robux", 38990], ["200", "200 Robux", 48990], ["500", "500 Robux", 81990], ["1000", "1 000 Robux", 159990], ["2000", "2 000 Robux", 314990], ["5250", "5 250 Robux", 781990], ["11000", "11 000 Robux", 1638990]] }
  ]
};

// src/catalog.mjs
var PRICES = [0, 3e3, 4e3, 6e3, 9e3, 13e3, 18e3, 25e3, 35e3, 5e4];
var CALIBRATION_LEGEND_PRICE = 9e4;
var MODE_SURCHARGE = 1e3;
var MIN_BOOST_PRICE = 12e3;
var MAX_AMOUNT = 1e8;
var MAX_STARS = 1e5;
var RANKS = [
  "\u041A\u0430\u043B\u0438\u0431\u0440\u043E\u0432\u043A\u0430",
  "Bronza",
  "Silver",
  "Gold",
  "Phoenix",
  "Ranger",
  "Champion",
  "Master",
  "Elite",
  "The Legend"
];
var MODES = /* @__PURE__ */ new Map([
  ["wing", "\u041D\u0430\u043F\u0430\u0440\u043D\u0438\u043A\u0438"],
  ["comp", "\u0421\u043E\u0440\u0435\u0432\u043D\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0439"],
  ["duel", "\u0414\u0443\u044D\u043B\u044C"]
]);
var products = new Map(catalog_default.items.map((product) => [product.id, product]));
var rankAliases = new Map([
  ["Calibration", 0],
  ["Kalibrovka", 0],
  ["Kalibrlash", 0],
  ["Bronze", 1],
  ["Fenix", 4],
  ["Elita", 8],
  ...RANKS.map((rank, index) => [rank, index])
]);
var RequestError = class extends Error {
  static {
    __name(this, "RequestError");
  }
  constructor(code, status = 400) {
    super(code);
    this.status = status;
  }
};
function integer(value, min = 1, max = Number.MAX_SAFE_INTEGER) {
  const number = typeof value === "string" && /^[0-9]+$/.test(value) ? Number(value) : value;
  if (!Number.isSafeInteger(number) || number < min || number > max) {
    throw new RequestError("invalid_number");
  }
  return number;
}
__name(integer, "integer");
function requestKey(value) {
  const key = value ?? crypto.randomUUID();
  if (typeof key !== "string" || !/^[A-Za-z0-9_-]{8,80}$/.test(key)) {
    throw new RequestError("invalid_request");
  }
  return key;
}
__name(requestKey, "requestKey");
function formatAmount(amount) {
  return String(amount).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}
__name(formatAmount, "formatAmount");
function playerName(value) {
  if (typeof value !== "string" || !value.trim() || [...value.trim()].length > 32 || /[\p{C}<>\u2028\u2029]/u.test(value.trim())) {
    throw new RequestError("invalid_game_id");
  }
  return value.trim();
}
__name(playerName, "playerName");
function normalizeBoost(data) {
  const from = data.fromIndex ?? rankAliases.get(data.from);
  const to = data.toIndex ?? rankAliases.get(data.to);
  const start = integer(from, 0, PRICES.length - 1);
  const end = integer(to, 0, PRICES.length - 1);
  if (end <= start || !MODES.has(data.mode)) throw new RequestError("invalid_rank");
  const base = start === 0 && end === PRICES.length - 1 ? CALIBRATION_LEGEND_PRICE : PRICES.slice(start + 1, end + 1).reduce((sum, price) => sum + price, 0);
  return {
    current_rank: start,
    target_rank: end,
    mode: data.mode,
    game_id: playerName(data.gameId),
    amount: Math.max(base, MIN_BOOST_PRICE) + (data.mode === "wing" ? 0 : MODE_SURCHARGE)
  };
}
__name(normalizeBoost, "normalizeBoost");
function productTitle(id) {
  return products.get(id)?.title || id;
}
__name(productTitle, "productTitle");
function quantityPrice(options, quantity) {
  const upperIndex = options.findIndex(([size]) => quantity <= Number(size));
  const [upper, , price] = options[upperIndex];
  if (quantity === Number(upper)) return price;
  const [lower, , previous] = options[upperIndex - 1];
  return previous + Math.ceil((quantity - Number(lower)) * (price - previous) / (Number(upper) - Number(lower)));
}
__name(quantityPrice, "quantityPrice");
function normalizeDonat(data, existing) {
  const item = products.get(data.product);
  if (!item) throw new RequestError("invalid_product");
  const packs = integer(data.packs ?? 1, 1, item.max_packs ?? 1);
  const isQuantity = item.kind === "quantity";
  const size = isQuantity ? integer(
    data.quantity ?? (item.id === "telegram_stars" ? data.option : void 0),
    item.min,
    item.max
  ) : null;
  const selected = String(size ?? data.option ?? "");
  if (item.max_packs && !/^[0-9]+$/.test(selected)) throw new RequestError("invalid_option");
  const optionCode = packs === 1 ? selected : selected + "x" + packs;
  const detail = typeof data.detail === "string" ? data.detail.trim() : "";
  if ([...detail].length > 64 || /[\p{C}<>\u2028\u2029]/u.test(detail) || item.input === "game_id" && !/^[A-Za-z0-9_#-]{4,40}$/.test(detail) || item.input === "username" && !/^@?[A-Za-z0-9_.]{3,32}$/.test(detail)) {
    throw new RequestError("invalid_detail");
  }
  let label;
  let amount;
  if (existing?.product === item.id && existing.option_code === optionCode) {
    label = existing.option_label;
    amount = existing.amount;
  } else if (isQuantity) {
    label = formatAmount(size) + " " + item.unit;
    amount = quantityPrice(item.options, size);
  } else {
    const option = item.options.find(([code]) => code === selected);
    if (!option) throw new RequestError("invalid_option");
    label = packs === 1 ? option[1] : packs + " \xD7 " + option[1];
    amount = option[2] * packs;
  }
  return { product: item.id, option_code: optionCode, option_label: label, detail, amount };
}
__name(normalizeDonat, "normalizeDonat");

// src/store.mjs
var RESERVATION_SECONDS = 180;
var NOTICE_LEASE_SECONDS = 60;
var epoch = /* @__PURE__ */ __name(() => Math.floor(Date.now() / 1e3), "epoch");
var utc = /* @__PURE__ */ __name(() => (/* @__PURE__ */ new Date()).toISOString(), "utc");
var orderTables = {
  order: {
    table: "orders",
    column: "order_id",
    method: "card",
    fields: ["mode", "current_rank", "target_rank", "game_id"]
  },
  donat: {
    table: "donat_orders",
    column: "donat_order_id",
    method: "method",
    fields: ["product", "option_code", "detail"]
  }
};
function checkOrder(existing, info, method, definition) {
  if (existing[definition.method] !== method || definition.fields.some((key) => existing[key] !== info[key])) {
    throw new RequestError("request_conflict", 409);
  }
}
__name(checkOrder, "checkOrder");
function checkOrderQuote(data, amount, stars) {
  if (integer(data.expectedAmount, 1, MAX_AMOUNT) !== amount) {
    throw new RequestError("order_quote_changed", 409);
  }
  if (stars && integer(data.expectedStars, 1, MAX_STARS) !== stars) {
    throw new RequestError("stars_quote_changed", 409);
  }
}
__name(checkOrderQuote, "checkOrderQuote");
function processing(payment) {
  return payment.status === "pending" && payment.checkout_reserved_at !== null && epoch() - payment.checkout_reserved_at < RESERVATION_SECONDS;
}
__name(processing, "processing");
var Store = class {
  static {
    __name(this, "Store");
  }
  constructor(db) {
    this.db = db;
  }
  stmt(sql, ...params) {
    return this.db.prepare(sql).bind(...params);
  }
  first(sql, ...params) {
    return this.stmt(sql, ...params).first();
  }
  async all(sql, ...params) {
    return (await this.stmt(sql, ...params).all()).results;
  }
  async eta() {
    const row = await this.first("SELECT min_hours, max_hours FROM boost_schedule WHERE id = 1");
    return [row?.min_hours ?? null, row?.max_hours ?? null];
  }
  async profile(userId, data) {
    const gameId = data.gameId == null ? null : playerName(data.gameId);
    const lang = data.lang ?? null;
    if (lang !== null && !["uz", "ru"].includes(lang)) throw new RequestError("invalid_language");
    return this.first(
      `
      INSERT INTO accounts (user_id, game_id, lang) VALUES (?, COALESCE(?, ''), COALESCE(?, 'uz'))
      ON CONFLICT (user_id) DO UPDATE SET game_id = COALESCE(?, game_id), lang = COALESCE(?, lang)
      RETURNING user_id, balance, stars_balance, game_id, lang`,
      userId,
      gameId,
      lang,
      gameId,
      lang
    );
  }
  async state(userId) {
    const [account, orders, payments] = await this.db.batch([
      this.stmt("SELECT balance, stars_balance, game_id, lang FROM accounts WHERE user_id = ?", userId),
      this.stmt(`SELECT id, mode, current_rank, target_rank, game_id, amount, card, status,
                        created_at, eta_min_hours, eta_max_hours
                 FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 100`, userId),
      this.stmt(`SELECT id, order_id, donat_order_id, kind, method, amount, stars, status, created_at
                 FROM payments WHERE user_id = ? ORDER BY id DESC LIMIT 100`, userId)
    ]);
    const user = account.results[0];
    return {
      balance: user?.balance ?? 0,
      starsBalance: user?.stars_balance ?? 0,
      gameId: user?.game_id ?? "",
      lang: user?.lang ?? "uz",
      orders: orders.results,
      payments: payments.results,
      uzcardTest: false
    };
  }
  async donatState(userId) {
    return this.all(`SELECT id, product, option_label, detail, amount, method, status, created_at
                     FROM donat_orders WHERE user_id = ? ORDER BY id DESC LIMIT 100`, userId);
  }
  async createOrder(kind, user, data, rate2) {
    const definition = orderTables[kind];
    const { table, column } = definition;
    const method = data.paymentMethod;
    const key = requestKey(data.requestId);
    const byKey = `FROM ${table} WHERE user_id = ? AND request_key = ?`;
    const selectOrder = `SELECT * ${byKey}`;
    const selectPayment = `SELECT * FROM payments WHERE ${column} = (SELECT id ${byKey})`;
    const saved = await this.first(selectOrder, user.id, key);
    const info = kind === "order" ? normalizeBoost(data) : normalizeDonat(data, saved);
    if (saved) {
      checkOrder(saved, info, method, definition);
      const payment = await this.first(selectPayment, user.id, key);
      if (!payment) throw new RequestError("payment_not_found", 409);
      checkOrderQuote(data, saved.amount, payment.stars);
      return { order: saved, payment };
    }
    const stars = method === "stars" ? integer(Math.ceil(info.amount / rate2), 1, MAX_STARS) : 0;
    checkOrderQuote(data, info.amount, stars);
    const lang = data.lang === "ru" ? "ru" : "uz";
    const status = method === "balance" ? "paid" : "pending";
    const created = utc();
    const insert = kind === "order" ? this.stmt(
      `
          INSERT INTO orders (user_id, username, mode, current_rank, target_rank, game_id,
              amount, card, status, created_at, request_key, lang, eta_min_hours, eta_max_hours)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
              (SELECT min_hours FROM boost_schedule WHERE id = 1),
              (SELECT max_hours FROM boost_schedule WHERE id = 1))
          ON CONFLICT (user_id, request_key) DO NOTHING`,
      user.id,
      user.username,
      info.mode,
      info.current_rank,
      info.target_rank,
      info.game_id,
      info.amount,
      method,
      status,
      created,
      key,
      lang
    ) : this.stmt(
      `
          INSERT INTO donat_orders (user_id, username, product, option_code, option_label, detail,
              amount, method, lang, status, request_key, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          ON CONFLICT (user_id, request_key) DO NOTHING`,
      user.id,
      user.username,
      info.product,
      info.option_code,
      info.option_label,
      info.detail,
      info.amount,
      method,
      lang,
      status,
      key,
      created
    );
    try {
      const [, , orders, payments] = await this.db.batch([
        insert,
        this.stmt(
          `
          INSERT INTO payments (user_id, ${column}, kind, method, amount, stars, status,
              request_key, created_at, admin_notice_pending)
          SELECT user_id, id, ?, ?, amount, ?, status, ? || id, created_at, ? ${byKey}
          AND ${definition.method} = ? AND status = ? AND amount = ?
          ON CONFLICT (${column}) DO NOTHING`,
          kind,
          method,
          stars,
          kind + ":",
          Number(status === "paid"),
          user.id,
          key,
          method,
          status,
          info.amount
        ),
        this.stmt(selectOrder, user.id, key),
        this.stmt(selectPayment, user.id, key)
      ]);
      const order = orders.results[0];
      const payment = payments.results[0];
      checkOrder(order, info, method, definition);
      if (!payment) throw new RequestError("payment_not_found", 409);
      checkOrderQuote(data, order.amount, payment.stars);
      return { order, payment };
    } catch (error) {
      if (String(error.message).includes("insufficient_balance")) {
        throw new RequestError("insufficient_balance", 409);
      }
      throw error;
    }
  }
  async createTopup(userId, data, rate2) {
    const stars = integer(data.stars, 1, MAX_STARS);
    const submittedRate = integer(data.starsRate, 1, 1e6);
    const amount = integer(stars * submittedRate, 1, MAX_AMOUNT);
    const key = requestKey(data.requestId);
    const select = "SELECT * FROM payments WHERE user_id = ? AND request_key = ?";
    let payment = await this.first(select, userId, key);
    if (!payment) {
      if (submittedRate !== rate2) throw new RequestError("stars_quote_changed", 409);
      payment = await this.first(
        `
        INSERT INTO payments (user_id, kind, method, amount, stars, request_key, created_at)
        VALUES (?, 'topup', 'stars', ?, ?, ?, ?)
        ON CONFLICT (user_id, request_key) DO NOTHING RETURNING *`,
        userId,
        amount,
        stars,
        key,
        utc()
      );
      payment ??= await this.first(select, userId, key);
    }
    if (payment.kind !== "topup" || payment.method !== "stars" || payment.stars !== stars || payment.amount !== amount) {
      throw new RequestError("request_conflict", 409);
    }
    return payment;
  }
  async userPayment(id, userId) {
    const payment = await this.first(`
      SELECT * FROM payments WHERE id = ? AND user_id = ? AND method = 'stars'`, id, userId);
    if (!payment) throw new RequestError("payment_not_found", 404);
    return payment;
  }
  async paymentOrder(payment) {
    if (payment.kind === "topup") return null;
    const { table, column } = orderTables[payment.kind];
    return this.first(
      `SELECT * FROM ${table} WHERE id = ? AND user_id = ?`,
      payment[column],
      payment.user_id
    );
  }
  reserveCheckout(id, userId, stars, queryId) {
    const now2 = epoch();
    return this.first(
      `
      UPDATE payments SET checkout_query_id = ?, checkout_reserved_at = ?
      WHERE id = ? AND user_id = ? AND method = 'stars' AND stars = ? AND status = 'pending'
      AND (checkout_query_id IS NULL OR checkout_query_id = ? OR checkout_reserved_at <= ?)
      RETURNING id`,
      queryId,
      now2,
      id,
      userId,
      stars,
      queryId,
      now2 - RESERVATION_SECONDS
    );
  }
  async settle(id, userId, successful) {
    const chargeId = successful.telegram_payment_charge_id;
    const total = successful.total_amount;
    let payment;
    if (id && successful.currency === "XTR") {
      try {
        payment = await this.first(`
          UPDATE payments SET status = 'paid', telegram_charge_id = ?, checkout_reserved_at = NULL,
              admin_notice_pending = CASE WHEN kind = 'topup' THEN 0 ELSE 1 END
          WHERE id = ? AND user_id = ? AND method = 'stars' AND stars = ? AND status = 'pending'
          AND NOT EXISTS (SELECT 1 FROM payments WHERE telegram_charge_id = ?)
          RETURNING *`, chargeId, id, userId, total, chargeId);
      } catch (error) {
        if (!String(error.message).includes("invalid_order_status")) throw error;
      }
      if (payment) return { payment, changed: true };
      payment = await this.first(`
        SELECT * FROM payments WHERE id = ? AND user_id = ? AND method = 'stars'
          AND stars = ? AND status = 'paid' AND telegram_charge_id = ?`, id, userId, total, chargeId);
      if (payment) return { payment, changed: false };
    }
    await this.stmt(
      `
      INSERT INTO payment_exceptions (charge_id, payment_id, user_id, currency, total_amount, created_at)
      VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT (charge_id) DO NOTHING`,
      chargeId,
      id,
      userId,
      successful.currency,
      total,
      utc()
    ).run();
    return null;
  }
  dueNotices() {
    return this.all(`
      SELECT id FROM payments WHERE admin_notice_pending = 1 AND notice_lease_until <= ?
      ORDER BY notice_lease_until, id LIMIT 8`, epoch());
  }
  claimNotice(id) {
    const now2 = epoch();
    return this.first(`
      UPDATE payments SET notice_lease_until = ?
      WHERE id = ? AND status = 'paid' AND admin_notice_pending = 1 AND notice_lease_until <= ?
      RETURNING *`, now2 + NOTICE_LEASE_SECONDS, id, now2);
  }
  async markNotified(payment) {
    await this.stmt(`
      UPDATE payments SET admin_notice_pending = 0, notice_lease_until = 0
      WHERE id = ? AND notice_lease_until = ?`, payment.id, payment.notice_lease_until).run();
  }
};

// src/payment-terms.mjs
function paymentTerms(config, rate2) {
  const username2 = config.support || config.name;
  const contact = `<a href="https://t.me/${username2}">@${username2}</a>`;
  const amount = formatAmount(rate2);
  return new Response(`<!doctype html>
<html lang="uz">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ARSLAN BOOST \xB7 To\u2018lov shartlari</title>
  <style>
    :root { color-scheme: dark; background: #0b1628; color: #f5f9ff; font: 16px/1.55 system-ui, sans-serif; }
    main { box-sizing: border-box; max-width: 36rem; margin: 0 auto; padding: 1.5rem 1rem 2.5rem; }
    section { padding: 1rem 1.25rem; border: 1px solid #346392; border-radius: 1rem; margin-top: 1rem; background: #102238; }
    h1 { font-size: 1.5rem; margin: 0; }
    h2 { font-size: 1.15rem; margin: 0; }
    p { color: #d1dff1; margin: .75rem 0 0; }
    a { color: #71dcff; }
  </style>
</head>
<body><main>
  <h1>ARSLAN BOOST</h1>
  <section aria-labelledby="terms-uz">
    <h2 id="terms-uz">To\u2018lov shartlari</h2>
    <p>Telegramdagi buyurtmalar uchun to\u2018lov Stars orqali amalga oshiriladi. Mahsulot va Stars miqdori tasdiqlashdan oldin hisobda ko\u2018rsatiladi.</p>
    ${rate2 ? `<p>Do\u2018kon balansini to\u2018ldirishda 1 \u2B50 uchun ${amount} so\u2018m hisoblanadi. Balansdan ARSLAN BOOST\u2019dagi xaridlar uchun foydalanish mumkin.</p>` : ""}
    <p>To\u2018lov yoki mablag\u2018ni qaytarish bo\u2018yicha do\u2018kon yordam xizmatiga murojaat qiling. ${contact} yoki botdagi /paysupport orqali buyurtma yoki to\u2018lov raqamini yuboring. Xaridlar bo\u2018yicha murojaatlarni ARSLAN BOOST ko\u2018rib chiqadi.</p>
  </section>
  <section lang="ru" aria-labelledby="terms-ru">
    <h2 id="terms-ru">\u0423\u0441\u043B\u043E\u0432\u0438\u044F \u043E\u043F\u043B\u0430\u0442\u044B</h2>
    <p>\u0417\u0430\u043A\u0430\u0437\u044B \u0432 Telegram \u043E\u043F\u043B\u0430\u0447\u0438\u0432\u0430\u044E\u0442\u0441\u044F \u0432 Stars. \u0422\u043E\u0432\u0430\u0440 \u0438 \u0441\u0443\u043C\u043C\u0430 \u0432 Stars \u0432\u0438\u0434\u043D\u044B \u0432 \u0441\u0447\u0451\u0442\u0435 \u0434\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F.</p>
    ${rate2 ? `<p>\u041F\u0440\u0438 \u043F\u043E\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u0431\u0430\u043B\u0430\u043D\u0441\u0430 \u043C\u0430\u0433\u0430\u0437\u0438\u043D\u0430 1 \u2B50 \u0437\u0430\u0447\u0438\u0441\u043B\u044F\u0435\u0442\u0441\u044F \u043A\u0430\u043A ${amount} \u0441\u0443\u043C. \u0411\u0430\u043B\u0430\u043D\u0441 \u043C\u043E\u0436\u043D\u043E \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u044C \u0434\u043B\u044F \u043F\u043E\u043A\u0443\u043F\u043E\u043A \u0432 ARSLAN BOOST.</p>` : ""}
    <p>\u041F\u043E \u0432\u043E\u043F\u0440\u043E\u0441\u0430\u043C \u043E\u043F\u043B\u0430\u0442\u044B \u0438 \u0432\u043E\u0437\u0432\u0440\u0430\u0442\u0430 \u043E\u0431\u0440\u0430\u0449\u0430\u0439\u0442\u0435\u0441\u044C \u0432 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443 \u043C\u0430\u0433\u0430\u0437\u0438\u043D\u0430. \u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043D\u043E\u043C\u0435\u0440 \u0437\u0430\u043A\u0430\u0437\u0430 \u0438\u043B\u0438 \u043F\u043B\u0430\u0442\u0435\u0436\u0430 \u0432 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0438 ${contact} \u0438\u043B\u0438 \u0447\u0435\u0440\u0435\u0437 /paysupport \u0432 \u0431\u043E\u0442\u0435. \u041E\u0431\u0440\u0430\u0449\u0435\u043D\u0438\u044F \u043F\u043E \u043F\u043E\u043A\u0443\u043F\u043A\u0430\u043C \u0440\u0430\u0441\u0441\u043C\u0430\u0442\u0440\u0438\u0432\u0430\u0435\u0442 ARSLAN BOOST.</p>
  </section>
</main></body></html>`, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "no-store",
      "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'",
      "Referrer-Policy": "no-referrer",
      "X-Content-Type-Options": "nosniff"
    }
  });
}
__name(paymentTerms, "paymentTerms");

// src/telegram.mjs
var tokenPattern = /^[0-9]+:[A-Za-z0-9_-]+$/;
var secretPattern = /^[A-Za-z0-9_-]{32,256}$/;
var encoder = new TextEncoder();
var botToken = /* @__PURE__ */ __name((env) => env.BOT_TOKEN?.trim() || "", "botToken");
var validToken = /* @__PURE__ */ __name((value) => tokenPattern.test(value), "validToken");
var validSecret = /* @__PURE__ */ __name((value) => typeof value === "string" && secretPattern.test(value), "validSecret");
var isTest = /* @__PURE__ */ __name((env) => env.TELEGRAM_TEST_ENV === "1", "isTest");
function matchesSecret(actual, expected) {
  if (!validSecret(actual) || !validSecret(expected) || actual.length !== expected.length) return false;
  let difference = 0;
  for (let index = 0; index < expected.length; index++) {
    difference |= actual.charCodeAt(index) ^ expected.charCodeAt(index);
  }
  return difference === 0;
}
__name(matchesSecret, "matchesSecret");
function username(value) {
  return typeof value === "string" && /^[A-Za-z0-9_]{5,32}$/.test(value) ? value : "";
}
__name(username, "username");
function telegramId(value) {
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed > 0 ? parsed : 0;
}
__name(telegramId, "telegramId");
async function telegram(env, method, body = {}) {
  const token = botToken(env);
  if (!validToken(token)) throw new RequestError("bot_not_configured", 503);
  const path = isTest(env) ? "/test/" : "/";
  let response;
  try {
    response = await fetch("https://api.telegram.org/bot" + token + path + method, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(method === "answerPreCheckoutQuery" ? 4e3 : 8e3)
    });
  } catch {
    throw new RequestError("telegram_unavailable", 502);
  }
  const data = await response.json().catch(() => null);
  if (!response.ok || data?.ok !== true) {
    const error = new RequestError("telegram_unavailable", 502);
    error.telegramCode = data?.error_code ?? response.status;
    throw error;
  }
  return data.result;
}
__name(telegram, "telegram");
async function authenticate(request, env) {
  const raw = request.headers.get("X-Telegram-Init-Data");
  const token = botToken(env);
  if (!raw || raw.length > 16e3 || !validToken(token)) throw new RequestError("unauthorized", 401);
  const params = new URLSearchParams(raw);
  const fields = /* @__PURE__ */ new Map();
  for (const [key2, value] of params) {
    if (fields.has(key2)) throw new RequestError("unauthorized", 401);
    fields.set(key2, value);
  }
  const hash = fields.get("hash") || "";
  if (!/^[0-9a-f]{64}$/.test(hash)) throw new RequestError("unauthorized", 401);
  fields.delete("hash");
  const message = [...fields.keys()].sort().map((key2) => key2 + "=" + fields.get(key2)).join("\n");
  const algorithm = { name: "HMAC", hash: "SHA-256" };
  const salt = await crypto.subtle.importKey("raw", encoder.encode("WebAppData"), algorithm, false, ["sign"]);
  const derived = await crypto.subtle.sign("HMAC", salt, encoder.encode(token));
  const key = await crypto.subtle.importKey("raw", derived, algorithm, false, ["verify"]);
  const supplied = Uint8Array.from(hash.match(/../g), (pair) => parseInt(pair, 16));
  if (!await crypto.subtle.verify("HMAC", key, supplied, encoder.encode(message))) {
    throw new RequestError("unauthorized", 401);
  }
  const authDate = Number(fields.get("auth_date"));
  const now2 = Math.floor(Date.now() / 1e3);
  if (!Number.isSafeInteger(authDate) || authDate < now2 - 86400 || authDate > now2 + 30) {
    throw new RequestError("session_expired", 401);
  }
  let user;
  try {
    user = JSON.parse(fields.get("user"));
    const id = integer(user?.id);
    return { id, username: username(user.username) };
  } catch {
    throw new RequestError("unauthorized", 401);
  }
}
__name(authenticate, "authenticate");

// src/partners.mjs
var minimum = 1e4;
var earned = /* @__PURE__ */ __name((operator) => `SELECT COALESCE(SUM(commission),0) FROM partner_earnings
  WHERE partner=? AND available_at ${operator} ?`, "earned");
var reserved = "SELECT COALESCE(SUM(amount),0) FROM partner_payouts WHERE partner=? AND status IN ('pending','paid')";
var nextDay = /* @__PURE__ */ __name(() => new Date(Date.now() + 864e5).toISOString(), "nextDay");
async function bindPartner(store, buyer, parameter) {
  const code = /^ref_([a-z0-9]{24})$/.exec(parameter || "")?.[1];
  if (!code) return;
  await store.stmt(`INSERT INTO partner_buyers(buyer,partner,joined_at)
    SELECT ?,user_id,? FROM partners WHERE code=? AND status='approved' AND user_id<>?
    ON CONFLICT(buyer) DO NOTHING`, buyer, utc(), code, buyer).run();
}
__name(bindPartner, "bindPartner");
async function dashboard(store, config, user) {
  const row = await store.first("SELECT status,code FROM partners WHERE user_id=?", user);
  const status = row?.status ?? "none";
  if (status !== "approved") return { status, minWithdraw: minimum };
  const time = utc();
  const [totals, history, withdrawals] = await store.db.batch([
    store.stmt(
      `SELECT (${earned("<=")}) AS earned, (${earned(">")}) AS pending,
      (${reserved}) AS reserved, (SELECT COUNT(*) FROM partner_buyers WHERE partner=?) AS clients`,
      user,
      time,
      user,
      time,
      user,
      user
    ),
    store.stmt(`SELECT kind,order_id AS orderId,commission,
      CASE WHEN available_at<=? THEN 'available' ELSE 'pending' END AS status
      FROM partner_earnings WHERE partner=? ORDER BY available_at DESC LIMIT 15`, time, user),
    store.stmt("SELECT id,amount,status FROM partner_payouts WHERE partner=? ORDER BY id DESC LIMIT 10", user)
  ]);
  const total = totals.results[0];
  return {
    status,
    minWithdraw: minimum,
    clients: total.clients,
    pending: total.pending,
    available: Math.max(0, total.earned - total.reserved),
    history: history.results,
    withdrawals: withdrawals.results,
    url: config.name ? `https://t.me/${config.name}?start=ref_${row.code}` : null
  };
}
__name(dashboard, "dashboard");
async function adminMessage(env, config, text, buttons) {
  await telegram(env, "sendMessage", {
    chat_id: config.admin,
    text,
    reply_markup: { inline_keyboard: [buttons] }
  });
}
__name(adminMessage, "adminMessage");
async function partnerApi(env, ctx, store, config, path, user, data) {
  if (path === "referral/me") return dashboard(store, config, user.id);
  if (!config.admin) throw new RequestError("admin_not_configured", 503);
  if (path === "referral/apply") {
    const row2 = await store.first(`INSERT INTO partners(user_id,username,status) VALUES (?,?,'pending')
      ON CONFLICT(user_id) DO UPDATE SET username=excluded.username,status='pending'
      WHERE partners.status='rejected' RETURNING status`, user.id, user.username);
    if (row2) ctx.waitUntil(adminMessage(env, config, `\u0417\u0430\u044F\u0432\u043A\u0430 \u043F\u0430\u0440\u0442\u043D\u0451\u0440\u0430 \xB7 ID ${user.id}`, [
      { text: "\u041E\u0434\u043E\u0431\u0440\u0438\u0442\u044C", callback_data: `partner:approve:${user.id}` },
      { text: "\u041E\u0442\u043A\u043B\u043E\u043D\u0438\u0442\u044C", callback_data: `partner:reject:${user.id}` }
    ]).catch(() => console.error("Partner application notice failed")));
    const status = row2 ?? await store.first("SELECT status FROM partners WHERE user_id=?", user.id);
    return { status: status.status };
  }
  const amount = integer(data.amount, minimum, 1e11);
  const dest = typeof data.destination === "string" ? data.destination.trim() : "";
  if (dest.length < 5 || dest.length > 120 || /[\p{C}]/u.test(dest)) throw new RequestError("invalid_payout_details");
  const row = await store.first(`INSERT INTO partner_payouts(partner,amount,destination)
    SELECT ?,?,? WHERE EXISTS (SELECT 1 FROM partners WHERE user_id=? AND status='approved')
    AND (${earned("<=")}) - (${reserved}) >= ?
    AND NOT EXISTS (SELECT 1 FROM partner_payouts WHERE partner=? AND status='pending')
    RETURNING id`, user.id, amount, dest, user.id, user.id, utc(), user.id, amount, user.id);
  if (!row) throw new RequestError("insufficient_referral_balance", 409);
  ctx.waitUntil(adminMessage(
    env,
    config,
    `\u0417\u0430\u043F\u0440\u043E\u0441 \u0432\u044B\u043F\u043B\u0430\u0442\u044B #${row.id}
ID ${user.id} \xB7 ${formatAmount(amount)} UZS
${dest}`,
    [
      { text: "\u041E\u0442\u043C\u0435\u0442\u0438\u0442\u044C \u0432\u044B\u043F\u043B\u0430\u0447\u0435\u043D\u043D\u043E\u0439", callback_data: `partner:paid:${row.id}` },
      { text: "\u041E\u0442\u043A\u043B\u043E\u043D\u0438\u0442\u044C", callback_data: `partner:deny:${row.id}` }
    ]
  ).catch(() => console.error("Partner payout notice failed")));
  return { id: row.id, status: "pending" };
}
__name(partnerApi, "partnerApi");
async function partnerCallback(env, store, config, query) {
  const match = /^partner:(approve|reject|paid|deny):(\d+)$/.exec(query.data || "");
  if (!match) return false;
  let text = "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430";
  if (query.from?.id === config.admin && config.admin) {
    const [, action, rawId] = match;
    const id = integer(rawId);
    if (["approve", "reject"].includes(action)) {
      const approve = action === "approve";
      const code = approve ? crypto.randomUUID().replaceAll("-", "").slice(0, 24) : null;
      const row = await store.first(
        "UPDATE partners SET status=?,code=? WHERE user_id=? AND status='pending' RETURNING user_id",
        approve ? "approved" : "rejected",
        code,
        id
      );
      text = row ? approve ? "\u041F\u0430\u0440\u0442\u043D\u0451\u0440 \u043E\u0434\u043E\u0431\u0440\u0435\u043D" : "\u0417\u0430\u044F\u0432\u043A\u0430 \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u0430" : "\u0417\u0430\u044F\u0432\u043A\u0430 \u0443\u0436\u0435 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u0430\u043D\u0430";
    } else {
      const row = await store.first(
        "UPDATE partner_payouts SET status=? WHERE id=? AND status='pending' RETURNING id",
        action === "paid" ? "paid" : "rejected",
        id
      );
      text = row ? "\u0421\u0442\u0430\u0442\u0443\u0441 \u0432\u044B\u043F\u043B\u0430\u0442\u044B \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D" : "\u0417\u0430\u044F\u0432\u043A\u0430 \u0443\u0436\u0435 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u0430\u043D\u0430";
    }
  }
  await telegram(env, "answerCallbackQuery", { callback_query_id: query.id, text });
  return true;
}
__name(partnerCallback, "partnerCallback");
async function fulfillOrder(store, kind, id, cost) {
  if (!["boost", "donat"].includes(kind)) throw new RequestError("invalid_kind");
  const { table } = orderTables[kind === "boost" ? "order" : "donat"];
  const [, order] = await store.db.batch([
    store.stmt(`INSERT INTO partner_earnings(kind,order_id,partner,commission,available_at)
      SELECT ?,o.id,b.partner,CAST(MAX(0,o.amount-?)/2 AS INTEGER),?
      FROM ${table} o JOIN partner_buyers b ON b.buyer=o.user_id
      JOIN partners p ON p.user_id=b.partner AND p.status='approved'
      WHERE o.id=? AND o.status IN ('paid','in_progress') AND b.joined_at<=o.created_at
      ON CONFLICT(kind,order_id) DO NOTHING`, kind, cost, nextDay(), id),
    store.stmt(`UPDATE ${table} SET status='fulfilled' WHERE id=? AND status IN ('paid','in_progress')
      RETURNING id,user_id,lang`, id)
  ]);
  return order.results[0];
}
__name(fulfillOrder, "fulfillOrder");

// src/p2p-notice.mjs
var AMOUNT = /^(?:[0-9]+|[0-9]{1,3}(?:[ ][0-9]{3})+)(?:[.,][0-9]{2})?$/;
var REF = /^[A-Z0-9][A-Z0-9_-]{5,63}$/;
var DATE = /^(\d{2})[./](\d{2})[./](\d{4}|\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/;
var ISO_DATE = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/;
var CREDIT = /^(?:[+][ \t]*|(?:пополнение|popolnenie|kirim|to['‘’]ldirish)[ \t]*[:=]?[ \t]*[+]?[ \t]*)([0-9][0-9 .,]*)\s*(?:UZS|сум(?:ов)?|so['‘’]m)(?=$|[\s;])/iu;
var CARD = /^(?:карта|karta|card)\s*[:=]\s*(?:[*•xX -]+\s*)?([0-9]{4})$/iu;
var BANK_REF = /^(?:RRN|ref(?:erence)?|операция|operatsiya|transaction(?: id)?)\s*[:=]\s*([A-Z0-9_-]{6,64})$/iu;
var BANK_DATE = /^(?:дата|время|date|time|sana)\s*[:=]\s*(.+)$/iu;
function parseAmount(text) {
  const normalized = text.trim().replace(/[\u00a0\u202f]/g, " ");
  if (!AMOUNT.test(normalized)) throw new RequestError("p2p_amount_invalid");
  const [whole, tiyin] = normalized.split(/[.,]/);
  if (tiyin && tiyin !== "00") throw new RequestError("p2p_fractional_amount");
  return integer(Number(whole.replaceAll(" ", "")), 1, 100000099);
}
__name(parseAmount, "parseAmount");
function reference(value) {
  const ref = typeof value === "string" ? value.trim().toUpperCase() : "";
  if (!REF.test(ref)) throw new RequestError("p2p_reference_required");
  return ref;
}
__name(reference, "reference");
function parseDate(value) {
  const local = DATE.exec(value);
  const iso = local ? `${local[3].length === 2 ? "20" + local[3] : local[3]}-${local[2]}-${local[1]}T${local[4]}:${local[5]}:${local[6] || "00"}+05:00` : value;
  if (!ISO_DATE.test(iso)) throw new RequestError("p2p_bank_time_required");
  const date = Date.parse(iso);
  const wallDate = Date.parse(iso.slice(0, 19) + "Z");
  if (!Number.isFinite(date) || !Number.isFinite(wallDate) || new Date(wallDate).toISOString().slice(0, 19) !== iso.slice(0, 19)) {
    throw new RequestError("p2p_bank_time_required");
  }
  return { occurredAt: Math.floor(date / 1e3), precision: local && !local[6] ? 60 : 1 };
}
__name(parseDate, "parseDate");
function singleMatch(lines, regex, code) {
  const matches = lines.map((line) => regex.exec(line)).filter(Boolean);
  if (matches.length !== 1) throw new RequestError(code);
  return matches[0][1];
}
__name(singleMatch, "singleMatch");
function parseIncoming(text) {
  if (typeof text !== "string" || text.length > 2500 || /(?:\botp\b|код подтверждения|verification code|tasdiqlash kodi|one.time password)/iu.test(text)) {
    throw new RequestError("p2p_notice_unsupported");
  }
  const lines = text.split(/\r?\n/).map((line) => line.trim().replace(/[\u00a0\u202f]/g, " ").replace(/\uFE0F/g, "").replace(/^[➕]/u, "+").replace(/^💳\s*/u, "Card: ").replace(/^[🕐-🕧]\s*/u, "Date: "));
  if (lines.some((line) => /^(?:🔴\s*)?(?:platezh|платеж|платёж|списание)\s*$/iu.test(line) || /^[-−➖]\s*[0-9]/u.test(line))) throw new RequestError("p2p_credit_line_required");
  const credit = singleMatch(lines, CREDIT, "p2p_credit_line_required");
  const last4 = singleMatch(lines, CARD, "p2p_card_last4_required");
  const bankRef = reference(singleMatch(lines, BANK_REF, "p2p_reference_required"));
  const date = parseDate(singleMatch(lines, BANK_DATE, "p2p_bank_time_required"));
  return { amount: parseAmount(credit), last4, bankRef, ...date };
}
__name(parseIncoming, "parseIncoming");

// src/p2p.mjs
var now = /* @__PURE__ */ __name(() => Math.floor(Date.now() / 1e3), "now");
var HOLD_SECONDS = 86400;
var MIN_AMOUNT = 1e4;
var METHOD = /^(humo|uzcard)$/;
var CARD_ID = /^[a-z0-9_-]{2,32}$/;
var EVENT_ID = /^[A-Za-z0-9:_.-]{1,120}$/;
function p2pAccess(env, userId) {
  return env.P2P_MODE === "private" && Boolean(telegramId(env.ADMIN_ID)) && Boolean(env.P2P_USERS?.trim().split(/\s+/).includes(String(userId)));
}
__name(p2pAccess, "p2pAccess");
function requireAccess(env, userId) {
  if (!p2pAccess(env, userId)) throw new RequestError("p2p_disabled", 403);
}
__name(requireAccess, "requireAccess");
function cards(env) {
  let input;
  try {
    input = JSON.parse(env.P2P_CARDS || "[]");
  } catch {
    input = null;
  }
  if (!Array.isArray(input) || input.length > 10) throw new RequestError("p2p_cards_invalid", 503);
  const ids = /* @__PURE__ */ new Set();
  const keys = /* @__PURE__ */ new Set();
  return input.map((card) => {
    const { id, method, number, holder } = card || {};
    const key = method + ":" + number?.slice?.(-4);
    if (typeof id !== "string" || !CARD_ID.test(id) || ids.has(id) || keys.has(key) || typeof method !== "string" || !METHOD.test(method) || typeof number !== "string" || !/^[0-9]{16}$/.test(number) || typeof holder !== "string" || !holder.trim() || holder.length > 64 || /[\p{C}<>]/u.test(holder)) {
      throw new RequestError("p2p_cards_invalid", 503);
    }
    ids.add(id);
    keys.add(key);
    return { id, method, number, holder, enabled: card.enabled !== false };
  });
}
__name(cards, "cards");
async function availableCards(store, env) {
  const flags = new Map((await store.all("SELECT card_id, enabled FROM p2p_card_flags")).map((row) => [row.card_id, Boolean(row.enabled)]));
  return cards(env).filter((card) => flags.get(card.id) ?? card.enabled);
}
__name(availableCards, "availableCards");
async function expireInvoices(store, at = now()) {
  await store.stmt("UPDATE invoices SET status = 'expired' WHERE status = 'pending' AND expires_at <= ?", at).run();
}
__name(expireInvoices, "expireInvoices");
function ownedInvoice(store, id, userId) {
  return store.first("SELECT * FROM invoices WHERE id = ? AND user_id = ?", id, userId);
}
__name(ownedInvoice, "ownedInvoice");
function publicInvoice(env, row, config) {
  const time = now();
  const status = row.status === "pending" && row.expires_at <= time ? "expired" : row.status;
  const card = status === "pending" ? cards(env).find((item) => item.id === row.card_id && item.number.endsWith(row.card_number)) : null;
  return {
    id: row.id,
    baseAmount: row.base_amount,
    uniqueAmount: row.unique_amount,
    method: row.payment_method,
    status,
    createdAt: row.created_at,
    expiresAt: row.expires_at,
    serverTime: time,
    checkedAt: row.checked_at,
    ...card ? { cardNumber: card.number, cardHolder: row.card_holder } : {},
    ...config.name && ["pending", "expired"].includes(status) && row.checked_at !== null && (time >= row.checked_at + 60 || status === "expired") ? { receiptLink: `https://t.me/${config.name}?start=p2p_${row.id}` } : {}
  };
}
__name(publicInvoice, "publicInvoice");
async function createInvoice(store, env, user, data) {
  const amount = integer(data.amount, MIN_AMOUNT, MAX_AMOUNT);
  const key = requestKey(data.requestId);
  const method = data.method;
  if (typeof method !== "string" || !METHOD.test(method)) throw new RequestError("invalid_payment_method");
  const retry = "SELECT * FROM invoices WHERE user_id = ? AND request_id = ?";
  const existing = await store.first(retry, user.id, key);
  if (existing) {
    if (existing.base_amount !== amount || existing.payment_method !== method) {
      throw new RequestError("request_conflict", 409);
    }
    return existing;
  }
  const candidates = (await availableCards(store, env)).filter((card) => card.method === method);
  if (!candidates.length) throw new RequestError("p2p_method_unavailable", 409);
  const time = now();
  const active = "SELECT * FROM invoices WHERE user_id = ? AND status = 'pending'";
  const [, inserted, open, saved] = await store.db.batch([
    store.stmt("UPDATE invoices SET status = 'expired' WHERE status = 'pending' AND expires_at <= ?", time),
    store.stmt(
      `
      WITH RECURSIVE offsets(n) AS (
        VALUES (1) UNION ALL SELECT n + 1 FROM offsets WHERE n < 99
      ), available AS (
        SELECT config.key AS card_id, config.value AS metadata,
          COALESCE((SELECT MAX(created_at) FROM invoices WHERE invoices.card_id = config.key), 0) AS last_used
        FROM json_each(?) AS config
        LEFT JOIN p2p_card_flags flag ON flag.card_id = config.key
        WHERE COALESCE(flag.enabled, json_extract(config.value, '$.enabled')) = 1
      )
      INSERT INTO invoices (
        user_id, request_id, base_amount, unique_amount, payment_method, card_id,
        card_number, card_holder, status, created_at, expires_at, lang
      )
      SELECT ?, ?, ?, ? + n, ?, available.card_id,
        json_extract(available.metadata, '$.last4'),
        json_extract(available.metadata, '$.holder'), 'pending', ?, ?, ?
      FROM offsets CROSS JOIN available
      WHERE NOT EXISTS (SELECT 1 FROM invoices WHERE unique_amount = ? + n AND status = 'pending')
      AND NOT EXISTS (SELECT 1 FROM invoices WHERE card_id = available.card_id AND unique_amount = ? + n
        AND (status = 'manual_check' OR created_at >= ?))
      AND NOT EXISTS (SELECT 1 FROM invoices WHERE user_id = ? AND status = 'pending')
      AND NOT EXISTS (SELECT 1 FROM invoices WHERE user_id = ? AND request_id = ?)
      ORDER BY available.last_used, available.card_id, n LIMIT 1 RETURNING *`,
      JSON.stringify(Object.fromEntries(candidates.map((card) => [card.id, {
        last4: card.number.slice(-4),
        holder: card.holder,
        enabled: Number(card.enabled)
      }]))),
      user.id,
      key,
      amount,
      amount,
      method,
      time,
      time + 600,
      data.lang === "ru" ? "ru" : "uz",
      amount,
      amount,
      time - HOLD_SECONDS,
      user.id,
      user.id,
      key
    ),
    store.stmt(active, user.id),
    store.stmt(retry, user.id, key)
  ]);
  const result = inserted.results[0] || saved.results[0];
  if (result) {
    if (result.base_amount !== amount || result.payment_method !== method) throw new RequestError("request_conflict", 409);
    return result;
  }
  if (open.results[0]) return open.results[0];
  throw new RequestError("p2p_amount_unavailable", 409);
}
__name(createInvoice, "createInvoice");
async function p2pApi(request, env, store, config, user, data, path) {
  requireAccess(env, user.id);
  if (path === "invoice/options" && request.method === "POST") {
    const active = await store.first(`
      SELECT * FROM invoices WHERE user_id = ? AND status = 'pending' AND expires_at > ?`, user.id, now());
    const latest = active ?? await store.first(`
      SELECT * FROM invoices WHERE user_id = ? ORDER BY id DESC LIMIT 1`, user.id);
    const account2 = await store.first("SELECT p2p_balance FROM accounts WHERE user_id = ?", user.id);
    return {
      balance: account2?.p2p_balance ?? 0,
      minAmount: MIN_AMOUNT,
      maxAmount: MAX_AMOUNT,
      methods: [...new Set((await availableCards(store, env)).map((card) => card.method))],
      active: active ? publicInvoice(env, active, config) : null,
      latest: latest ? publicInvoice(env, latest, config) : null
    };
  }
  if (path === "invoice" && request.method === "POST") {
    return publicInvoice(env, await createInvoice(store, env, user, data), config);
  }
  const match = /^invoice\/([0-9]{1,16})\/(status|check)$/.exec(path);
  if (!match || (match[2] === "status" ? request.method !== "GET" : request.method !== "POST")) {
    throw new RequestError("endpoint_missing", 404);
  }
  const id = integer(match[1]);
  if (match[2] === "check") {
    await store.stmt(`
      UPDATE invoices SET checked_at = COALESCE(checked_at, ?)
      WHERE id = ? AND user_id = ? AND status IN ('pending', 'expired')`, now(), id, user.id).run();
  }
  const row = await ownedInvoice(store, id, user.id);
  if (!row) throw new RequestError("payment_not_found", 404);
  const account = await store.first("SELECT p2p_balance FROM accounts WHERE user_id = ?", user.id);
  return { ...publicInvoice(env, row, config), balance: account?.p2p_balance ?? 0 };
}
__name(p2pApi, "p2pApi");
function authorizeRelay(request, env, method) {
  if (env.P2P_MODE !== "private" || request.method !== "POST" || !/^(humo|uzcard|cardxabar)$/.test(method)) {
    throw new RequestError("endpoint_missing", 404);
  }
  const key = env["P2P_" + method.toUpperCase() + "_SECRET"];
  const supplied = request.headers.get("Authorization")?.replace(/^Bearer /, "");
  if (!validSecret(key) || !matchesSecret(supplied, key)) throw new RequestError("forbidden", 403);
}
__name(authorizeRelay, "authorizeRelay");
async function receiveIncoming(store, env, method, data) {
  if (method === "uzcard" && (typeof data.sender !== "string" || !env.P2P_UZCARD_SENDERS?.trim().split(/\s*,\s*/).includes(data.sender))) {
    throw new RequestError("p2p_sender_invalid", 403);
  }
  const notice = parseIncoming(data.text);
  const matchingCards = cards(env).filter((item) => (method === "cardxabar" || item.method === method) && item.number.endsWith(notice.last4));
  if (matchingCards.length !== 1) throw new RequestError("p2p_card_unknown");
  const [card] = matchingCards;
  const eventId = data.eventId ?? `ref:${card.id}:${notice.bankRef}`;
  if (typeof eventId !== "string" || !EVENT_ID.test(eventId)) throw new RequestError("p2p_event_invalid");
  const received = now();
  if (notice.occurredAt > received + 30 || notice.occurredAt < received - HOLD_SECONDS) {
    throw new RequestError("p2p_event_time_invalid");
  }
  const minimum2 = notice.occurredAt;
  const maximum = minimum2 + notice.precision - 1;
  const recorded = await store.first(
    `
    INSERT INTO p2p_incoming (card_id, source, source_event_id, bank_ref, amount, occurred_at, received_at, invoice_id)
    SELECT ?, ?, ?, ?, ?, ?, ?,
      (SELECT CASE WHEN COUNT(*) = 1 THEN MIN(id) END FROM invoices
       WHERE card_id = ? AND unique_amount = ? AND created_at <= ? AND expires_at > ?
         AND ((status = 'pending' AND expires_at > ?) OR status = 'manual_check')
         AND NOT EXISTS (SELECT 1 FROM invoices paid WHERE paid.card_id = ? AND paid.paid_ref = ?))
    ON CONFLICT DO NOTHING RETURNING invoice_id`,
    card.id,
    method,
    eventId,
    notice.bankRef,
    notice.amount,
    minimum2,
    received,
    card.id,
    notice.amount,
    minimum2,
    maximum,
    received,
    card.id,
    notice.bankRef
  );
  return {
    matched: Boolean(recorded?.invoice_id),
    invoiceId: recorded?.invoice_id ?? null,
    duplicate: !recorded
  };
}
__name(receiveIncoming, "receiveIncoming");
async function sendP2pNotice(store, env, id) {
  const time = now();
  const claim = await store.first(`
    UPDATE p2p_notices SET lease_until = ? WHERE invoice_id = ? AND lease_until <= ?
    RETURNING lease_until`, time + 60, id, time);
  if (!claim) return;
  const row = await store.first("SELECT * FROM invoices WHERE id = ?", id);
  const label = row.lang === "ru" ? "\u2705 \u041F\u043E\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u043E" : "\u2705 To\u2018lov tasdiqlandi";
  await telegram(env, "sendMessage", {
    chat_id: row.user_id,
    text: `${label} \xB7 #${id}
+${formatAmount(row.base_amount)} UZS`
  }).catch((error) => {
    if (error.telegramCode !== 403) throw error;
  });
  await store.stmt("DELETE FROM p2p_notices WHERE invoice_id = ? AND lease_until = ?", id, claim.lease_until).run();
}
__name(sendP2pNotice, "sendP2pNotice");
var BUYER_RECEIPT = /^P2P #(\d+)(?:\n|$)/;
function receiptChat(env, config) {
  const chat = Number(env.P2P_REVIEW_CHAT_ID);
  return Number.isSafeInteger(chat) && chat !== 0 ? chat : config.admin;
}
__name(receiptChat, "receiptChat");
async function p2pReceipt(env, store, config, message) {
  const reply = message.reply_to_message;
  const match = reply?.from?.is_bot && reply.from.id === Number(env.BOT_TOKEN?.split(":")[0]) && BUYER_RECEIPT.exec(reply.text || "");
  const file = message.photo?.at(-1) ?? (["application/pdf", "image/jpeg", "image/png", "image/webp"].includes(message.document?.mime_type) && message.document);
  if (!match || !file || !p2pAccess(env, message.from?.id)) return false;
  const id = integer(match[1]);
  let saved = await store.first("SELECT * FROM invoices WHERE id = ? AND user_id = ?", id, message.from.id);
  if (!saved) return true;
  if (["pending", "expired"].includes(saved.status)) {
    const time = now();
    const result = await store.first(
      `
      UPDATE invoices SET status = 'manual_check', receipt_file_id = ?, receipt_unique_id = ?,
          receipt_chat_id = ?, receipt_message_id = ?
      WHERE id = ? AND user_id = ? AND status IN ('pending', 'expired') AND checked_at IS NOT NULL
        AND (checked_at <= ? OR expires_at <= ?)
        AND NOT EXISTS (SELECT 1 FROM invoices WHERE receipt_unique_id = ?)
      RETURNING *`,
      file.file_id,
      file.file_unique_id,
      message.chat.id,
      message.message_id,
      id,
      message.from.id,
      time - 60,
      time,
      file.file_unique_id
    );
    if (!result) return true;
    saved = result;
  }
  if (saved.status !== "manual_check" || saved.receipt_message_id !== message.message_id || saved.review_message_id) return true;
  const forwarded = await telegram(env, "copyMessage", {
    chat_id: receiptChat(env, config),
    from_chat_id: message.chat.id,
    message_id: message.message_id,
    caption: `P2P \u0447\u0435\u043A #${id}
${saved.payment_method.toUpperCase()} \u2022\u2022\u2022\u2022${saved.card_number}
\u041A \u0437\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044E ${formatAmount(saved.base_amount)} UZS. \u0421\u0432\u0435\u0440\u044C\u0442\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044E \u0441 \u0432\u044B\u043F\u0438\u0441\u043A\u043E\u0439.
/p2p_confirm ${id} RRN \u0421\u0423\u041C\u041C\u0410`,
    reply_markup: { inline_keyboard: [[
      { text: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C", callback_data: `p2p_yes:${id}` },
      { text: "\u041E\u0442\u043A\u043B\u043E\u043D\u0438\u0442\u044C", callback_data: `p2p_no:${id}` }
    ]] }
  });
  if (Number.isSafeInteger(forwarded?.message_id)) {
    await store.stmt(
      "UPDATE invoices SET review_message_id = ? WHERE id = ? AND review_message_id IS NULL",
      forwarded.message_id,
      id
    ).run();
  }
  await telegram(env, "sendMessage", {
    chat_id: message.chat.id,
    text: saved.lang === "ru" ? "\u0427\u0435\u043A \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D \u043D\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443." : "Chek tekshiruvga yuborildi."
  }).catch(() => {
  });
  return true;
}
__name(p2pReceipt, "p2pReceipt");
async function p2pCommand(env, store, config, message, command, args) {
  const admin = Boolean(config.admin && message.from.id === config.admin);
  const say = /* @__PURE__ */ __name((text) => telegram(env, "sendMessage", { chat_id: message.chat.id, text }), "say");
  if (command === "/start" && /^p2p_[0-9]+$/.test(args[0] || "")) {
    if (!p2pAccess(env, message.from.id)) return true;
    const row2 = await ownedInvoice(store, integer(args[0].slice(4)), message.from.id);
    if (!row2 || !publicInvoice(env, row2, config).receiptLink) return true;
    await telegram(env, "sendMessage", {
      chat_id: message.chat.id,
      text: `P2P #${row2.id}
` + (row2.lang === "ru" ? "\u041E\u0442\u0432\u0435\u0442\u044C\u0442\u0435 \u043D\u0430 \u044D\u0442\u043E \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0444\u043E\u0442\u043E \u0438\u043B\u0438 PDF." : "Ushbu xabarga rasm yoki PDF bilan javob bering."),
      reply_markup: { force_reply: true, selective: true }
    });
    return true;
  }
  if (command !== "/p2p_card" && command !== "/p2p_confirm") return false;
  if (!admin || env.P2P_MODE !== "private") return true;
  if (command === "/p2p_card") {
    const [action, id2] = args;
    if (action === "list") {
      const active = new Set((await availableCards(store, env)).map((card) => card.id));
      await say(cards(env).map((card) => `${card.id} \xB7 ${card.method.toUpperCase()} \u2022\u2022\u2022\u2022${card.number.slice(-4)} \xB7 ${active.has(card.id) ? "on" : "off"}`).join("\n") || "\u041A\u0430\u0440\u0442\u044B \u043F\u043E\u043A\u0430 \u043D\u0435 \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u044B.");
      return true;
    }
    if (!["on", "off"].includes(action) || !cards(env).some((card) => card.id === id2)) {
      await say("/p2p_card list\n/p2p_card on ID\n/p2p_card off ID");
      return true;
    }
    await store.stmt(`INSERT INTO p2p_card_flags VALUES (?, ?)
      ON CONFLICT (card_id) DO UPDATE SET enabled = excluded.enabled`, id2, Number(action === "on")).run();
    await say(`\u041A\u0430\u0440\u0442\u0430 ${id2} \xB7 ${action}`);
    return true;
  }
  let id, ref, amount;
  try {
    if (args.length < 3) throw new RequestError("p2p_reference_required");
    id = integer(args[0]);
    ref = reference(args[1]);
    amount = parseAmount(args.slice(2).join(" "));
  } catch (error) {
    if (!(error instanceof RequestError)) throw error;
    await say("/p2p_confirm ID RRN \u0424\u0410\u041A\u0422\u0418\u0427\u0415\u0421\u041A\u0410\u042F_\u0421\u0423\u041C\u041C\u0410");
    return true;
  }
  const row = await store.first(`
    UPDATE invoices AS target SET status = 'paid', paid_at = ?, paid_ref = ?, received_amount = ?, review_user_id = ?
    WHERE id = ? AND status = 'manual_check' AND base_amount <= ?
    AND NOT EXISTS (SELECT 1 FROM invoices existing WHERE existing.card_id = target.card_id AND existing.paid_ref = ?)
    AND NOT EXISTS (SELECT 1 FROM p2p_incoming event WHERE event.card_id = target.card_id AND event.bank_ref = ?
      AND (event.amount <> ? OR event.occurred_at < target.created_at OR event.invoice_id IS NOT NULL))
    RETURNING id`, now(), ref, amount, message.from.id, id, amount, ref, ref, amount);
  await say(row ? `\u0417\u0430\u044F\u0432\u043A\u0430 #${id} \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0430.` : "\u0417\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u0435 \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u043E. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0441\u0442\u0430\u0442\u0443\u0441, \u0441\u0443\u043C\u043C\u0443 \u0438 \u043D\u043E\u043C\u0435\u0440 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438.");
  if (row) await sendP2pNotice(store, env, id).catch(() => {
  });
  return true;
}
__name(p2pCommand, "p2pCommand");
async function p2pCallback(env, store, config, query) {
  const match = /^p2p_(yes|no):([0-9]+)$/.exec(query.data || "");
  if (!match) return false;
  const admin = Boolean(config.admin && query.from?.id === config.admin && env.P2P_MODE === "private");
  let text = "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430";
  if (admin) {
    const id = integer(match[2]);
    if (match[1] === "yes") {
      text = `\u0421\u0432\u0435\u0440\u044C\u0442\u0435 \u0432\u044B\u043F\u0438\u0441\u043A\u0443 \u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u044C\u0442\u0435 /p2p_confirm ${id} RRN \u0421\u0423\u041C\u041C\u0410`;
    } else {
      const changed = await store.first(`
        UPDATE invoices SET status = 'rejected', review_user_id = ?
        WHERE id = ? AND status = 'manual_check' RETURNING id`, query.from.id, id);
      text = changed ? "\u0417\u0430\u044F\u0432\u043A\u0430 \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u0430" : "\u0417\u0430\u044F\u0432\u043A\u0430 \u0443\u0436\u0435 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u0430\u043D\u0430";
    }
  }
  await telegram(env, "answerCallbackQuery", { callback_query_id: query.id, text, show_alert: true });
  return true;
}
__name(p2pCallback, "p2pCallback");
async function p2pCron(store, env) {
  await expireInvoices(store);
  const queue = await store.all("SELECT invoice_id FROM p2p_notices WHERE lease_until <= ? ORDER BY lease_until LIMIT 6", now());
  await Promise.allSettled(queue.map((row) => sendP2pNotice(store, env, row.invoice_id)));
}
__name(p2pCron, "p2pCron");

// src/worker.mjs
var paymentUpdates = ["message", "pre_checkout_query", "callback_query"];
function httpsUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && !url.username && !url.password ? url.href : "";
  } catch {
    return "";
  }
}
__name(httpsUrl, "httpsUrl");
function rate(value) {
  const n = Number(value);
  return Number.isSafeInteger(n) && n > 0 && n <= 1e6 ? n : 0;
}
__name(rate, "rate");
function settings(env, requestUrl) {
  const app = httpsUrl(env.MINIAPP_URL || requestUrl?.origin);
  const test = isTest(env);
  const terms = httpsUrl(env.STARS_TERMS_URL) || (test && app ? new URL("/test-terms", app).href : "");
  const admin = telegramId(env.ADMIN_ID);
  const name = username(env.BOT_USERNAME?.replace(/^@/, ""));
  const support = username(env.ADMIN_USERNAME?.replace(/^@/, ""));
  const webhookReady = ["0", "1"].includes(env.TELEGRAM_TEST_ENV) && Boolean(name && app && validSecret(env.WEBHOOK_SECRET) && validToken(botToken(env)));
  const enabled = env.ENABLE_PAYMENTS === "1" && webhookReady && Boolean(terms && admin);
  return {
    app,
    test,
    terms,
    admin,
    name,
    support,
    webhookReady,
    enabled,
    topupRate: enabled ? rate(env.STARS_TOPUP_RATE_UZS) : 0,
    orderRate: enabled ? rate(env.STARS_RATE_UZS) : 0
  };
}
__name(settings, "settings");
function webhookAddress(config) {
  return new URL("/telegram", config.app).href;
}
__name(webhookAddress, "webhookAddress");
async function checkoutSettings(store, config) {
  if (!config.enabled || config.test) return config;
  const row = await store.first("SELECT checkout_webhook_url FROM telegram_entry WHERE id = 1");
  if (row?.checkout_webhook_url === webhookAddress(config)) return config;
  return { ...config, enabled: false, topupRate: 0, orderRate: 0 };
}
__name(checkoutSettings, "checkoutSettings");
function json(body, status = 200) {
  return Response.json(body, { status, headers: { "Cache-Control": "no-store" } });
}
__name(json, "json");
function requireStars(data, configuredRate) {
  if (data.paymentMethod !== "stars") throw new RequestError("invalid_payment_method");
  if (!configuredRate) throw new RequestError("stars_not_configured", 503);
  if (data.acceptTerms !== true) throw new RequestError("terms_required");
}
__name(requireStars, "requireStars");
async function readObject(request) {
  if (Number(request.headers.get("Content-Length")) > 16e3) {
    throw new RequestError("invalid_request", 413);
  }
  const body = await request.json().catch(() => null);
  if (!body || typeof body !== "object" || Array.isArray(body)) throw new RequestError("invalid_json");
  return body;
}
__name(readObject, "readObject");
function langText(lang, ru, uz) {
  return lang === "ru" ? ru : uz;
}
__name(langText, "langText");
function background(ctx, work) {
  ctx.waitUntil(work.catch(() => console.error("ARSLAN BOOST background task failed")));
}
__name(background, "background");
async function sendNotice(env, store, id) {
  const admin = telegramId(env.ADMIN_ID);
  if (!admin) return;
  const payment = await store.claimNotice(id);
  if (!payment) return;
  const order = await store.paymentOrder(payment);
  if (!order) throw new Error("Order missing");
  const title = payment.kind === "order" ? `Boost #${order.id} \xB7 ${MODES.get(order.mode)}
${RANKS[order.current_rank]} \u2192 ${RANKS[order.target_rank]}
ID: ${order.game_id}` : `Donat Shop #${order.id}
${productTitle(order.product)} \xB7 ${order.option_label}
\u0414\u0430\u043D\u043D\u044B\u0435: ${order.detail || "\u2014"}`;
  const method = payment.method === "stars" ? `${formatAmount(payment.stars)} \u2B50` : "\u0411\u0430\u043B\u0430\u043D\u0441";
  const params = {
    chat_id: admin,
    text: `\u2705 \u0417\u0430\u043A\u0430\u0437 \u043E\u043F\u043B\u0430\u0447\u0435\u043D

${title}
\u{1F4B0} ${formatAmount(payment.amount)} UZS \xB7 ${method}
\u{1F464} Telegram ID: ${payment.user_id}${order.username ? " \xB7 @" + order.username : ""}
\u041F\u043B\u0430\u0442\u0451\u0436 #${id}`
  };
  if (payment.kind === "order") {
    params.reply_markup = { inline_keyboard: [[{ text: "\u25B6 \u0412 \u0440\u0430\u0431\u043E\u0442\u0443", callback_data: `boost_work:${order.id}` }]] };
  }
  await telegram(env, "sendMessage", params);
  await store.markNotified(payment);
}
__name(sendNotice, "sendNotice");
async function paymentDetails(env, store, payment, { invoice = false, lang = "uz", order } = {}) {
  const result = {
    id: payment.id,
    amount: payment.amount,
    stars: payment.stars,
    kind: payment.kind,
    method: payment.method,
    status: payment.status,
    orderId: payment.order_id ?? payment.donat_order_id,
    processing: processing(payment)
  };
  if (!invoice || result.status !== "pending" || result.processing) return result;
  const row = order ?? await store.paymentOrder(payment);
  const title = payment.kind === "donat" ? productTitle(row.product) : "ARSLAN BOOST";
  const description = {
    topup: langText(lang, "\u041F\u043E\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u0431\u0430\u043B\u0430\u043D\u0441\u0430", "Balansni to\u2018ldirish"),
    order: langText(lang, "\u041F\u043E\u0432\u044B\u0448\u0435\u043D\u0438\u0435 \u0440\u0430\u043D\u0433\u0430", "Rank oshirish") + " #" + result.orderId,
    donat: "Donat Shop #" + result.orderId + (row?.option_label ? " \xB7 " + row.option_label : "")
  };
  result.invoiceLink = await telegram(env, "createInvoiceLink", {
    title: title.slice(0, 32),
    description: description[payment.kind].slice(0, 255),
    payload: "ab:" + payment.id,
    provider_token: "",
    currency: "XTR",
    prices: [{ label: langText(lang, "\u0421\u0443\u043C\u043C\u0430", "Summa"), amount: payment.stars }]
  });
  return result;
}
__name(paymentDetails, "paymentDetails");
async function publicConfig(store, config) {
  return {
    arslanBoostApi: true,
    botUrl: config.name ? "https://t.me/" + config.name : null,
    supportUrl: config.support ? "https://t.me/" + config.support : null,
    termsUrl: config.terms,
    starsRate: config.topupRate,
    orderStarsRate: config.orderRate,
    starsMax: config.topupRate ? Math.min(MAX_STARS, Math.floor(MAX_AMOUNT / config.topupRate)) : 0,
    orderStarsMax: config.orderRate ? MAX_STARS : 0,
    prices: PRICES,
    calibrationLegendPrice: CALIBRATION_LEGEND_PRICE,
    boostModeSurcharge: MODE_SURCHARGE,
    minBoostPrice: MIN_BOOST_PRICE,
    boostEta: await store.eta()
  };
}
__name(publicConfig, "publicConfig");
async function handleApi(request, env, ctx, store, config, path) {
  if (path === "invoice" || path.startsWith("invoice/")) {
    const user2 = await authenticate(request, env);
    const data2 = request.method === "POST" ? await readObject(request) : {};
    return json(await p2pApi(request, env, store, config, user2, data2, path));
  }
  if (request.method === "GET") {
    if (path === "config") return json(await publicConfig(store, config));
    if (path === "donat/catalog") return json(catalog_default);
    return json({ error: "endpoint_missing" }, 404);
  }
  if (request.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  const user = await authenticate(request, env);
  const data = await readObject(request);
  switch (path) {
    case "referral/me":
    case "referral/apply":
    case "referral/withdraw":
      return json(await partnerApi(env, ctx, store, config, path, user, data));
    case "state":
      return json({ ...await store.state(user.id), p2pPrivate: p2pAccess(env, user.id) });
    case "donat/state":
      return json({ orders: await store.donatState(user.id) });
    case "profile":
      return json(await store.profile(user.id, data));
    case "topup": {
      requireStars(data, config.topupRate);
      const payment = await store.createTopup(user.id, data, config.topupRate);
      return json(await paymentDetails(env, store, payment, { invoice: true, lang: data.lang }));
    }
    case "payment/status": {
      const payment = await store.userPayment(integer(data.paymentId), user.id);
      const configured = payment.kind === "topup" ? config.topupRate : config.orderRate;
      return json(await paymentDetails(env, store, payment, {
        invoice: Boolean(configured && data.resume === true),
        lang: data.lang
      }));
    }
    case "checkout":
    case "donat/create": {
      if (data.paymentMethod === "stars") requireStars(data, config.orderRate);
      else if (data.paymentMethod !== "balance") throw new RequestError("invalid_payment_method");
      else if (!config.enabled) throw new RequestError("stars_not_configured", 503);
      const kind = path === "checkout" ? "order" : "donat";
      const { order, payment } = await store.createOrder(kind, user, data, config.orderRate);
      const result = { id: order.id, amount: order.amount, status: order.status };
      if (kind === "order") result.boostEta = [order.eta_min_hours, order.eta_max_hours];
      if (payment.method === "stars") {
        result.payment = await paymentDetails(env, store, payment, { invoice: true, order, lang: data.lang });
      } else if (payment.admin_notice_pending) {
        background(ctx, sendNotice(env, store, payment.id));
      }
      return json(result);
    }
    case "order-help":
      throw new RequestError("automatic_payment_only");
    default:
      return json({ error: "endpoint_missing" }, 404);
  }
}
__name(handleApi, "handleApi");
function paymentId(payload) {
  const match = typeof payload === "string" && /^ab:([0-9]{1,16})$/.exec(payload);
  return match ? telegramId(match[1]) || null : null;
}
__name(paymentId, "paymentId");
async function handlePreCheckout(env, store, config, query) {
  const id = paymentId(query.invoice_payload);
  const buyer = telegramId(query.from?.id);
  let reserved2 = false;
  if (config.enabled && id && buyer && typeof query.id === "string" && query.currency === "XTR" && Number.isSafeInteger(query.total_amount) && query.total_amount > 0 && query.total_amount <= MAX_STARS) {
    try {
      reserved2 = Boolean(await store.reserveCheckout(id, buyer, query.total_amount, query.id));
    } catch {
      console.error("ARSLAN BOOST checkout reservation failed");
    }
  }
  await telegram(env, "answerPreCheckoutQuery", {
    pre_checkout_query_id: query.id,
    ok: reserved2,
    ...reserved2 ? {} : { error_message: langText(
      query.from?.language_code,
      "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0441\u0443\u043C\u043C\u0443 \u0438\u043B\u0438 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u0447\u0451\u0442 \u0438\u0437 \u0438\u0441\u0442\u043E\u0440\u0438\u0438 \u0437\u0430\u043A\u0430\u0437\u043E\u0432.",
      "Summani tekshiring yoki hisobni buyurtmalar tarixidan oching."
    ) }
  });
}
__name(handlePreCheckout, "handlePreCheckout");
async function handlePaid(env, ctx, store, message) {
  const payment = message.successful_payment;
  const buyer = telegramId(message.from?.id);
  if (!buyer || typeof payment.currency !== "string" || !/^[A-Z]{3}$/.test(payment.currency) || typeof payment.telegram_payment_charge_id !== "string" || !payment.telegram_payment_charge_id || payment.telegram_payment_charge_id.length > 512 || !Number.isSafeInteger(payment.total_amount) || payment.total_amount < 1) {
    console.error("ARSLAN BOOST invalid payment update");
    return;
  }
  const result = await store.settle(paymentId(payment.invoice_payload), buyer, payment);
  if (!result) {
    console.error("ARSLAN BOOST payment requires reconciliation");
    return;
  }
  if (result.payment.admin_notice_pending) background(ctx, sendNotice(env, store, result.payment.id));
  if (result.changed) {
    const lang = message.from?.language_code;
    const text = result.payment.kind === "topup" ? langText(lang, "\u2705 \u0411\u0430\u043B\u0430\u043D\u0441 \u043F\u043E\u043F\u043E\u043B\u043D\u0435\u043D \u043D\u0430 ", "\u2705 Balansga qo\u2018shildi: ") + formatAmount(result.payment.amount) + " UZS" : langText(lang, "\u2705 \u0417\u0430\u043A\u0430\u0437 \u043E\u043F\u043B\u0430\u0447\u0435\u043D. \u0410\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440 \u043F\u043E\u043B\u0443\u0447\u0438\u043B \u0437\u0430\u044F\u0432\u043A\u0443.", "\u2705 To\u2018lov qabul qilindi. Buyurtma administratorga yuborildi.");
    background(ctx, telegram(env, "sendMessage", { chat_id: buyer, text }));
  }
}
__name(handlePaid, "handlePaid");
async function handleCommand(env, store, config, message) {
  const [raw, ...args] = (message.text || "").trim().split(/\s+/);
  const command = raw.split("@", 1)[0];
  const chatId = message.chat.id;
  const lang = message.from?.language_code;
  const say = /* @__PURE__ */ __name((text, extra) => telegram(env, "sendMessage", { chat_id: chatId, text, ...extra }), "say");
  if (await p2pCommand(env, store, config, message, command, args)) return;
  switch (command) {
    case "/start":
    case "/preview": {
      const preview = command === "/preview";
      const url = config.app;
      if (!url) throw new RequestError("miniapp_url_required", 503);
      if (!preview) await bindPartner(store, message.from.id, args[0]);
      const greeting = preview ? langText(lang, "\u041E\u0442\u043A\u0440\u043E\u0439 \u043E\u0431\u043D\u043E\u0432\u043B\u0451\u043D\u043D\u044B\u0439 ARSLAN BOOST.", "Yangilangan ARSLAN BOOST\u2019ni oching.") : langText(lang, "\u0414\u043E\u0431\u0440\u043E \u043F\u043E\u0436\u0430\u043B\u043E\u0432\u0430\u0442\u044C \u0432 ARSLAN BOOST!", "ARSLAN BOOST\u2019ga xush kelibsiz!");
      return say(greeting + (config.test ? "\n\n\u{1F9EA} ID: " + message.from.id : ""), {
        reply_markup: { inline_keyboard: [[{
          text: langText(lang, "\u{1F680} \u041E\u0442\u043A\u0440\u044B\u0442\u044C Mini App", "\u{1F680} Mini App\u2019ni ochish"),
          web_app: { url }
        }]] }
      });
    }
    case "/balance": {
      const user = await store.first("SELECT stars_balance FROM accounts WHERE user_id = ?", message.from.id);
      return say(langText(lang, "\u0411\u0430\u043B\u0430\u043D\u0441: ", "Balans: ") + formatAmount(user?.stars_balance ?? 0) + " UZS");
    }
    case "/id":
      return say("Telegram ID: " + message.from.id);
    case "/terms":
      return say(config.terms || langText(lang, "\u0423\u0441\u043B\u043E\u0432\u0438\u044F \u043E\u043F\u043B\u0430\u0442\u044B \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u0443 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0438.", "To\u2018lov shartlari uchun yordam xizmatiga yozing."));
    case "/support":
    case "/paysupport":
      return say(langText(lang, "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043D\u043E\u043C\u0435\u0440 \u0437\u0430\u043A\u0430\u0437\u0430 \u0438\u043B\u0438 \u043F\u043B\u0430\u0442\u0435\u0436\u0430.", "Buyurtma yoki to\u2018lov raqamini yozing.") + (config.support ? " https://t.me/" + config.support : ""));
    case "/admin":
      if (config.admin && message.from.id === config.admin) {
        return say("ARSLAN BOOST\n/delivered donat 123 9000 \u2014 \u0432\u044B\u0434\u0430\u0442\u044C \u0437\u0430\u043A\u0430\u0437, \u0443\u043A\u0430\u0437\u0430\u0432 \u0441\u0435\u0431\u0435\u0441\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C\n/delivered boost 123 9000 \u2014 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u0431\u0443\u0441\u0442\n/boost_eta 24 48 \u2014 \u0441\u0440\u043E\u043A\u0438 \u0431\u0443\u0441\u0442\u0430\n/p2p_card list \u2014 \u043A\u0430\u0440\u0442\u044B \u0442\u0435\u0441\u0442\u0430");
      }
      return;
    case "/partner":
      return say(langText(lang, "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0440\u0430\u0437\u0434\u0435\u043B \xAB\u041F\u0430\u0440\u0442\u043D\u0451\u0440\u044B\xBB \u0432 Mini App.", "Mini App\u2019dagi \xABHamkorlar\xBB bo\u2018limini oching."));
    case "/delivered": {
      if (!config.admin || message.from.id !== config.admin) return;
      let order;
      try {
        if (args.length !== 3) throw new RequestError("invalid_request");
        order = await fulfillOrder(store, args[0], integer(args[1]), integer(args[2], 0, 1e11));
      } catch (error) {
        if (!(error instanceof RequestError)) throw error;
        return say("/delivered donat 123 9000 \u0438\u043B\u0438 /delivered boost 123 9000");
      }
      if (!order) return say("\u041E\u043F\u043B\u0430\u0447\u0435\u043D\u043D\u044B\u0439 \u0437\u0430\u043A\u0430\u0437 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D \u0438\u043B\u0438 \u0443\u0436\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D.");
      await telegram(env, "sendMessage", {
        chat_id: order.user_id,
        text: langText(order.lang, `\u2705 \u0417\u0430\u043A\u0430\u0437 #${order.id} \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D.`, `\u2705 Buyurtma #${order.id} bajarildi.`)
      }).catch(() => {
      });
      return say(`\u2705 \u0417\u0430\u043A\u0430\u0437 #${order.id} \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D.`);
    }
    case "/boost_eta":
      if (message.from.id !== config.admin) return;
      try {
        if (args[0] === "off" && args.length === 1) {
          await store.stmt("DELETE FROM boost_schedule WHERE id = 1").run();
          return say("\u0421\u0440\u043E\u043A \u0441\u043A\u0440\u044B\u0442.");
        }
        if (args.length < 1 || args.length > 2) throw new RequestError("invalid_number");
        const low = integer(args[0], 1, 720);
        const high = integer(args.at(-1), low, 720);
        await store.stmt(
          `
          INSERT INTO boost_schedule VALUES (1, ?, ?)
          ON CONFLICT (id) DO UPDATE SET min_hours = excluded.min_hours, max_hours = excluded.max_hours`,
          low,
          high
        ).run();
        return say(`\u0421\u0440\u043E\u043A \u0431\u0443\u0441\u0442\u0430: ${low === high ? low : low + "\u2013" + high} \u0447 \u043F\u043E\u0441\u043B\u0435 \u043E\u043F\u043B\u0430\u0442\u044B.`);
      } catch (error) {
        if (!(error instanceof RequestError)) throw error;
        return say("/boost_eta 24 48 \u0438\u043B\u0438 /boost_eta off");
      }
    default:
      return;
  }
}
__name(handleCommand, "handleCommand");
async function handleCallback(env, store, config, query) {
  if (await p2pCallback(env, store, config, query)) return;
  if (await partnerCallback(env, store, config, query)) return;
  const work = typeof query.data === "string" && /^boost_work:([0-9]+)$/.exec(query.data);
  if (!work) return;
  let text = "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430";
  if (config.admin && query.from?.id === config.admin) {
    const order = await store.first(`
      UPDATE orders SET status = 'in_progress' WHERE id = ? AND status = 'paid'
      RETURNING id, user_id, lang`, integer(work[1]));
    text = order ? "\u0412 \u0440\u0430\u0431\u043E\u0442\u0435" : "\u0421\u0442\u0430\u0442\u0443\u0441 \u0443\u0436\u0435 \u0438\u0437\u043C\u0435\u043D\u0451\u043D";
    if (order) {
      await telegram(env, "sendMessage", {
        chat_id: order.user_id,
        text: langText(order.lang, `\u0411\u0443\u0441\u0442 #${order.id} \u0432 \u0440\u0430\u0431\u043E\u0442\u0435.`, `Boost #${order.id} bajarilmoqda.`)
      }).catch(() => {
      });
    }
  }
  await telegram(env, "answerCallbackQuery", { callback_query_id: query.id, text });
}
__name(handleCallback, "handleCallback");
async function handleWebhook(request, env, ctx, store, config) {
  if (request.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  if (!matchesSecret(request.headers.get("X-Telegram-Bot-Api-Secret-Token"), env.WEBHOOK_SECRET)) {
    return json({ error: "forbidden" }, 403);
  }
  const update = await readObject(request);
  if (update.pre_checkout_query) {
    await handlePreCheckout(env, store, await checkoutSettings(store, config), update.pre_checkout_query);
  } else if (update.message?.successful_payment && update.message.chat?.type === "private") {
    await handlePaid(env, ctx, store, update.message);
  } else if (update.callback_query) {
    await handleCallback(env, store, config, update.callback_query);
  } else if (update.message?.chat?.type === "private" && update.message.from?.id) {
    const message = update.message;
    if (message.text) await handleCommand(env, store, config, message);
    else if (env.P2P_MODE === "private") await p2pReceipt(env, store, config, message);
  }
  return new Response("OK");
}
__name(handleWebhook, "handleWebhook");
function setupPage(content, status = 200) {
  return new Response(`<!doctype html><html lang="ru"><meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>ARSLAN BOOST \xB7 \u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 Telegram</title>
    <main><h1>\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 Telegram</h1>${content}</main></html>`, {
    status,
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "no-store",
      "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'",
      "Referrer-Policy": "no-referrer"
    }
  });
}
__name(setupPage, "setupPage");
function receivesPaymentUpdates(webhook) {
  const subscribed = webhook.allowed_updates;
  return !Array.isArray(subscribed) || !subscribed.length || paymentUpdates.every((update) => subscribed.includes(update));
}
__name(receivesPaymentUpdates, "receivesPaymentUpdates");
function registerWebhook(env, url, existing) {
  const subscribed = existing.allowed_updates;
  const updates = existing.url ? subscribed?.length ? [.../* @__PURE__ */ new Set([...subscribed, ...paymentUpdates])] : [] : paymentUpdates;
  return telegram(env, "setWebhook", {
    url,
    secret_token: env.WEBHOOK_SECRET,
    drop_pending_updates: false,
    allowed_updates: updates
  });
}
__name(registerWebhook, "registerWebhook");
async function saveTelegramEntry(store, bot, menuUrl, checkoutUrl) {
  await store.stmt(`
    INSERT INTO telegram_entry (id, menu_url, webhook_connected, has_main_web_app, checkout_webhook_url)
    VALUES (1, ?, ?, ?, ?)
    ON CONFLICT (id) DO UPDATE SET
      menu_url = COALESCE(NULLIF(excluded.menu_url, ''), telegram_entry.menu_url),
      webhook_connected = excluded.webhook_connected, has_main_web_app = excluded.has_main_web_app,
      checkout_webhook_url = excluded.checkout_webhook_url
  `, menuUrl, Number(Boolean(checkoutUrl)), Number(bot.has_main_web_app === true), checkoutUrl).run();
}
__name(saveTelegramEntry, "saveTelegramEntry");
async function setup(request, env, config, store) {
  if (!config.webhookReady) {
    return setupPage("<p>\u0412 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430\u0445 Worker \u0437\u0430\u0434\u0430\u0439 BOT_USERNAME, BOT_TOKEN \u0438 WEBHOOK_SECRET.</p>", 503);
  }
  if (request.method === "GET") {
    return setupPage(`<p>\u0420\u0435\u0436\u0438\u043C: ${config.test ? "\u0442\u0435\u0441\u0442\u043E\u0432\u0430\u044F \u0441\u0435\u0442\u044C" : "\u0440\u0430\u0431\u043E\u0447\u0430\u044F \u0441\u0435\u0442\u044C"}. \u0411\u043E\u0442 @${config.name}.</p>
      <form method="post" action="/setup"><label>WEBHOOK_SECRET
      <input name="secret" type="password" maxlength="256" autocomplete="off" required></label>
      <button type="submit">\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C Telegram</button></form>`);
  }
  if (request.method !== "POST") return setupPage("<p>\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043C\u0435\u0442\u043E\u0434.</p>", 405);
  const form = await request.formData().catch(() => null);
  if (!matchesSecret(form?.get("secret"), env.WEBHOOK_SECRET)) {
    return setupPage('<p>\u041A\u043E\u0434 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u043B. <a href="/setup">\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C</a></p>', 403);
  }
  const webhook = webhookAddress(config);
  const bot = await telegram(env, "getMe");
  if (bot.username?.toLowerCase() !== config.name.toLowerCase()) {
    return setupPage("<p>BOT_TOKEN \u043F\u0440\u0438\u043D\u0430\u0434\u043B\u0435\u0436\u0438\u0442 \u0434\u0440\u0443\u0433\u043E\u043C\u0443 \u0431\u043E\u0442\u0443. \u041F\u0440\u043E\u0432\u0435\u0440\u044C BOT_USERNAME \u0438 \u0441\u0435\u0442\u044C Telegram.</p>", 400);
  }
  const existing = await telegram(env, "getWebhookInfo");
  if (existing.url && existing.url !== webhook) {
    return setupPage("<p>\u0423 \u0431\u043E\u0442\u0430 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0451\u043D webhook \u043D\u0430 \u0434\u0440\u0443\u0433\u043E\u043C \u0430\u0434\u0440\u0435\u0441\u0435. \u041F\u0440\u043E\u0432\u0435\u0440\u044C \u0430\u0434\u0440\u0435\u0441 Worker \u0432 MINIAPP_URL.</p>", 409);
  }
  await store.eta();
  if (await registerWebhook(env, webhook, existing) !== true) {
    throw new RequestError("telegram_webhook_not_configured", 502);
  }
  await saveTelegramEntry(store, bot, "", webhook);
  return setupPage(`<p>Webhook \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0451\u043D. \u041E\u0442\u043A\u0440\u043E\u0439 <a href="https://t.me/${config.name}">@${config.name}</a> \u0438 \u043D\u0430\u0436\u043C\u0438 Start.</p>`);
}
__name(setup, "setup");
async function syncTelegramEntry(env, store, config) {
  const webhookUrl = webhookAddress(config);
  const saved = await store.first("SELECT menu_url, checkout_webhook_url FROM telegram_entry WHERE id = 1");
  const syncMenu = env.SYNC_TELEGRAM_MENU === "1" && saved?.menu_url !== config.app;
  if (!syncMenu && saved?.checkout_webhook_url === webhookUrl) return;
  const bot = await telegram(env, "getMe");
  if (bot.username?.toLowerCase() !== config.name.toLowerCase()) {
    throw new RequestError("wrong_bot_for_telegram_sync", 503);
  }
  const [menu, webhook] = await Promise.all([
    syncMenu ? telegram(env, "getChatMenuButton") : null,
    telegram(env, "getWebhookInfo")
  ]);
  let webhookConnected = webhook.url === webhookUrl;
  if (!webhook.url || webhookConnected && !receivesPaymentUpdates(webhook)) {
    webhookConnected = await registerWebhook(env, webhookUrl, webhook) === true;
    if (!webhookConnected) throw new Error("Telegram webhook was not configured");
  }
  if (menu && (menu.type !== "web_app" || menu.web_app?.url !== config.app)) {
    const updated = await telegram(env, "setChatMenuButton", {
      menu_button: { type: "web_app", text: menu.text || "Mini App", web_app: { url: config.app } }
    });
    if (updated !== true) throw new Error("Telegram menu was not updated");
  }
  await saveTelegramEntry(store, bot, syncMenu ? config.app : "", webhookConnected ? webhookUrl : null);
}
__name(syncTelegramEntry, "syncTelegramEntry");
var worker_default = {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const store = new Store(env.DB);
    const config = settings(env, url);
    try {
      if (/^\/relay\/(humo|uzcard|cardxabar)$/.test(path)) {
        const method = path.slice("/relay/".length);
        authorizeRelay(request, env, method);
        const event = await receiveIncoming(store, env, method, await readObject(request));
        if (event.invoiceId) background(ctx, sendP2pNotice(store, env, event.invoiceId));
        return json({ accepted: true, matched: event.matched, duplicate: event.duplicate });
      }
      if (path.startsWith("/api/")) {
        return await handleApi(request, env, ctx, store, await checkoutSettings(store, config), path.slice(5));
      }
      if (path === "/telegram") return await handleWebhook(request, env, ctx, store, config);
      if (path === "/setup") return await setup(request, env, config, store);
      if (path === "/healthz" && request.method === "GET") {
        await store.eta();
        const checkout = await checkoutSettings(store, config);
        return json({ ok: true, telegramTest: config.test, paymentsEnabled: Boolean(checkout.orderRate || checkout.topupRate) });
      }
      if (path === "/payment-terms" && request.method === "GET") {
        const approvedUrl = config.app ? new URL(path, config.app).href : "";
        if (!config.terms || config.terms !== approvedUrl || !config.name) return json({ error: "terms_not_published" }, 404);
        return paymentTerms(config, rate(env.STARS_TOPUP_RATE_UZS));
      }
      if (path === "/test-terms" && config.test && request.method === "GET") {
        return new Response("ARSLAN BOOST \xB7 Sinov to\u2018lovi\n\u0422\u0435\u0441\u0442\u043E\u0432\u0430\u044F \u043E\u043F\u043B\u0430\u0442\u0430 \u0432 \u0442\u0435\u0441\u0442\u043E\u0432\u043E\u0439 \u0441\u0435\u0442\u0438 Telegram.");
      }
      return env.ASSETS.fetch(request);
    } catch (error) {
      if (error instanceof RequestError) {
        if (path === "/setup") return setupPage("<p>\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u044F. \u041F\u0440\u043E\u0432\u0435\u0440\u044C \u0442\u043E\u043A\u0435\u043D \u0438 \u0441\u0435\u0442\u044C \u0431\u043E\u0442\u0430.</p>", error.status);
        if (path === "/telegram" && error.telegramCode === 403) return new Response("OK");
        return json({ error: error.message }, error.status);
      }
      console.error("ARSLAN BOOST Worker failed");
      return json({ error: "service_unavailable" }, 503);
    }
  },
  async scheduled(_controller, env, ctx) {
    const store = new Store(env.DB);
    const config = settings(env);
    if (config.webhookReady && (env.SYNC_TELEGRAM_MENU === "1" || config.enabled)) {
      background(ctx, syncTelegramEntry(env, store, config));
    }
    if (!telegramId(env.ADMIN_ID)) return;
    if (env.P2P_MODE === "private") background(ctx, p2pCron(store, env));
    background(ctx, (async () => {
      for (const row of await store.dueNotices()) {
        await sendNotice(env, store, row.id).catch(() => console.error("ARSLAN BOOST admin notice retry failed"));
      }
    })());
  }
};
export {
  worker_default as default
};

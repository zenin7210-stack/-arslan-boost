const BOT_USERNAME = "arslanboostbot";
const WEBHOOK_URL = "https://arslan-boost-bot.zenin7210.workers.dev/telegram";
const DEFAULT_MINIAPP_URL = "https://zenin7210-stack.github.io/-arslan-boost/";

function validSecret(value) {
  return typeof value === "string" && /^[A-Za-z0-9_-]{32,256}$/.test(value);
}

function matchesSecret(actual, expected) {
  if (!validSecret(expected) || !validSecret(actual) || actual.length !== expected.length) {
    return false;
  }
  let difference = 0;
  for (let i = 0; i < expected.length; i++) {
    difference |= actual.charCodeAt(i) ^ expected.charCodeAt(i);
  }
  return difference === 0;
}

function miniAppUrl(env) {
  try {
    const url = new URL(env.MINIAPP_URL?.trim() || DEFAULT_MINIAPP_URL);
    return url.protocol === "https:" && !url.username && !url.password ? url.href : null;
  } catch {
    return null;
  }
}

async function telegram(env, method, params = {}) {
  const token = env.BOT_TOKEN?.trim();
  if (!token || !/^\d+:[A-Za-z0-9_-]+$/.test(token)) {
    throw new Error("BOT_TOKEN is missing or invalid");
  }
  const response = await fetch("https://api.telegram.org/bot" + token + "/" + method, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(params),
    signal: AbortSignal.timeout(8000),
  });
  const data = await response.json();
  if (!response.ok || data.ok !== true) {
    const error = new Error("Telegram API error: " + method);
    error.telegramCode = Number.isInteger(data.error_code) ? data.error_code : response.status;
    throw error;
  }
  return data.result;
}

function setupPage(body, status = 200, nonce = "") {
  const csp = "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; "
    + "base-uri 'none'; frame-ancestors 'none'"
    + (nonce ? "; script-src 'nonce-" + nonce + "'" : "");
  return new Response(
    "<!doctype html><html lang=\"ru\"><meta charset=\"utf-8\">"
    + "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
    + "<title>Подключение ARSLAN BOOST</title>"
    + "<style>body{font:16px/1.5 system-ui,sans-serif;background:#f4f7fb;color:#16243a;margin:0}"
    + "main{max-width:35rem;margin:2rem auto;padding:1.25rem}"
    + "h1{font-size:1.5rem;margin-top:0}input,button{box-sizing:border-box;font:inherit}"
    + "input{width:100%;padding:.7rem;border:1px solid #8998ab;border-radius:.5rem;margin:.4rem 0 .65rem}"
    + "button{min-height:44px;padding:.55rem .9rem;border:0;border-radius:.5rem;color:#fff;background:#135ac1}"
    + "a{color:#135ac1}</style><main><h1>Подключение ARSLAN BOOST</h1>"
    + body + "</main></html>",
    {
      status,
      headers: {
        "content-type": "text/html; charset=utf-8",
        "cache-control": "no-store",
        "content-security-policy": csp,
        "referrer-policy": "no-referrer",
        "x-content-type-options": "nosniff",
      },
    },
  );
}

function showSetup(env) {
  if (!validSecret(env.WEBHOOK_SECRET)) {
    const code = crypto.randomUUID().replaceAll("-", "");
    const nonce = crypto.randomUUID();
    return setupPage(
      '<p>Скопируй код и сохрани его в настройках Worker как секрет <strong>WEBHOOK_SECRET</strong>.</p>'
      + '<label for="code">Код подключения</label><input id="code" type="text" readonly value="' + code + '">'
      + '<button id="copy" type="button">Скопировать код</button>'
      + '<p>После сохранения секрета вернись на эту страницу и обнови её.</p>'
      + '<script nonce="' + nonce + '">'
      + "const button = document.getElementById('copy');"
      + "button.addEventListener('click', async () => {"
      + "const input = document.getElementById('code');"
      + "try { await navigator.clipboard.writeText(input.value); button.textContent = 'Скопировано'; }"
      + "catch { input.focus(); input.select(); }"
      + "});</script>",
      200,
      nonce,
    );
  }
  return setupPage(
    '<p>После подключения команды бота будут приходить в этот Worker. Он отвечает на <code>/start</code> и открывает Mini App.</p>'
    + '<form method="post" action="/setup">'
    + '<label for="secret">Код WEBHOOK_SECRET</label>'
    + '<input id="secret" name="secret" type="password" maxlength="256" required autocomplete="off">'
    + '<button type="submit">Подключить Telegram</button></form>',
  );
}

async function connectTelegram(request, env) {
  const form = await request.formData().catch(() => null);
  if (!matchesSecret(form?.get("secret"), env.WEBHOOK_SECRET)) {
    return setupPage('<p>Код подключения не совпал.</p><p><a href="/setup">Попробовать снова</a></p>', 403);
  }
  if (!miniAppUrl(env)) {
    return setupPage("<p>Укажи HTTPS-адрес Mini App в настройке MINIAPP_URL.</p>", 400);
  }

  try {
    const bot = await telegram(env, "getMe");
    if (bot.username?.toLowerCase() !== BOT_USERNAME) {
      return setupPage("<p>Этот токен принадлежит другому боту. Проверь BOT_TOKEN для @arslanboostbot.</p>", 400);
    }

    const current = await telegram(env, "getWebhookInfo");
    if (current.url && current.url !== WEBHOOK_URL) {
      return setupPage("<p>У бота уже есть другой webhook. Чтобы не отключить текущий сервер, эта страница его не заменяет.</p>", 409);
    }

    await telegram(env, "setWebhook", {
      url: WEBHOOK_URL,
      secret_token: env.WEBHOOK_SECRET,
      allowed_updates: ["message"],
      drop_pending_updates: false,
    });
    return setupPage('<p>Telegram подключён. Открой <a href="https://t.me/arslanboostbot">@arslanboostbot</a> и отправь <code>/start</code>.</p>');
  } catch (error) {
    if (!env.BOT_TOKEN || error.telegramCode === 401 || error.telegramCode === 404) {
      return setupPage("<p>Проверь секрет BOT_TOKEN. Нужен токен @arslanboostbot из BotFather.</p>", 400);
    }
    console.error("Telegram setup failed", error.telegramCode ?? "network or configuration");
    return setupPage('<p>Не удалось подключить Telegram. Проверь настройки Worker и повтори попытку.</p><p><a href="/setup">Вернуться</a></p>', 502);
  }
}

async function handleUpdate(request, env) {
  if (!matchesSecret(request.headers.get("X-Telegram-Bot-Api-Secret-Token"), env.WEBHOOK_SECRET)) {
    return new Response("Forbidden", { status: 403 });
  }

  const update = await request.json().catch(() => null);
  if (!update) return new Response("Bad request", { status: 400 });

  const message = update.message;
  const isStart = typeof message?.text === "string"
    && /^\/start(?:@arslanboostbot)?(?:\s|$)/i.test(message.text);
  if (message?.chat?.type !== "private" || !isStart) return new Response("OK");

  const url = miniAppUrl(env);
  if (!url) return new Response("Invalid MINIAPP_URL", { status: 503 });

  try {
    await telegram(env, "sendMessage", {
      chat_id: message.chat.id,
      text: "Assalomu alaykum! ARSLAN BOOST’ga xush kelibsiz.",
      reply_markup: {
        inline_keyboard: [[{
          text: "🚀 ARSLAN BOOST’ni ochish",
          web_app: { url },
        }]],
      },
    });
  } catch (error) {
    if (error.telegramCode === 403) return new Response("OK");
    console.error("Telegram reply failed", error.telegramCode ?? "network or configuration");
    return new Response("Telegram API unavailable", { status: 502 });
  }
  return new Response("OK");
}

export default {
  async fetch(request, env) {
    const path = new URL(request.url).pathname;
    if (path === "/setup") {
      if (request.method === "GET") return showSetup(env);
      if (request.method === "POST") return connectTelegram(request, env);
      return new Response("Method not allowed", { status: 405, headers: { allow: "GET, POST" } });
    }
    if (path === "/telegram") {
      if (request.method === "POST") return handleUpdate(request, env);
      return new Response("Method not allowed", { status: 405, headers: { allow: "POST" } });
    }
    if (path === "/" && request.method === "GET") {
      return new Response("ARSLAN BOOST Worker is online");
    }
    return new Response("Not found", { status: 404 });
  },
};

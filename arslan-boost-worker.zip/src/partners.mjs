import { formatAmount, integer, RequestError } from "./catalog.mjs";
import { orderTables, utc } from "./store.mjs";
import { telegram } from "./telegram.mjs";

const minimum = 10000;
const earned = (operator) => `SELECT COALESCE(SUM(commission),0) FROM partner_earnings
  WHERE partner=? AND available_at ${operator} ?`;
const reserved = "SELECT COALESCE(SUM(amount),0) FROM partner_payouts WHERE partner=? AND status IN ('pending','paid')";
const nextDay = () => new Date(Date.now() + 86400000).toISOString();

export async function bindPartner(store, buyer, parameter) {
  const code = /^ref_([a-z0-9]{24})$/.exec(parameter || "")?.[1];
  if (!code) return;
  await store.stmt(`INSERT INTO partner_buyers(buyer,partner,joined_at)
    SELECT ?,user_id,? FROM partners WHERE code=? AND status='approved' AND user_id<>?
    ON CONFLICT(buyer) DO NOTHING`, buyer, utc(), code, buyer).run();
}

async function dashboard(store, config, user) {
  const row = await store.first("SELECT status,code FROM partners WHERE user_id=?", user);
  const status = row?.status ?? "none";
  if (status !== "approved") return { status, minWithdraw: minimum };
  const time = utc();
  const [totals, history, withdrawals] = await store.db.batch([
    store.stmt(`SELECT (${earned("<=")}) AS earned, (${earned(">")}) AS pending,
      (${reserved}) AS reserved, (SELECT COUNT(*) FROM partner_buyers WHERE partner=?) AS clients`,
      user, time, user, time, user, user),
    store.stmt(`SELECT kind,order_id AS orderId,commission,
      CASE WHEN available_at<=? THEN 'available' ELSE 'pending' END AS status
      FROM partner_earnings WHERE partner=? ORDER BY available_at DESC LIMIT 15`, time, user),
    store.stmt("SELECT id,amount,status FROM partner_payouts WHERE partner=? ORDER BY id DESC LIMIT 10", user),
  ]);
  const total = totals.results[0];
  return { status, minWithdraw: minimum, clients: total.clients, pending: total.pending,
    available: Math.max(0, total.earned - total.reserved), history: history.results,
    withdrawals: withdrawals.results, url: config.name ? `https://t.me/${config.name}?start=ref_${row.code}` : null };
}

async function adminMessage(env, config, text, buttons) {
  await telegram(env, "sendMessage", {
    chat_id: config.admin, text, reply_markup: { inline_keyboard: [buttons] },
  });
}

export async function partnerApi(env, ctx, store, config, path, user, data) {
  if (path === "referral/me") return dashboard(store, config, user.id);
  if (!config.admin) throw new RequestError("admin_not_configured", 503);
  if (path === "referral/apply") {
    const row = await store.first(`INSERT INTO partners(user_id,username,status) VALUES (?,?,'pending')
      ON CONFLICT(user_id) DO UPDATE SET username=excluded.username,status='pending'
      WHERE partners.status='rejected' RETURNING status`, user.id, user.username);
    if (row) ctx.waitUntil(adminMessage(env, config, `Заявка партнёра · ID ${user.id}`, [
      { text: "Одобрить", callback_data: `partner:approve:${user.id}` },
      { text: "Отклонить", callback_data: `partner:reject:${user.id}` },
    ]).catch(() => console.error("Partner application notice failed")));
    const status = row ?? await store.first("SELECT status FROM partners WHERE user_id=?", user.id);
    return { status: status.status };
  }
  const amount = integer(data.amount, minimum, 100000000000);
  const dest = typeof data.destination === "string" ? data.destination.trim() : "";
  if (dest.length < 5 || dest.length > 120 || /[\p{C}]/u.test(dest)) throw new RequestError("invalid_payout_details");
  const row = await store.first(`INSERT INTO partner_payouts(partner,amount,destination)
    SELECT ?,?,? WHERE EXISTS (SELECT 1 FROM partners WHERE user_id=? AND status='approved')
    AND (${earned("<=")}) - (${reserved}) >= ?
    AND NOT EXISTS (SELECT 1 FROM partner_payouts WHERE partner=? AND status='pending')
    RETURNING id`, user.id, amount, dest, user.id, user.id, utc(), user.id, amount, user.id);
  if (!row) throw new RequestError("insufficient_referral_balance", 409);
  ctx.waitUntil(adminMessage(env, config,
    `Запрос выплаты #${row.id}\nID ${user.id} · ${formatAmount(amount)} UZS\n${dest}`, [
      { text: "Отметить выплаченной", callback_data: `partner:paid:${row.id}` },
      { text: "Отклонить", callback_data: `partner:deny:${row.id}` },
    ]).catch(() => console.error("Partner payout notice failed")));
  return { id: row.id, status: "pending" };
}

export async function partnerCallback(env, store, config, query) {
  const match = /^partner:(approve|reject|paid|deny):(\d+)$/.exec(query.data || "");
  if (!match) return false;
  let text = "Нет доступа";
  if (query.from?.id === config.admin && config.admin) {
    const [, action, rawId] = match;
    const id = integer(rawId);
    if (["approve","reject"].includes(action)) {
      const approve = action === "approve";
      const code = approve ? crypto.randomUUID().replaceAll("-","").slice(0,24) : null;
      const row = await store.first("UPDATE partners SET status=?,code=? WHERE user_id=? AND status='pending' RETURNING user_id",
        approve ? "approved" : "rejected", code, id);
      text = row ? (approve ? "Партнёр одобрен" : "Заявка отклонена") : "Заявка уже обработана";
    } else {
      const row = await store.first("UPDATE partner_payouts SET status=? WHERE id=? AND status='pending' RETURNING id",
        action === "paid" ? "paid" : "rejected", id);
      text = row ? "Статус выплаты сохранён" : "Заявка уже обработана";
    }
  }
  await telegram(env, "answerCallbackQuery", { callback_query_id: query.id, text });
  return true;
}

export async function fulfillOrder(store, kind, id, cost) {
  if (!["boost", "donat"].includes(kind)) throw new RequestError("invalid_kind");
  const { table } = orderTables[kind === "boost" ? "order" : "donat"];
  const [, order] = await store.db.batch([
    store.stmt(`INSERT INTO partner_earnings(kind,order_id,partner,commission,available_at)
      SELECT ?,o.id,b.partner,CAST(MAX(0,o.amount-?)/2 AS INTEGER),?
      FROM ${table} o JOIN partner_buyers b ON b.buyer=o.user_id
      JOIN partners p ON p.user_id=b.partner AND p.status='approved'
      WHERE o.id=? AND o.status IN ('paid','in_progress') AND b.joined_at<=o.created_at
      ON CONFLICT(kind,order_id) DO NOTHING`, kind, cost, nextDay(), id),
    store.stmt(`UPDATE ${table} SET status='fulfilled' WHERE id=? AND status IN ('paid','in_progress')
      RETURNING id,user_id,lang`, id),
  ]);
  return order.results[0];
}

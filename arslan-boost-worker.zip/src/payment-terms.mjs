import { formatAmount } from "./catalog.mjs";

export function paymentTerms(config, rate) {
  const username = config.support || config.name;
  const contact = `<a href="https://t.me/${username}">@${username}</a>`;
  const amount = formatAmount(rate);
  return new Response(`<!doctype html>
<html lang="uz">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ARSLAN BOOST · To‘lov shartlari</title>
  <style>
    :root { color-scheme: dark; background: #0b1628; color: #f5f9ff; font: 16px/1.55 system-ui, sans-serif; }
    main { box-sizing: border-box; max-width: 36rem; margin: 0 auto; padding: 1.5rem 1rem 2.5rem; }
    section { padding: 1rem 1.25rem; border: 1px solid #346392; border-radius: 1rem; margin-top: 1rem; background: #102238; }
    h1 { font-size: 1.5rem; margin: 0; }
    h2 { font-size: 1.15rem; margin: 0; }
    p { color: #d1dff1; margin: .75rem 0 0; }
    a { color: #71dcff; }
  </style>
</head>
<body><main>
  <h1>ARSLAN BOOST</h1>
  <section aria-labelledby="terms-uz">
    <h2 id="terms-uz">To‘lov shartlari</h2>
    <p>Telegramdagi buyurtmalar uchun to‘lov Stars orqali amalga oshiriladi. Mahsulot va Stars miqdori tasdiqlashdan oldin hisobda ko‘rsatiladi.</p>
    ${rate ? `<p>Do‘kon balansini to‘ldirishda 1 ⭐ uchun ${amount} so‘m hisoblanadi. Balansdan ARSLAN BOOST’dagi xaridlar uchun foydalanish mumkin.</p>` : ""}
    <p>To‘lov yoki mablag‘ni qaytarish bo‘yicha do‘kon yordam xizmatiga murojaat qiling. ${contact} yoki botdagi /paysupport orqali buyurtma yoki to‘lov raqamini yuboring. Xaridlar bo‘yicha murojaatlarni ARSLAN BOOST ko‘rib chiqadi.</p>
  </section>
  <section lang="ru" aria-labelledby="terms-ru">
    <h2 id="terms-ru">Условия оплаты</h2>
    <p>Заказы в Telegram оплачиваются в Stars. Товар и сумма в Stars видны в счёте до подтверждения.</p>
    ${rate ? `<p>При пополнении баланса магазина 1 ⭐ зачисляется как ${amount} сум. Баланс можно использовать для покупок в ARSLAN BOOST.</p>` : ""}
    <p>По вопросам оплаты и возврата обращайтесь в поддержку магазина. Укажите номер заказа или платежа в сообщении ${contact} или через /paysupport в боте. Обращения по покупкам рассматривает ARSLAN BOOST.</p>
  </section>
</main></body></html>`, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "no-store",
      "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'",
      "Referrer-Policy": "no-referrer",
      "X-Content-Type-Options": "nosniff",
    },
  });
}

import {
  catalog, CALIBRATION_LEGEND_PRICE, formatAmount, integer, MAX_AMOUNT, MAX_STARS,
  MIN_BOOST_PRICE, MODE_SURCHARGE, MODES, PRICES, productTitle, RANKS, RequestError,
} from "./catalog.mjs";
import { processing, Store } from "./store.mjs";
import { paymentTerms } from "./payment-terms.mjs";
import { bindPartner, fulfillOrder, partnerApi, partnerCallback } from "./partners.mjs";
import { authorizeRelay, inspectBankChat, p2pAccess, p2pApi, p2pCallback, p2pCommand, p2pCron,
  p2pReceipt, receiveIncoming, sendP2pNotice } from "./p2p.mjs";
import {
  authenticate, botToken, isTest, matchesSecret, telegram, telegramId, username, validSecret, validToken,
} from "./telegram.mjs";

const paymentUpdates = ["message", "pre_checkout_query", "callback_query"];
const testInvoiceAmount = 5000000; // 50,000 UZS in tiyin
const testProviders = [
  { command: "/clicktest", prefix: "click-test", label: "CLICK", secret: "CLICK_TEST_PROVIDER_TOKEN" },
  { command: "/paymetest", prefix: "payme-test", label: "Payme", secret: "PAYME_TEST_PROVIDER_TOKEN" },
];

function testProviderToken(env, provider) {
  const token = env[provider.secret]?.trim();
  return token && /^\d+:TEST:[A-Za-z0-9_-]+$/.test(token) ? token : "";
}

function testProviderFor(payment) {
  if (typeof payment?.invoice_payload !== "string") return undefined;
  return testProviders.find(provider => payment.invoice_payload.startsWith(provider.prefix + ":"));
}

function validTestPayment(payment, sender, config, provider) {
  return Boolean(config.admin && telegramId(sender?.id) === config.admin &&
    payment.currency === "UZS" && payment.total_amount === testInvoiceAmount &&
    /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(
      payment.invoice_payload.slice(provider.prefix.length + 1)));
}

function requiredTelegramUpdates(env) {
  return env.P2P_CHAT_DIAGNOSTICS === "1" ? [...paymentUpdates, "business_message"] : paymentUpdates;
}

function httpsUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && !url.username && !url.password ? url.href : "";
  } catch {
    return "";
  }
}

function rate(value) {
  const n = Number(value);
  return Number.isSafeInteger(n) && n > 0 && n <= 1000000 ? n : 0;
}

function settings(env, requestUrl) {
  const app = httpsUrl(env.MINIAPP_URL || requestUrl?.origin);
  const test = isTest(env);
  const terms = httpsUrl(env.STARS_TERMS_URL) || (test && app ? new URL("/test-terms", app).href : "");
  const admin = telegramId(env.ADMIN_ID);
  const name = username(env.BOT_USERNAME?.replace(/^@/, ""));
  const support = username(env.ADMIN_USERNAME?.replace(/^@/, ""));
  const webhookReady = ["0", "1"].includes(env.TELEGRAM_TEST_ENV) &&
    Boolean(name && app && validSecret(env.WEBHOOK_SECRET) && validToken(botToken(env)));
  const enabled = env.ENABLE_PAYMENTS === "1" && webhookReady && Boolean(terms && admin);
  return {
    app, test, terms, admin, name, support, webhookReady, enabled,
    topupRate: enabled ? rate(env.STARS_TOPUP_RATE_UZS) : 0,
    orderRate: enabled ? rate(env.STARS_RATE_UZS) : 0,
  };
}

function webhookAddress(config) {
  return new URL("/telegram", config.app).href;
}

async function checkoutSettings(store, config) {
  if (!config.enabled || config.test) return config;
  const row = await store.first("SELECT checkout_webhook_url FROM telegram_entry WHERE id = 1");
  if (row?.checkout_webhook_url === webhookAddress(config)) return config;
  return { ...config, enabled: false, topupRate: 0, orderRate: 0 };
}

function json(body, status = 200) {
  return Response.json(body, { status, headers: { "Cache-Control": "no-store" } });
}

function requireStars(data, configuredRate) {
  if (data.paymentMethod !== "stars") throw new RequestError("invalid_payment_method");
  if (!configuredRate) throw new RequestError("stars_not_configured", 503);
  if (data.acceptTerms !== true) throw new RequestError("terms_required");
}

async function readObject(request) {
  if (Number(request.headers.get("Content-Length")) > 16000) {
    throw new RequestError("invalid_request", 413);
  }
  const body = await request.json().catch(() => null);
  if (!body || typeof body !== "object" || Array.isArray(body)) throw new RequestError("invalid_json");
  return body;
}

function langText(lang, ru, uz) {
  return lang === "ru" ? ru : uz;
}

function background(ctx, work) {
  ctx.waitUntil(work.catch(() => console.error("ARSLAN BOOST background task failed")));
}

async function sendNotice(env, store, id) {
  const admin = telegramId(env.ADMIN_ID);
  if (!admin) return;
  const payment = await store.claimNotice(id);
  if (!payment) return;
  const order = await store.paymentOrder(payment);
  if (!order) throw new Error("Order missing");
  const title = payment.kind === "order"
    ? `Boost #${order.id} · ${MODES.get(order.mode)}\n${RANKS[order.current_rank]} → ${RANKS[order.target_rank]}\nID: ${order.game_id}`
    : `Donat Shop #${order.id}\n${productTitle(order.product)} · ${order.option_label}\nДанные: ${order.detail || "—"}`;
  const method = payment.method === "stars" ? `${formatAmount(payment.stars)} ⭐` : "Баланс";
  const params = {
    chat_id: admin,
    text: `✅ Заказ оплачен\n\n${title}\n💰 ${formatAmount(payment.amount)} UZS · ${method}`
      + `\n👤 Telegram ID: ${payment.user_id}${order.username ? " · @" + order.username : ""}\nПлатёж #${id}`,
  };
  if (payment.kind === "order") {
    params.reply_markup = { inline_keyboard: [[{ text: "▶ В работу", callback_data: `boost_work:${order.id}` }]] };
  }
  await telegram(env, "sendMessage", params);
  await store.markNotified(payment);
}

async function paymentDetails(env, store, payment, { invoice = false, lang = "uz", order } = {}) {
  const result = {
    id: payment.id, amount: payment.amount, stars: payment.stars, kind: payment.kind,
    method: payment.method, status: payment.status, orderId: payment.order_id ?? payment.donat_order_id,
    processing: processing(payment),
  };
  if (!invoice || result.status !== "pending" || result.processing) return result;
  const row = order ?? await store.paymentOrder(payment);
  const title = payment.kind === "donat" ? productTitle(row.product) : "ARSLAN BOOST";
  const description = {
    topup: langText(lang, "Пополнение баланса", "Balansni to‘ldirish"),
    order: langText(lang, "Повышение ранга", "Rank oshirish") + " #" + result.orderId,
    donat: "Donat Shop #" + result.orderId + (row?.option_label ? " · " + row.option_label : ""),
  };
  result.invoiceLink = await telegram(env, "createInvoiceLink", {
    title: title.slice(0, 32), description: description[payment.kind].slice(0, 255),
    payload: "ab:" + payment.id, provider_token: "", currency: "XTR",
    prices: [{ label: langText(lang, "Сумма", "Summa"), amount: payment.stars }],
  });
  return result;
}

async function publicConfig(store, config) {
  return {
    arslanBoostApi: true,
    botUrl: config.name ? "https://t.me/" + config.name : null,
    supportUrl: config.support ? "https://t.me/" + config.support : null,
    termsUrl: config.terms, starsRate: config.topupRate, orderStarsRate: config.orderRate,
    starsMax: config.topupRate ? Math.min(MAX_STARS, Math.floor(MAX_AMOUNT / config.topupRate)) : 0,
    orderStarsMax: config.orderRate ? MAX_STARS : 0,
    prices: PRICES, calibrationLegendPrice: CALIBRATION_LEGEND_PRICE,
    boostModeSurcharge: MODE_SURCHARGE, minBoostPrice: MIN_BOOST_PRICE, boostEta: await store.eta(),
  };
}

async function handleApi(request, env, ctx, store, config, path) {
  if (path === "invoice" || path.startsWith("invoice/")) {
    const user = await authenticate(request, env);
    const data = request.method === "POST" ? await readObject(request) : {};
    return json(await p2pApi(request, env, store, config, user, data, path));
  }
  if (request.method === "GET") {
    if (path === "config") return json(await publicConfig(store, config));
    if (path === "donat/catalog") return json(catalog);
    return json({ error: "endpoint_missing" }, 404);
  }
  if (request.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  const user = await authenticate(request, env);
  const data = await readObject(request);
  switch (path) {
    case "referral/me":
    case "referral/apply":
    case "referral/withdraw":
      return json(await partnerApi(env, ctx, store, config, path, user, data));
    case "state":
      return json({ ...await store.state(user.id), p2pPrivate: p2pAccess(env, user.id) });
    case "donat/state":
      return json({ orders: await store.donatState(user.id) });
    case "profile":
      return json(await store.profile(user.id, data));
    case "topup": {
      requireStars(data, config.topupRate);
      const payment = await store.createTopup(user.id, data, config.topupRate);
      return json(await paymentDetails(env, store, payment, { invoice: true, lang: data.lang }));
    }
    case "payment/status": {
      const payment = await store.userPayment(integer(data.paymentId), user.id);
      const configured = payment.kind === "topup" ? config.topupRate : config.orderRate;
      return json(await paymentDetails(env, store, payment, {
        invoice: Boolean(configured && data.resume === true), lang: data.lang,
      }));
    }
    case "checkout":
    case "donat/create": {
      if (data.paymentMethod === "stars") requireStars(data, config.orderRate);
      else if (data.paymentMethod !== "balance") throw new RequestError("invalid_payment_method");
      else if (!config.enabled) throw new RequestError("stars_not_configured", 503);
      const kind = path === "checkout" ? "order" : "donat";
      const { order, payment } = await store.createOrder(kind, user, data, config.orderRate);
      const result = { id: order.id, amount: order.amount, status: order.status };
      if (kind === "order") result.boostEta = [order.eta_min_hours, order.eta_max_hours];
      if (payment.method === "stars") {
        result.payment = await paymentDetails(env, store, payment, { invoice: true, order, lang: data.lang });
      } else if (payment.admin_notice_pending) {
        background(ctx, sendNotice(env, store, payment.id));
      }
      return json(result);
    }
    case "order-help":
      throw new RequestError("automatic_payment_only");
    default:
      return json({ error: "endpoint_missing" }, 404);
  }
}

function paymentId(payload) {
  const match = typeof payload === "string" && /^ab:([0-9]{1,16})$/.exec(payload);
  return match ? telegramId(match[1]) || null : null;
}

async function handlePreCheckout(env, store, config, query) {
  const id = paymentId(query.invoice_payload);
  const buyer = telegramId(query.from?.id);
  let reserved = false;
  if (config.enabled && id && buyer && typeof query.id === "string" &&
      query.currency === "XTR" && Number.isSafeInteger(query.total_amount) &&
      query.total_amount > 0 && query.total_amount <= MAX_STARS) {
    try {
      reserved = Boolean(await store.reserveCheckout(id, buyer, query.total_amount, query.id));
    } catch {
      console.error("ARSLAN BOOST checkout reservation failed");
    }
  }
  await telegram(env, "answerPreCheckoutQuery", {
    pre_checkout_query_id: query.id, ok: reserved,
    ...(reserved ? {} : { error_message: langText(query.from?.language_code,
      "Проверьте сумму или откройте счёт из истории заказов.",
      "Summani tekshiring yoki hisobni buyurtmalar tarixidan oching.") }),
  });
}

async function handlePaid(env, ctx, store, message) {
  const payment = message.successful_payment;
  const buyer = telegramId(message.from?.id);
  if (!buyer || typeof payment.currency !== "string" || !/^[A-Z]{3}$/.test(payment.currency) ||
      typeof payment.telegram_payment_charge_id !== "string" ||
      !payment.telegram_payment_charge_id || payment.telegram_payment_charge_id.length > 512 ||
      !Number.isSafeInteger(payment.total_amount) || payment.total_amount < 1) {
    console.error("ARSLAN BOOST invalid payment update");
    return;
  }
  const result = await store.settle(paymentId(payment.invoice_payload), buyer, payment);
  if (!result) {
    console.error("ARSLAN BOOST payment requires reconciliation");
    return;
  }
  if (result.payment.admin_notice_pending) background(ctx, sendNotice(env, store, result.payment.id));
  if (result.changed) {
    const lang = message.from?.language_code;
    const text = result.payment.kind === "topup"
      ? langText(lang, "✅ Баланс пополнен на ", "✅ Balansga qo‘shildi: ") + formatAmount(result.payment.amount) + " UZS"
      : langText(lang, "✅ Заказ оплачен. Администратор получил заявку.", "✅ To‘lov qabul qilindi. Buyurtma administratorga yuborildi.");
    background(ctx, telegram(env, "sendMessage", { chat_id: buyer, text }));
  }
}

async function handleCommand(env, store, config, message) {
  const [raw, ...args] = (message.text || "").trim().split(/\s+/);
  const command = raw.split("@", 1)[0];
  const chatId = message.chat.id;
  const lang = message.from?.language_code;
  const say = (text, extra) => telegram(env, "sendMessage", { chat_id: chatId, text, ...extra });
  if (await p2pCommand(env, store, config, message, command, args)) return;
  const testProvider = testProviders.find(provider => provider.command === command);
  if (testProvider) {
    if (!config.admin || telegramId(message.from?.id) !== config.admin) return;
    const token = testProviderToken(env, testProvider);
    if (!token) return say(`Добавьте тестовый токен из BotFather в секрет ${testProvider.secret}.`);
    try {
      return await telegram(env, "sendInvoice", {
        chat_id: chatId,
        title: `Тест ${testProvider.label}`,
        description: "Проверка оплаты. Без заказа и начисления баланса.",
        payload: testProvider.prefix + ":" + crypto.randomUUID(),
        provider_token: token,
        currency: "UZS",
        prices: [{ label: "Тестовый счёт", amount: testInvoiceAmount }],
        start_parameter: testProvider.prefix,
      });
    } catch (error) {
      if (!(error instanceof RequestError) || error.message !== "telegram_unavailable") throw error;
      const reason = error.invoiceError || (Number.isInteger(error.telegramCode)
        ? `Telegram ${error.telegramCode}`
        : "Telegram не ответил");
      return say(`Не удалось выставить тестовый счёт ${testProvider.label} (${reason}).`);
    }
  }
  switch (command) {
    case "/start":
    case "/preview": {
      const preview = command === "/preview";
      const url = config.app;
      if (!url) throw new RequestError("miniapp_url_required", 503);
      if (!preview) await bindPartner(store, message.from.id, args[0]);
      const greeting = preview
        ? langText(lang, "Открой обновлённый ARSLAN BOOST.", "Yangilangan ARSLAN BOOST’ni oching.")
        : langText(lang, "Добро пожаловать в ARSLAN BOOST!", "ARSLAN BOOST’ga xush kelibsiz!");
      return say(greeting
        + (config.test ? "\n\n🧪 ID: " + message.from.id : ""), {
        reply_markup: { inline_keyboard: [[{
          text: langText(lang, "🚀 Открыть Mini App", "🚀 Mini App’ni ochish"),
          web_app: { url },
        }]] },
      });
    }
    case "/balance": {
      const user = await store.first("SELECT stars_balance FROM accounts WHERE user_id = ?", message.from.id);
      return say(langText(lang, "Баланс: ", "Balans: ") + formatAmount(user?.stars_balance ?? 0) + " UZS");
    }
    case "/id":
      return say("Telegram ID: " + message.from.id);
    case "/terms":
      return say(config.terms || langText(lang, "Условия оплаты доступны у поддержки.", "To‘lov shartlari uchun yordam xizmatiga yozing."));
    case "/support":
    case "/paysupport":
      return say(langText(lang, "Укажите номер заказа или платежа.", "Buyurtma yoki to‘lov raqamini yozing.")
        + (config.support ? " https://t.me/" + config.support : ""));
    case "/admin":
      if (config.admin && message.from.id === config.admin) {
        return say("ARSLAN BOOST\n/delivered donat 123 9000 — выдать заказ, указав себестоимость\n/delivered boost 123 9000 — завершить буст\n/boost_eta 24 48 — сроки буста\n/p2p_card list — карты теста");
      }
      return;
    case "/partner":
      return say(langText(lang, "Откройте раздел «Партнёры» в Mini App.", "Mini App’dagi «Hamkorlar» bo‘limini oching."));
    case "/delivered": {
      if (!config.admin || message.from.id !== config.admin) return;
      let order;
      try {
        if (args.length !== 3) throw new RequestError("invalid_request");
        order = await fulfillOrder(store, args[0], integer(args[1]), integer(args[2], 0, 100000000000));
      } catch (error) {
        if (!(error instanceof RequestError)) throw error;
        return say("/delivered donat 123 9000 или /delivered boost 123 9000");
      }
      if (!order) return say("Оплаченный заказ не найден или уже выполнен.");
      await telegram(env, "sendMessage", { chat_id: order.user_id,
        text: langText(order.lang, `✅ Заказ #${order.id} выполнен.`, `✅ Buyurtma #${order.id} bajarildi.`) }).catch(() => {});
      return say(`✅ Заказ #${order.id} выполнен.`);
    }
    case "/boost_eta":
      if (message.from.id !== config.admin) return;
      try {
        if (args[0] === "off" && args.length === 1) {
          await store.stmt("DELETE FROM boost_schedule WHERE id = 1").run();
          return say("Срок скрыт.");
        }
        if (args.length < 1 || args.length > 2) throw new RequestError("invalid_number");
        const low = integer(args[0], 1, 720);
        const high = integer(args.at(-1), low, 720);
        await store.stmt(`
          INSERT INTO boost_schedule VALUES (1, ?, ?)
          ON CONFLICT (id) DO UPDATE SET min_hours = excluded.min_hours, max_hours = excluded.max_hours`,
          low, high).run();
        return say(`Срок буста: ${low === high ? low : low + "–" + high} ч после оплаты.`);
      } catch (error) {
        if (!(error instanceof RequestError)) throw error;
        return say("/boost_eta 24 48 или /boost_eta off");
      }
    default:
      return;
  }
}

async function handleCallback(env, store, config, query) {
  if (await p2pCallback(env, store, config, query)) return;
  if (await partnerCallback(env, store, config, query)) return;
  const work = typeof query.data === "string" && /^boost_work:([0-9]+)$/.exec(query.data);
  if (!work) return;
  let text = "Нет доступа";
  if (config.admin && query.from?.id === config.admin) {
    const order = await store.first(`
      UPDATE orders SET status = 'in_progress' WHERE id = ? AND status = 'paid'
      RETURNING id, user_id, lang`, integer(work[1]));
    text = order ? "В работе" : "Статус уже изменён";
    if (order) {
      await telegram(env, "sendMessage", { chat_id: order.user_id,
        text: langText(order.lang, `Буст #${order.id} в работе.`, `Boost #${order.id} bajarilmoqda.`),
      }).catch(() => {});
    }
  }
  await telegram(env, "answerCallbackQuery", { callback_query_id: query.id, text });
}

async function handleWebhook(request, env, ctx, store, config) {
  if (request.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  if (!matchesSecret(request.headers.get("X-Telegram-Bot-Api-Secret-Token"), env.WEBHOOK_SECRET)) {
    return json({ error: "forbidden" }, 403);
  }
  const update = await readObject(request);
  const query = update.pre_checkout_query;
  const payment = update.message?.successful_payment;
  const testQueryProvider = testProviderFor(query);
  const testPaymentProvider = testProviderFor(payment);
  if (testQueryProvider) {
    const ok = Boolean(testProviderToken(env, testQueryProvider) &&
      validTestPayment(query, query.from, config, testQueryProvider));
    await telegram(env, "answerPreCheckoutQuery", {
      pre_checkout_query_id: query.id, ok,
      ...(ok ? {} : { error_message: "Этот тестовый счёт недоступен." }),
    });
  } else if (testPaymentProvider) {
    const message = update.message;
    if (message.chat?.type === "private" && validTestPayment(payment, message.from, config, testPaymentProvider)) {
      await telegram(env, "sendMessage", {
        chat_id: message.chat.id,
        text: `✅ Telegram подтвердил тестовую оплату ${testPaymentProvider.label}.`,
      });
    }
  } else if (query) {
    await handlePreCheckout(env, store, await checkoutSettings(store, config), update.pre_checkout_query);
  } else if (update.message?.successful_payment && update.message.chat?.type === "private") {
    await handlePaid(env, ctx, store, update.message);
  } else if (update.callback_query) {
    await handleCallback(env, store, config, update.callback_query);
  } else if (update.business_message && env.P2P_CHAT_DIAGNOSTICS === "1") {
    await inspectBankChat(env, config.admin, update.business_message);
  } else if (update.message?.chat?.type === "private" && update.message.from?.id) {
    const message = update.message;
    if (message.text) await handleCommand(env, store, config, message);
    else if (env.P2P_MODE === "private") await p2pReceipt(env, store, config, message);
  }
  return new Response("OK");
}

function setupPage(content, status = 200) {
  return new Response(`<!doctype html><html lang="ru"><meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>ARSLAN BOOST · Подключение Telegram</title>
    <main><h1>Подключение Telegram</h1>${content}</main></html>`, {
    status,
    headers: {
      "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store",
      "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'",
      "Referrer-Policy": "no-referrer",
    },
  });
}

function receivesRequiredUpdates(webhook, env) {
  const subscribed = webhook.allowed_updates;
  return !Array.isArray(subscribed) || !subscribed.length ||
    requiredTelegramUpdates(env).every(update => subscribed.includes(update));
}

function registerWebhook(env, url, existing) {
  const subscribed = existing.allowed_updates;
  const required = requiredTelegramUpdates(env);
  const updates = existing.url
    ? (subscribed?.length ? [...new Set([...subscribed, ...required])] : [])
    : required;
  return telegram(env, "setWebhook", {
    url, secret_token: env.WEBHOOK_SECRET, drop_pending_updates: false,
    allowed_updates: updates,
  });
}

async function saveTelegramEntry(store, bot, menuUrl, checkoutUrl) {
  await store.stmt(`
    INSERT INTO telegram_entry (id, menu_url, webhook_connected, has_main_web_app, checkout_webhook_url)
    VALUES (1, ?, ?, ?, ?)
    ON CONFLICT (id) DO UPDATE SET
      menu_url = COALESCE(NULLIF(excluded.menu_url, ''), telegram_entry.menu_url),
      webhook_connected = excluded.webhook_connected, has_main_web_app = excluded.has_main_web_app,
      checkout_webhook_url = excluded.checkout_webhook_url
  `, menuUrl, Number(Boolean(checkoutUrl)), Number(bot.has_main_web_app === true), checkoutUrl).run();
}

async function setup(request, env, config, store) {
  if (!config.webhookReady) {
    return setupPage("<p>В настройках Worker задай BOT_USERNAME, BOT_TOKEN и WEBHOOK_SECRET.</p>", 503);
  }
  if (request.method === "GET") {
    return setupPage(`<p>Режим: ${config.test ? "тестовая сеть" : "рабочая сеть"}. Бот @${config.name}.</p>
      <form method="post" action="/setup"><label>WEBHOOK_SECRET
      <input name="secret" type="password" maxlength="256" autocomplete="off" required></label>
      <button type="submit">Подключить Telegram</button></form>`);
  }
  if (request.method !== "POST") return setupPage("<p>Неверный метод.</p>", 405);
  const form = await request.formData().catch(() => null);
  if (!matchesSecret(form?.get("secret"), env.WEBHOOK_SECRET)) {
    return setupPage("<p>Код не совпал. <a href=\"/setup\">Повторить</a></p>", 403);
  }
  const webhook = webhookAddress(config);
  const bot = await telegram(env, "getMe");
  if (bot.username?.toLowerCase() !== config.name.toLowerCase()) {
    return setupPage("<p>BOT_TOKEN принадлежит другому боту. Проверь BOT_USERNAME и сеть Telegram.</p>", 400);
  }
  const existing = await telegram(env, "getWebhookInfo");
  if (existing.url && existing.url !== webhook) {
    return setupPage("<p>У бота подключён webhook на другом адресе. Проверь адрес Worker в MINIAPP_URL.</p>", 409);
  }
  await store.eta();
  if (await registerWebhook(env, webhook, existing) !== true) {
    throw new RequestError("telegram_webhook_not_configured", 502);
  }
  await saveTelegramEntry(store, bot, "", webhook);
  return setupPage(`<p>Webhook подключён. Открой <a href="https://t.me/${config.name}">@${config.name}</a> и нажми Start.</p>`);
}

async function syncTelegramEntry(env, store, config) {
  const webhookUrl = webhookAddress(config);
  const saved = await store.first("SELECT menu_url, checkout_webhook_url FROM telegram_entry WHERE id = 1");
  const syncMenu = env.SYNC_TELEGRAM_MENU === "1" && saved?.menu_url !== config.app;
  if (!syncMenu && saved?.checkout_webhook_url === webhookUrl && env.P2P_CHAT_DIAGNOSTICS !== "1") return;

  const bot = await telegram(env, "getMe");
  if (bot.username?.toLowerCase() !== config.name.toLowerCase()) {
    throw new RequestError("wrong_bot_for_telegram_sync", 503);
  }
  const [menu, webhook] = await Promise.all([
    syncMenu ? telegram(env, "getChatMenuButton") : null,
    telegram(env, "getWebhookInfo"),
  ]);
  let webhookConnected = webhook.url === webhookUrl;
  if (!webhook.url || (webhookConnected && !receivesRequiredUpdates(webhook, env))) {
    webhookConnected = await registerWebhook(env, webhookUrl, webhook) === true;
    if (!webhookConnected) throw new Error("Telegram webhook was not configured");
  }
  if (menu && (menu.type !== "web_app" || menu.web_app?.url !== config.app)) {
    const updated = await telegram(env, "setChatMenuButton", {
      menu_button: { type: "web_app", text: menu.text || "Mini App", web_app: { url: config.app } },
    });
    if (updated !== true) throw new Error("Telegram menu was not updated");
  }
  await saveTelegramEntry(store, bot, syncMenu ? config.app : "", webhookConnected ? webhookUrl : null);
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const store = new Store(env.DB);
    const config = settings(env, url);
    try {
      if (/^\/relay\/(humo|uzcard|cardxabar)$/.test(path)) {
        const method = path.slice("/relay/".length);
        authorizeRelay(request, env, method);
        const event = await receiveIncoming(store, env, method, await readObject(request));
        if (event.invoiceId) background(ctx, sendP2pNotice(store, env, event.invoiceId));
        return json({ accepted: true, matched: event.matched, duplicate: event.duplicate });
      }
      if (path.startsWith("/api/")) {
        return await handleApi(request, env, ctx, store, await checkoutSettings(store, config), path.slice(5));
      }
      if (path === "/telegram") return await handleWebhook(request, env, ctx, store, config);
      if (path === "/setup") return await setup(request, env, config, store);
      if (path === "/healthz" && request.method === "GET") {
        await store.eta();
        const checkout = await checkoutSettings(store, config);
        return json({ ok: true, telegramTest: config.test, paymentsEnabled: Boolean(checkout.orderRate || checkout.topupRate) });
      }
      if (path === "/payment-terms" && request.method === "GET") {
        const approvedUrl = config.app ? new URL(path, config.app).href : "";
        if (!config.terms || config.terms !== approvedUrl || !config.name) return json({ error: "terms_not_published" }, 404);
        return paymentTerms(config, rate(env.STARS_TOPUP_RATE_UZS));
      }
      if (path === "/test-terms" && config.test && request.method === "GET") {
        return new Response("ARSLAN BOOST · Sinov to‘lovi\nТестовая оплата в тестовой сети Telegram.");
      }
      return env.ASSETS.fetch(request);
    } catch (error) {
      if (error instanceof RequestError) {
        if (path === "/setup") return setupPage("<p>Ошибка подключения. Проверь токен и сеть бота.</p>", error.status);
        if (path === "/telegram" && error.telegramCode === 403) return new Response("OK");
        return json({ error: error.message }, error.status);
      }
      console.error("ARSLAN BOOST Worker failed");
      return json({ error: "service_unavailable" }, 503);
    }
  },

  async scheduled(_controller, env, ctx) {
    const store = new Store(env.DB);
    const config = settings(env);
    if (config.webhookReady && (env.SYNC_TELEGRAM_MENU === "1" || config.enabled || env.P2P_CHAT_DIAGNOSTICS === "1")) {
      background(ctx, syncTelegramEntry(env, store, config));
    }
    if (!telegramId(env.ADMIN_ID)) return;
    if (env.P2P_MODE === "private") background(ctx, p2pCron(store, env));
    background(ctx, (async () => {
      for (const row of await store.dueNotices()) {
        await sendNotice(env, store, row.id).catch(() => console.error("ARSLAN BOOST admin notice retry failed"));
      }
    })());
  },
};

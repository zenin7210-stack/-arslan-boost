import { formatAmount, integer, MAX_AMOUNT, requestKey, RequestError } from "./catalog.mjs";
import { parseAmount, parseIncoming, reference } from "./p2p-notice.mjs";
import { isTest, matchesSecret, telegram, telegramId, username, validSecret } from "./telegram.mjs";

const now = () => Math.floor(Date.now() / 1000);
const HOLD_SECONDS = 86400;
const MIN_AMOUNT = 10000;
const METHOD = /^(humo|uzcard)$/;
const CARD_ID = /^[a-z0-9_-]{2,32}$/;
const EVENT_ID = /^[A-Za-z0-9:_.-]{1,120}$/;
const BANK_CHATS = new Map([["cardxabarbot", "CardXabar"], ["humocardbot", "HUMO Card"]]);

export function p2pAccess(env, userId) {
  return env.P2P_MODE === "private" && Boolean(telegramId(env.ADMIN_ID)) &&
    Boolean(env.P2P_USERS?.trim().split(/\s+/).includes(String(userId)));
}

function requireAccess(env, userId) {
  if (!p2pAccess(env, userId)) throw new RequestError("p2p_disabled", 403);
}

function cards(env) {
  let input;
  try { input = JSON.parse(env.P2P_CARDS || "[]"); } catch { input = null; }
  if (!Array.isArray(input) || input.length > 10) throw new RequestError("p2p_cards_invalid", 503);
  const ids = new Set();
  const keys = new Set();
  return input.map(card => {
    const { id, method, number, holder } = card || {};
    const key = method + ":" + number?.slice?.(-4);
    if (typeof id !== "string" || !CARD_ID.test(id) || ids.has(id) || keys.has(key) ||
        typeof method !== "string" || !METHOD.test(method) || typeof number !== "string" ||
        !/^[0-9]{16}$/.test(number) || typeof holder !== "string" ||
        !holder.trim() || holder.length > 64 || /[\p{C}<>]/u.test(holder)) {
      throw new RequestError("p2p_cards_invalid", 503);
    }
    ids.add(id);
    keys.add(key);
    return { id, method, number, holder, enabled: card.enabled !== false };
  });
}

async function availableCards(store, env) {
  const flags = new Map((await store.all("SELECT card_id, enabled FROM p2p_card_flags"))
    .map(row => [row.card_id, Boolean(row.enabled)]));
  return cards(env).filter(card => flags.get(card.id) ?? card.enabled);
}

export async function expireInvoices(store, at = now()) {
  await store.stmt("UPDATE invoices SET status = 'expired' WHERE status = 'pending' AND expires_at <= ?", at).run();
}

function ownedInvoice(store, id, userId) {
  return store.first("SELECT * FROM invoices WHERE id = ? AND user_id = ?", id, userId);
}

function publicInvoice(env, row, config) {
  const time = now();
  const status = row.status === "pending" && row.expires_at <= time ? "expired" : row.status;
  const card = status === "pending" ? cards(env).find(item => item.id === row.card_id &&
    item.number.endsWith(row.card_number)) : null;
  return {
    id: row.id, baseAmount: row.base_amount, uniqueAmount: row.unique_amount,
    method: row.payment_method, status, createdAt: row.created_at, expiresAt: row.expires_at,
    serverTime: time, checkedAt: row.checked_at,
    ...(card ? { cardNumber: card.number, cardHolder: row.card_holder } : {}),
    ...(config.name && ["pending", "expired"].includes(status) && row.checked_at !== null &&
      (time >= row.checked_at + 60 || status === "expired")
      ? { receiptLink: `https://t.me/${config.name}?start=p2p_${row.id}` } : {}),
  };
}

async function createInvoice(store, env, user, data) {
  const amount = integer(data.amount, MIN_AMOUNT, MAX_AMOUNT);
  const key = requestKey(data.requestId);
  const method = data.method;
  if (typeof method !== "string" || !METHOD.test(method)) throw new RequestError("invalid_payment_method");
  const retry = "SELECT * FROM invoices WHERE user_id = ? AND request_id = ?";
  const existing = await store.first(retry, user.id, key);
  if (existing) {
    if (existing.base_amount !== amount || existing.payment_method !== method) {
      throw new RequestError("request_conflict", 409);
    }
    return existing;
  }
  const candidates = (await availableCards(store, env)).filter(card => card.method === method);
  if (!candidates.length) throw new RequestError("p2p_method_unavailable", 409);
  const time = now();
  const active = "SELECT * FROM invoices WHERE user_id = ? AND status = 'pending'";
  const [, inserted, open, saved] = await store.db.batch([
    store.stmt("UPDATE invoices SET status = 'expired' WHERE status = 'pending' AND expires_at <= ?", time),
    store.stmt(`
      WITH available AS (
        SELECT config.key AS card_id, config.value AS metadata,
          COALESCE((SELECT MAX(created_at) FROM invoices WHERE invoices.card_id = config.key), 0) AS last_used
        FROM json_each(?) AS config
        LEFT JOIN p2p_card_flags flag ON flag.card_id = config.key
        WHERE COALESCE(flag.enabled, json_extract(config.value, '$.enabled')) = 1
      )
      INSERT INTO invoices (
        user_id, request_id, base_amount, unique_amount, payment_method, card_id,
        card_number, card_holder, status, created_at, expires_at, lang
      )
      SELECT ?, ?, ?, ?, ?, available.card_id,
        json_extract(available.metadata, '$.last4'),
        json_extract(available.metadata, '$.holder'), 'pending', ?, ?, ?
      FROM available
      WHERE NOT EXISTS (SELECT 1 FROM invoices WHERE unique_amount = ? AND status = 'pending')
      AND NOT EXISTS (SELECT 1 FROM invoices WHERE card_id = available.card_id AND unique_amount = ?
        AND (expires_at > ? OR status = 'manual_check' OR (status <> 'paid' AND created_at >= ?)))
      AND NOT EXISTS (SELECT 1 FROM invoices WHERE user_id = ? AND status = 'pending')
      AND NOT EXISTS (SELECT 1 FROM invoices WHERE user_id = ? AND request_id = ?)
      ORDER BY available.last_used, available.card_id LIMIT 1 RETURNING *`,
      JSON.stringify(Object.fromEntries(candidates.map(card => [card.id, {
        last4: card.number.slice(-4), holder: card.holder, enabled: Number(card.enabled),
      }]))),
      user.id, key, amount, amount, method,
      time, time + 600, data.lang === "ru" ? "ru" : "uz",
      amount, amount,
      time, time - HOLD_SECONDS, user.id, user.id, key),
    store.stmt(active, user.id), store.stmt(retry, user.id, key),
  ]);
  const result = inserted.results[0] || saved.results[0];
  if (result) {
    if (result.base_amount !== amount || result.payment_method !== method) throw new RequestError("request_conflict", 409);
    return result;
  }
  if (open.results[0]) return open.results[0];
  throw new RequestError("p2p_amount_unavailable", 409);
}

export async function p2pApi(request, env, store, config, user, data, path) {
  requireAccess(env, user.id);
  if (path === "invoice/options" && request.method === "POST") {
    const active = await store.first(`
      SELECT * FROM invoices WHERE user_id = ? AND status = 'pending' AND expires_at > ?`, user.id, now());
    const latest = active ?? await store.first(`
      SELECT * FROM invoices WHERE user_id = ? ORDER BY id DESC LIMIT 1`, user.id);
    const account = await store.first("SELECT p2p_balance FROM accounts WHERE user_id = ?", user.id);
    return { balance: account?.p2p_balance ?? 0, minAmount: MIN_AMOUNT, maxAmount: MAX_AMOUNT,
      methods: [...new Set((await availableCards(store, env)).map(card => card.method))],
      active: active ? publicInvoice(env, active, config) : null,
      latest: latest ? publicInvoice(env, latest, config) : null };
  }
  if (path === "invoice" && request.method === "POST") {
    return publicInvoice(env, await createInvoice(store, env, user, data), config);
  }
  const match = /^invoice\/([0-9]{1,16})\/(status|check)$/.exec(path);
  if (!match || (match[2] === "status" ? request.method !== "GET" : request.method !== "POST")) {
    throw new RequestError("endpoint_missing", 404);
  }
  const id = integer(match[1]);
  if (match[2] === "check") {
    await store.stmt(`
      UPDATE invoices SET checked_at = COALESCE(checked_at, ?)
      WHERE id = ? AND user_id = ? AND status IN ('pending', 'expired')`, now(), id, user.id).run();
  }
  const row = await ownedInvoice(store, id, user.id);
  if (!row) throw new RequestError("payment_not_found", 404);
  const account = await store.first("SELECT p2p_balance FROM accounts WHERE user_id = ?", user.id);
  return { ...publicInvoice(env, row, config), balance: account?.p2p_balance ?? 0 };
}

export function authorizeRelay(request, env, method) {
  if (env.P2P_MODE !== "private" || request.method !== "POST" || !/^(humo|uzcard|cardxabar)$/.test(method)) {
    throw new RequestError("endpoint_missing", 404);
  }
  const key = env["P2P_" + method.toUpperCase() + "_SECRET"];
  const supplied = request.headers.get("Authorization")?.replace(/^Bearer /, "");
  if (!validSecret(key) || !matchesSecret(supplied, key)) throw new RequestError("forbidden", 403);
}

export async function inspectBankChat(env, admin, message) {
  const { business_connection_id: id, chat, from, document, text, forward_origin } = message;
  if (!admin || typeof id !== "string" || !id || chat?.type !== "private" ||
      from?.is_bot !== true || !telegramId(from.id) || from.id !== chat.id || forward_origin) return;
  const source = BANK_CHATS.get(username(from.username).toLowerCase());
  if (!source) return;

  const connection = await telegram(env, "getBusinessConnection", { business_connection_id: id }).catch(error => {
    if (error.telegramCode === 400 || error.telegramCode === 403) return null;
    throw error;
  });
  if (connection?.id !== id || connection.is_enabled !== true || connection.user?.id !== admin) return;

  let result = document?.mime_type === "application/pdf" ? "pdf" : "other";
  if (typeof text === "string") {
    try {
      parseIncoming(text);
      result = "transfer_with_reference";
    } catch (error) {
      if (!(error instanceof RequestError)) throw error;
      result = error.message;
    }
  }
  console.info("ARSLAN BOOST bank chat", source, result);
}

export async function receiveIncoming(store, env, method, data) {
  if (method === "uzcard" && (typeof data.sender !== "string" ||
      !env.P2P_UZCARD_SENDERS?.trim().split(/\s*,\s*/).includes(data.sender))) {
    throw new RequestError("p2p_sender_invalid", 403);
  }
  const notice = parseIncoming(data.text);
  const notifiedMethod = method === "cardxabar" ? "uzcard" : method;
  const matchingCards = cards(env).filter(item => item.method === notifiedMethod &&
    item.number.endsWith(notice.last4));
  if (matchingCards.length !== 1) throw new RequestError("p2p_card_unknown");
  const [card] = matchingCards;
  const eventId = data.eventId ?? `ref:${card.id}:${notice.bankRef}`;
  if (typeof eventId !== "string" || !EVENT_ID.test(eventId)) throw new RequestError("p2p_event_invalid");
  const received = now();
  if (notice.occurredAt > received + 30 || notice.occurredAt < received - HOLD_SECONDS) {
    throw new RequestError("p2p_event_time_invalid");
  }
  const minimum = notice.occurredAt;
  const maximum = minimum + notice.precision - 1;
  const recorded = await store.first(`
    INSERT INTO p2p_incoming (card_id, source, source_event_id, bank_ref, amount, occurred_at, received_at, invoice_id)
    SELECT ?, ?, ?, ?, ?, ?, ?,
      (SELECT CASE WHEN COUNT(*) = 1 THEN MIN(id) END FROM invoices
       WHERE card_id = ? AND unique_amount = ? AND created_at <= ? AND expires_at > ?
         AND ((status = 'pending' AND expires_at > ?) OR status = 'manual_check')
         AND NOT EXISTS (SELECT 1 FROM invoices paid WHERE paid.card_id = ? AND paid.paid_ref = ?))
    ON CONFLICT DO NOTHING RETURNING invoice_id`,
    card.id, method, eventId, notice.bankRef, notice.amount, minimum, received, card.id, notice.amount,
    minimum, maximum, received, card.id, notice.bankRef);
  return { matched: Boolean(recorded?.invoice_id), invoiceId: recorded?.invoice_id ?? null,
    duplicate: !recorded };
}

export async function sendP2pNotice(store, env, id) {
  const time = now();
  const claim = await store.first(`
    UPDATE p2p_notices SET lease_until = ? WHERE invoice_id = ? AND lease_until <= ?
    RETURNING lease_until`, time + 60, id, time);
  if (!claim) return;
  const row = await store.first("SELECT * FROM invoices WHERE id = ?", id);
  const label = row.lang === "ru" ? "✅ Пополнение подтверждено" : "✅ To‘lov tasdiqlandi";
  await telegram(env, "sendMessage", {
    chat_id: row.user_id, text: `${label} · #${id}\n+${formatAmount(row.base_amount)} UZS`,
  }).catch(error => { if (error.telegramCode !== 403) throw error; });
  await store.stmt("DELETE FROM p2p_notices WHERE invoice_id = ? AND lease_until = ?", id, claim.lease_until).run();
}

const BUYER_RECEIPT = /^P2P #(\d+)(?:\n|$)/;

function receiptChat(env, config) {
  const chat = Number(env.P2P_REVIEW_CHAT_ID);
  return Number.isSafeInteger(chat) && chat !== 0 ? chat : config.admin;
}

export async function p2pReceipt(env, store, config, message) {
  const reply = message.reply_to_message;
  const match = reply?.from?.is_bot && reply.from.id === Number(env.BOT_TOKEN?.split(":")[0]) &&
    BUYER_RECEIPT.exec(reply.text || "");
  const file = message.photo?.at(-1) ??
    (["application/pdf", "image/jpeg", "image/png", "image/webp"].includes(message.document?.mime_type)
      && message.document);
  if (!match || !file || !p2pAccess(env, message.from?.id)) return false;
  const id = integer(match[1]);
  let saved = await store.first("SELECT * FROM invoices WHERE id = ? AND user_id = ?", id, message.from.id);
  if (!saved) return true;
  if (["pending", "expired"].includes(saved.status)) {
    const time = now();
    const result = await store.first(`
      UPDATE invoices SET status = 'manual_check', receipt_file_id = ?, receipt_unique_id = ?,
          receipt_chat_id = ?, receipt_message_id = ?
      WHERE id = ? AND user_id = ? AND status IN ('pending', 'expired') AND checked_at IS NOT NULL
        AND (checked_at <= ? OR expires_at <= ?)
        AND NOT EXISTS (SELECT 1 FROM invoices WHERE receipt_unique_id = ?)
      RETURNING *`, file.file_id, file.file_unique_id, message.chat.id, message.message_id,
      id, message.from.id, time - 60, time, file.file_unique_id);
    if (!result) return true;
    saved = result;
  }
  if (saved.status !== "manual_check" || saved.receipt_message_id !== message.message_id ||
      saved.review_message_id) return true;
  const forwarded = await telegram(env, "copyMessage", {
    chat_id: receiptChat(env, config), from_chat_id: message.chat.id, message_id: message.message_id,
    caption: `P2P чек #${id}\n${saved.payment_method.toUpperCase()} ••••${saved.card_number}\n`
      + `К зачислению ${formatAmount(saved.base_amount)} UZS. Сверьте операцию с выпиской.\n`
      + `/p2p_confirm ${id} RRN СУММА`,
    reply_markup: { inline_keyboard: [[
      { text: "Подтвердить", callback_data: `p2p_yes:${id}` },
      { text: "Отклонить", callback_data: `p2p_no:${id}` },
    ]] },
  });
  if (Number.isSafeInteger(forwarded?.message_id)) {
    await store.stmt("UPDATE invoices SET review_message_id = ? WHERE id = ? AND review_message_id IS NULL",
      forwarded.message_id, id).run();
  }
  await telegram(env, "sendMessage", { chat_id: message.chat.id,
    text: saved.lang === "ru" ? "Чек отправлен на проверку." : "Chek tekshiruvga yuborildi." }).catch(() => {});
  return true;
}

export async function p2pCommand(env, store, config, message, command, args) {
  const admin = Boolean(config.admin && message.from.id === config.admin);
  const say = text => telegram(env, "sendMessage", { chat_id: message.chat.id, text });
  if (command === "/start" && /^p2p_[0-9]+$/.test(args[0] || "")) {
    if (!p2pAccess(env, message.from.id)) return true;
    const row = await ownedInvoice(store, integer(args[0].slice(4)), message.from.id);
    if (!row || !publicInvoice(env, row, config).receiptLink) return true;
    await telegram(env, "sendMessage", {
      chat_id: message.chat.id,
      text: `P2P #${row.id}\n` + (row.lang === "ru" ? "Ответьте на это сообщение фото или PDF."
        : "Ushbu xabarga rasm yoki PDF bilan javob bering."),
      reply_markup: { force_reply: true, selective: true },
    });
    return true;
  }
  if (command !== "/p2p_card" && command !== "/p2p_confirm") return false;
  if (!admin || env.P2P_MODE !== "private") return true;
  if (command === "/p2p_card") {
    const [action, id] = args;
    if (action === "list") {
      const active = new Set((await availableCards(store, env)).map(card => card.id));
      await say(cards(env).map(card => `${card.id} · ${card.method.toUpperCase()} ••••${card.number.slice(-4)} · ${active.has(card.id) ? "on" : "off"}`).join("\n") || "Карты пока не добавлены.");
      return true;
    }
    if (!["on", "off"].includes(action) || !cards(env).some(card => card.id === id)) {
      await say("/p2p_card list\n/p2p_card on ID\n/p2p_card off ID");
      return true;
    }
    await store.stmt(`INSERT INTO p2p_card_flags VALUES (?, ?)
      ON CONFLICT (card_id) DO UPDATE SET enabled = excluded.enabled`, id, Number(action === "on")).run();
    await say(`Карта ${id} · ${action}`);
    return true;
  }
  let id, ref, amount;
  try {
    if (args.length < 3) throw new RequestError("p2p_reference_required");
    id = integer(args[0]);
    ref = reference(args[1]);
    amount = parseAmount(args.slice(2).join(" "));
  } catch (error) {
    if (!(error instanceof RequestError)) throw error;
    await say("/p2p_confirm ID RRN ФАКТИЧЕСКАЯ_СУММА");
    return true;
  }
  const row = await store.first(`
    UPDATE invoices AS target SET status = 'paid', paid_at = ?, paid_ref = ?, received_amount = ?, review_user_id = ?
    WHERE id = ? AND status = 'manual_check' AND base_amount <= ?
    AND NOT EXISTS (SELECT 1 FROM invoices existing WHERE existing.card_id = target.card_id AND existing.paid_ref = ?)
    AND NOT EXISTS (SELECT 1 FROM p2p_incoming event WHERE event.card_id = target.card_id AND event.bank_ref = ?
      AND (event.amount <> ? OR event.occurred_at < target.created_at OR event.invoice_id IS NOT NULL))
    RETURNING id`, now(), ref, amount, message.from.id, id, amount, ref, ref, amount);
  await say(row ? `Заявка #${id} подтверждена.` : "Зачисление отклонено. Проверьте статус, сумму и номер операции.");
  if (row) await sendP2pNotice(store, env, id).catch(() => {});
  return true;
}

export async function p2pCallback(env, store, config, query) {
  const match = /^p2p_(yes|no):([0-9]+)$/.exec(query.data || "");
  if (!match) return false;
  const admin = Boolean(config.admin && query.from?.id === config.admin && env.P2P_MODE === "private");
  let text = "Нет доступа";
  if (admin) {
    const id = integer(match[2]);
    if (match[1] === "yes") {
      text = `Сверьте выписку и отправьте /p2p_confirm ${id} RRN СУММА`;
    } else {
      const changed = await store.first(`
        UPDATE invoices SET status = 'rejected', review_user_id = ?
        WHERE id = ? AND status = 'manual_check' RETURNING id`, query.from.id, id);
      text = changed ? "Заявка отклонена" : "Заявка уже обработана";
    }
  }
  await telegram(env, "answerCallbackQuery", { callback_query_id: query.id, text, show_alert: true });
  return true;
}

export async function p2pCron(store, env) {
  await expireInvoices(store);
  const queue = await store.all("SELECT invoice_id FROM p2p_notices WHERE lease_until <= ? ORDER BY lease_until LIMIT 6", now());
  await Promise.allSettled(queue.map(row => sendP2pNotice(store, env, row.invoice_id)));
}

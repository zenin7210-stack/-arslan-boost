(function () {
  'use strict';
  const strings = {
    ru: {
      wallet: 'Пополнение картой', balance: 'Баланс переводов', amount: 'Сумма пополнения',
      method: 'Способ оплаты', next: 'Продолжить', back: 'Назад', copied: 'Скопировано',
      copy: 'Копировать', selectCopy: 'Выделите и скопируйте текст', exact: 'Точная сумма перевода',
      expires: 'Время для перевода', rules1: 'Не меняйте сумму ни на 1 сум.',
      rules2: 'Оплатите в течение 10 минут.', transfer: 'Я оплатил', checking: 'Проверяем платёж',
      checkingNote: 'Перевод ищется по сумме, карте и данным операции.',
      paid: 'Баланс пополнен', manual: 'Чек на проверке', expired: 'Время перевода истекло',
      rejected: 'Заявка отклонена', absent: 'Платёж пока не найден',
      receipt: 'Загрузить чек', retry: 'Обновить статус', new: 'К сумме и способу оплаты',
      help: 'Сумма, которую зачислим', unavailable: 'Способ временно недоступен.',
      error: 'Не удалось обновить данные. Попробуйте ещё раз.',
      amountUnavailable: 'Свободные суммы заняты. Попробуйте другую сумму.',
      noCard: 'Реквизиты изменились. Если вы уже перевели деньги, откройте проверку.',
      history: 'Последняя заявка',
    },
    uz: {
      wallet: 'Karta orqali to‘ldirish', balance: 'O‘tkazmalar balansi', amount: 'To‘ldirish summasi',
      method: 'To‘lov usuli', next: 'Davom etish', back: 'Orqaga', copied: 'Nusxalandi',
      copy: 'Nusxalash', selectCopy: 'Matnni belgilab nusxalang', exact: 'O‘tkaziladigan aniq summa',
      expires: 'O‘tkazma uchun vaqt', rules1: 'Summani 1 so‘mga ham o‘zgartirmang.',
      rules2: '10 daqiqa ichida to‘lang.', transfer: 'To‘ladim', checking: 'To‘lov tekshirilmoqda',
      checkingNote: 'Summa, karta va operatsiya ma’lumotlari tekshirilmoqda.',
      paid: 'Balans to‘ldirildi', manual: 'Chek tekshirilmoqda', expired: 'O‘tkazma vaqti tugadi',
      rejected: 'Ariza rad etildi', absent: 'To‘lov hozircha topilmadi',
      receipt: 'Chek yuklash', retry: 'Holatni yangilash', new: 'Summa va usulga qaytish',
      help: 'Balansga tushadigan summa', unavailable: 'Usul vaqtincha mavjud emas.',
      error: 'Ma’lumot yangilanmadi. Qayta urinib ko‘ring.',
      amountUnavailable: 'Bo‘sh summalar band. Boshqa summani tanlang.',
      noCard: 'Rekvizitlar o‘zgargan. Pul yuborgan bo‘lsangiz, tekshiruvni oching.',
      history: 'So‘nggi ariza',
    },
  };

  window.ArsLanP2P = function (ui) {
    let options, invoice, method = '', amount = '50000', key;
    let deadline = 0, tick, polling, generation = 0;
    const t = name => strings[ui.lang()][name];
    const e = ui.escape;
    const within = selector => ui.body.querySelector(selector);
    const money = value => ui.money(value) + (ui.lang() === 'ru' ? ' сум' : ' so‘m');

    function stop() {
      generation++;
      clearInterval(tick);
      clearTimeout(polling);
    }

    function show(html, title = t('wallet')) {
      ui.show('<div class="p2p-stack">' + html + '</div>', title);
      return generation;
    }

    function active(version) {
      return generation === version && ui.active();
    }

    function warning(error) {
      const text = {
        p2p_method_unavailable: 'unavailable', p2p_amount_unavailable: 'amountUnavailable',
        p2p_disabled: 'unavailable',
      }[error?.message] || 'error';
      const target = within('.p2p-feedback');
      if (target) target.textContent = t(text);
      else ui.toast(t(text));
    }

    function copy(button, text) {
      button.onclick = async () => {
        try {
          await navigator.clipboard.writeText(text);
          ui.toast(t('copied'));
        } catch {
          let field = within('.p2p-copy-field');
          if (!field) {
            field = document.createElement('input');
            field.className = 'p2p-copy-field';
            field.readOnly = true;
            field.setAttribute('aria-label', t('copy'));
            button.closest('.p2p-stack').append(field);
          }
          field.value = text;
          field.focus();
          field.select();
          ui.toast(t('selectCopy'));
        }
      };
    }

    function validAmount() {
      return /^[0-9]{1,9}$/.test(amount) && Number(amount) >= options.minAmount &&
        Number(amount) <= options.maxAmount;
    }

    function renderForm() {
      const version = show(`
        <div class="p2p-amount"><div><span>${e(t('balance'))}</span><strong>${e(money(options.balance))}</strong></div></div>
        <div><label for="p2p-value">${e(t('amount'))}</label>
        <div data-keyboard-inline><input id="p2p-value" inputmode="numeric" enterkeyhint="done"
          maxlength="9" autocomplete="off" value="${e(amount)}"></div></div>
        <div class="p2p-presets">${[10000, 50000, 100000].map(n =>
          `<button class="p2p-chip" type="button" data-p2p-amount="${n}">${e(ui.money(n))}</button>`).join('')}</div>
        <fieldset><legend>${e(t('method'))}</legend><div class="p2p-methods">
          ${options.methods.map(id => `<button class="p2p-method" type="button" data-p2p-method="${e(id)}">
            <img src="assets/${e(id)}.svg" alt="">${e(id.toUpperCase())}</button>`).join('')}
        </div>${options.methods.length ? '' : `<p class="p2p-muted">${e(t('unavailable'))}</p>`}</fieldset>
        <p class="p2p-feedback" role="status"></p>
        <button class="p2p-action" type="button" id="p2p-next">${e(t('next'))}</button>
        ${options.latest && !options.active ? `<button class="secondary" type="button" id="p2p-latest">${e(t('history'))} #${options.latest.id}</button>` : ''}
        <button class="secondary" type="button" id="p2p-back">${e(t('back'))}</button>`);
      const field = within('#p2p-value'), next = within('#p2p-next');
      const update = () => {
        next.disabled = !validAmount() || !method;
        ui.body.querySelectorAll('[data-p2p-amount]').forEach(button =>
          button.setAttribute('aria-pressed', String(button.dataset.p2pAmount === amount)));
        ui.body.querySelectorAll('[data-p2p-method]').forEach(button =>
          button.setAttribute('aria-pressed', String(button.dataset.p2pMethod === method)));
      };
      const change = value => {
        if (value !== amount) key = null;
        amount = value;
        update();
      };
      field.oninput = () => change(field.value);
      ui.body.querySelectorAll('[data-p2p-amount]').forEach(button => button.onclick = () => {
        ui.dismissKeyboard();
        field.value = button.dataset.p2pAmount;
        change(field.value);
      });
      ui.body.querySelectorAll('[data-p2p-method]').forEach(button => button.onclick = () => {
        if (method !== button.dataset.p2pMethod) key = null;
        method = button.dataset.p2pMethod;
        ui.dismissKeyboard();
        update();
      });
      next.onclick = async () => {
        if (next.disabled) return;
        next.disabled = true;
        const controls = [...ui.body.querySelectorAll('input, [data-p2p-amount], [data-p2p-method]')];
        controls.forEach(control => { control.disabled = true; });
        ui.dismissKeyboard();
        key ||= ui.requestKey();
        try {
          const result = await ui.api('invoice', { amount, method, requestId: key, lang: ui.lang() });
          if (!active(version)) return;
          invoice = result;
          deadline = 0;
          renderInvoice();
        } catch (error) {
          if (active(version)) {
            controls.forEach(control => { control.disabled = false; });
            update();
            warning(error);
          }
        }
      };
      within('#p2p-back').onclick = ui.back;
      const latest = within('#p2p-latest');
      if (latest) latest.onclick = () => {
        invoice = options.latest;
        deadline = 0;
        renderInvoice();
      };
      update();
    }

    function remainingClock(seconds) {
      return Math.floor(seconds / 60) + ':' + String(seconds % 60).padStart(2, '0');
    }

    function renderInvoice() {
      if (invoice.status !== 'pending' || invoice.checkedAt) return renderCheck();
      const card = invoice.cardNumber;
      const version = show(`
        <div class="p2p-amount"><div><span>${e(t('exact'))}</span><strong>${e(money(invoice.uniqueAmount))}</strong></div>
          <button type="button" class="p2p-copy" id="p2p-copy-sum">${e(t('copy'))}</button></div>
        <p class="p2p-muted">${e(t('help'))} · ${e(money(invoice.baseAmount))}</p>
        ${card ? `<div class="p2p-card"><div><strong>${e(card.replace(/(.{4})(?=.)/g, '$1 '))}</strong><span>${e(invoice.cardHolder)}</span></div>
          <button type="button" class="p2p-copy" id="p2p-copy-card">${e(t('copy'))}</button></div>` :
          `<p class="p2p-muted">${e(t('noCard'))}</p>`}
        <ul class="p2p-rules"><li>${e(t('rules1'))}</li><li>${e(t('rules2'))}</li></ul>
        <div class="p2p-progress"><div><span>${e(t('expires'))}</span><time id="p2p-clock">10:00</time></div>
          <progress id="p2p-progress" max="600" value="600" aria-label="${e(t('expires'))}"></progress></div>
        <p class="p2p-feedback" role="status"></p>
        <button type="button" class="p2p-action" id="p2p-paid">${e(t('transfer'))}</button>`,
      invoice.method.toUpperCase());
      copy(within('#p2p-copy-sum'), String(invoice.uniqueAmount));
      if (card) copy(within('#p2p-copy-card'), card);
      within('#p2p-paid').onclick = () => startCheck(version);
      const end = Date.now() + Math.max(0, invoice.expiresAt - invoice.serverTime) * 1000;
      const refreshClock = () => {
        if (!active(version)) return;
        const remaining = Math.max(0, Math.ceil((end - Date.now()) / 1000));
        within('#p2p-clock').textContent = remainingClock(remaining);
        within('#p2p-progress').value = remaining;
        if (!remaining) {
          clearInterval(tick);
          const cardCopy = within('#p2p-copy-card');
          cardCopy?.closest('.p2p-card').remove();
          const sumCopy = within('#p2p-copy-sum');
          if (sumCopy) sumCopy.disabled = true;
          within('.p2p-copy-field')?.remove();
          within('.p2p-feedback').textContent = t('expired');
        }
      };
      tick = setInterval(refreshClock, 500);
      refreshClock();
    }

    async function startCheck(version) {
      const button = within('#p2p-paid') || within('#p2p-retry');
      if (button) button.disabled = true;
      try {
        const result = await ui.api(`invoice/${invoice.id}/check`, {});
        if (!active(version)) return;
        invoice = result;
        deadline = 0;
        renderCheck();
      } catch (error) {
        if (active(version)) {
          if (button) button.disabled = false;
          warning(error);
        }
      }
    }

    function renderCheck() {
      if (!deadline && invoice.checkedAt) {
        deadline = Date.now() + Math.max(0, invoice.checkedAt + 60 - invoice.serverTime) * 1000;
      }
      const running = invoice.status === 'pending' && deadline > Date.now();
      const heading = invoice.status === 'paid' ? 'paid' : invoice.status === 'manual_check' ? 'manual'
        : invoice.status === 'rejected' ? 'rejected' : invoice.status === 'expired' ? 'expired'
          : running ? 'checking' : 'absent';
      const version = show(`
        <div class="p2p-check">${running ? '<div class="p2p-ring" aria-hidden="true"><time>60</time></div>' : ''}
          <h3>${e(t(heading))}</h3>
          <p class="p2p-muted">${e(invoice.status === 'paid'
            ? money(invoice.balance ?? options.balance) : running ? t('checkingNote') : '#' + invoice.id)}</p>
        </div>
        <p class="p2p-feedback" role="status"></p>
        ${invoice.receiptLink ? `<button type="button" class="p2p-action" id="p2p-receipt">${e(t('receipt'))}</button>` : ''}
        ${['pending','expired','manual_check'].includes(invoice.status) && !running ?
          `<button type="button" class="secondary" id="p2p-retry">${e(t('retry'))}</button>` : ''}
        <button type="button" class="secondary" id="p2p-return">${e(invoice.status === 'pending' ? t('back') : t('new'))}</button>`,
      invoice.method.toUpperCase());
      const upload = within('#p2p-receipt');
      if (upload) upload.onclick = () => ui.openTelegram(invoice.receiptLink);
      const retry = within('#p2p-retry');
      if (retry) retry.onclick = () => invoice.checkedAt ? refresh(version) : startCheck(version);
      within('#p2p-return').onclick = invoice.status === 'pending' ? ui.back : open;
      if (running) {
        const ring = within('.p2p-ring');
        const draw = () => {
          const seconds = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
          ring.style.setProperty('--angle', seconds * 6 + 'deg');
          ring.querySelector('time').textContent = String(seconds);
        };
        tick = setInterval(draw, 250);
        draw();
        polling = setTimeout(() => refresh(version), Math.min(3000, Math.max(0, deadline - Date.now())));
      }
    }

    async function refresh(version) {
      try {
        const result = await ui.api(`invoice/${invoice.id}/status`, null, 'GET');
        if (!active(version)) return;
        const unchanged = invoice.status === result.status && invoice.receiptLink === result.receiptLink;
        invoice = result;
        if (invoice.status === 'paid') options.balance = invoice.balance;
        if (unchanged && invoice.status === 'pending' && deadline > Date.now()) {
          polling = setTimeout(() => refresh(version), Math.min(3000, deadline - Date.now()));
        } else {
          renderCheck();
        }
      } catch (error) {
        if (!active(version)) return;
        if (invoice.status === 'pending' && deadline > Date.now()) {
          polling = setTimeout(() => refresh(version), Math.min(3000, deadline - Date.now()));
        } else {
          renderCheck();
        }
        warning(error);
      }
    }

    async function open() {
      const version = show(`<p class="p2p-feedback" role="status"></p>
        <button type="button" class="secondary" id="p2p-load-back">${e(t('back'))}</button>`);
      within('#p2p-load-back').onclick = ui.back;
      try {
        options = await ui.api('invoice/options', {});
        if (!active(version)) return;
        invoice = options.active;
        deadline = 0;
        method = options.methods.includes(method) ? method : options.methods[0] || '';
        if (invoice && !invoice.checkedAt) renderInvoice();
        else if (invoice) renderCheck();
        else {
          key = null;
          renderForm();
        }
      } catch (error) {
        if (active(version)) warning(error);
      }
    }

    return { open, stop };
  };
})();

'use strict';

window.initArslanShop = function ({
  config, lang, api, connected, openSheet, closeSheet, sheetBody, openTopup, walletBalance, syncState,
  starsOrderChoice, bindStarsOrder,
  transferOrderChoices, bindTransferOrder,
  openTelegram, telegramUrl, toast, escape, money, glyph, showHistory
}) {
  const translations = {
    uz: {
      sub: 'O‘yin valyutalari va xizmatlar', search: 'Qidirish…', clear: 'Qidiruvni tozalash',
      all: 'Hammasi', games: 'O‘yinlar', services: 'Servislar', filters: 'Do‘kon filtrlari',
      other: 'Boshqa o‘yinlar', showAll: 'Barchasi', noResults: 'Mahsulot topilmadi',
      loading: 'Mahsulotlar yuklanmoqda…', loadError: 'Katalogni yuklab bo‘lmadi', retry: 'Qayta urinish',
      quantity: 'Nechta Gold kerak?', starsQuantity: 'Nechta Stars kerak?', select: 'Paketni tanlang', game: 'O‘yin ID',
      addPack: 'Paket qo‘shish', removePack: 'Bitta paketni olib tashlash',
      username: 'Username', optional: 'Nick yoki izoh (ixtiyoriy)', example: 'Masalan, 12345678',
      price: 'Jami', next: 'Davom etish', back: 'Orqaga', pay: 'To‘lov usuli',
      confirm: 'Buyurtma berish', copy: 'Xabarni nusxalash', contact: 'Administratorga yozish',
      receipt: 'Chekni botga yuborish', manual: 'Rekvizitlarni administratordan oling. To‘lovdan keyin chek yuboring.',
      market: 'Skinni qo‘yishdan oldin narxni admin bilan kelishing. Skinni aynan shu narxda qo‘ying.',
      created: 'Buyurtma yaratildi', draft: 'Buyurtma matni tayyor', sendBot: 'Botga yuborish',
      draftHint: 'Buyurtmani rasmiylashtirish uchun xabarni administratorga yuboring.',
      delivery: 'Admin to‘lovni tekshiradi va buyurtmani bajaradi.',
      error: 'Serverga ulanib bo‘lmadi. Qayta urinib ko‘ring.', copied: 'Nusxalandi',
      copyHint: 'Matnni belgilang va nusxalang', done: 'Tayyor', terminal: 'Bankomat',
      partners: 'Hamkorlar', partner: 'Hamkorlik dasturi', apply: 'Ariza yuborish',
      waiting: 'Arizangiz ko‘rib chiqilmoqda', rejected: 'Ariza rad etildi. Qayta yuborishingiz mumkin.',
      disabled: 'Hamkorlik vaqtincha to‘xtatilgan', clients: 'Mijozlar', available: 'Yechib olish mumkin',
      pending: '24 soat kutmoqda', link: 'Sizning taklif havolangiz', copyLink: 'Havolani nusxalash',
      withdrawal: 'Pul yechish', withdrawalAmount: 'Yechish summasi (kamida 10 000 so‘m)',
      withdrawalDetails: 'Karta yoki telefon raqami', withdrawalSent: 'So‘rov yuborildi',
      insufficient: 'Mablag‘ yetarli emas', invalid: 'Ma’lumotlarni tekshiring', commissions: 'Hisoblangan komissiyalar',
      intro: 'Taklif qilgan mijozlaringizning bajarilgan buyurtmalaridan sof foydaning 50% ini olasiz.',
      minimum: 'Yechish 10 000 so‘mdan', delay: '24 soatdan keyin', openBot: 'Telegram botini ochish',
      waitingCommission: 'Kutilmoqda', availableCommission: 'Hisoblandi', reversedCommission: 'Bekor qilindi',
      balance: 'Mavjud balans', topup: 'Hamyonni to‘ldirish',
      payBalance: 'Balansdan to‘lash', paid: 'To‘langan buyurtma adminga yuborildi', walletShort: 'Balansda mablag‘ yetarli emas',
      quoteChanged: 'Narx yangilandi. Buyurtmani qayta oching.',
      buy: 'Sotib olish', verify: 'Tekshirish', formatValid: 'Format to‘g‘ri.',
      formatInvalid: 'Kiritilgan ma’lumot formatini tekshiring.', chooseProduct: 'Mahsulotni tanlang',
      fastUc: 'UC tezkor', bundles: 'To‘plamlar', global: 'Global', login: 'Akkauntga kirib',
      gems: 'Gems', brawlPass: 'Brawl Pass',
      customStars: 'Ixtiyoriy miqdor', starsPrice: 'Narx', from: 'Kamida', to: 'Ko‘pi bilan'
    },
    ru: {
      sub: 'Игровая валюта и услуги', search: 'Поиск…', clear: 'Очистить поиск',
      all: 'Все', games: 'Игры', services: 'Услуги', filters: 'Фильтры магазина',
      other: 'Другие игры', showAll: 'Все игры', noResults: 'Ничего не найдено',
      loading: 'Загружаем товары…', loadError: 'Не удалось загрузить каталог', retry: 'Повторить',
      quantity: 'Сколько нужно Gold?', starsQuantity: 'Сколько нужно Stars?', select: 'Выберите пакет', game: 'Игровой ID',
      addPack: 'Добавить пакет', removePack: 'Убрать один пакет',
      username: 'Имя пользователя', optional: 'Ник или комментарий (необязательно)', example: 'Например, 12345678',
      price: 'Итого', next: 'Продолжить', back: 'Назад', pay: 'Способ оплаты',
      confirm: 'Оформить заказ', copy: 'Скопировать сообщение', contact: 'Написать администратору',
      receipt: 'Отправить чек боту', manual: 'Реквизиты уточните у администратора. После оплаты отправьте чек.',
      market: 'Согласуйте цену скина с администратором и выставьте его ровно по этой цене.',
      created: 'Заказ создан', draft: 'Текст заказа готов', sendBot: 'Отправить боту',
      draftHint: 'Отправьте сообщение администратору, чтобы оформить заказ.',
      delivery: 'Администратор проверит оплату и выполнит заказ.',
      error: 'Не удалось связаться с ботом. Попробуйте ещё раз.', copied: 'Скопировано',
      copyHint: 'Выделите и скопируйте текст', done: 'Готово', terminal: 'Банкомат',
      partners: 'Партнёрам', partner: 'Партнёрская программа', apply: 'Подать заявку',
      waiting: 'Заявка на рассмотрении', rejected: 'Заявка отклонена. Её можно подать снова.',
      disabled: 'Партнёрство приостановлено', clients: 'Клиенты', available: 'Доступно к выводу',
      pending: 'Ожидает 24 часа', link: 'Ваша реферальная ссылка', copyLink: 'Скопировать ссылку',
      withdrawal: 'Вывод средств', withdrawalAmount: 'Сумма вывода (от 10 000 сум)',
      withdrawalDetails: 'Номер карты или телефона', withdrawalSent: 'Заявка отправлена',
      insufficient: 'Недостаточно средств', invalid: 'Проверьте введённые данные', commissions: 'История начислений',
      intro: 'Получайте 50% чистой прибыли с выполненных заказов клиентов, которых вы пригласили.',
      minimum: 'Вывод от 10 000 сум', delay: 'Начисление через 24 часа', openBot: 'Открыть Telegram-бота',
      waitingCommission: 'Ожидает', availableCommission: 'Начислено', reversedCommission: 'Отменено',
      balance: 'Доступный баланс', topup: 'Пополнить баланс',
      payBalance: 'Оплатить с баланса', paid: 'Оплаченный заказ передан администратору', walletShort: 'На балансе недостаточно средств',
      quoteChanged: 'Цена обновилась. Откройте заказ заново.',
      buy: 'Купить', verify: 'Проверить', formatValid: 'Формат верный.',
      formatInvalid: 'Проверьте формат введённых данных.', chooseProduct: 'Выберите товар',
      fastUc: 'Быстрые UC', bundles: 'Наборы', global: 'Global', login: 'Со входом в аккаунт',
      gems: 'Гемы', brawlPass: 'Brawl Pass',
      customStars: 'Своё количество', starsPrice: 'Цена', from: 'Минимум', to: 'Максимум'
    }
  };
  const translatedSubtitles = {
    gold_rinok: 'Gold через рынок',
    gold_id: 'Gold по игровому ID',
    spin_coins: 'Валюта для Spin',
    telegram_premium: '1 / 3 / 6 / 12 мес.'
  };
  const cardStyles = {
    gold_rinok: 'gold', gold_id: 'id', gold_pass: 'pass', spin_coins: 'coins'
  };
  const goldTitles = { gold_rinok: 'Gold через рынок', gold_id: 'Gold по ID' };
  const gameOrder = new Map(['pubg_mobile', 'roblox', 'mobile_legends', 'brawl_stars']
    .map((id, index) => [id, index]));
  const storefrontArt = new Set([...Object.keys(cardStyles), 'telegram_premium', 'telegram_stars', ...gameOrder.keys()]);
  const widgetCovers = {
    pubg_mobile: 'pubg', telegram_premium: 'premium', telegram_stars: 'stars', brawl_stars: 'brawl'
  };
  const widgetIds = new Set(Object.keys(widgetCovers));
  const quickUc = ['60', '325', '660', '1800', '3850', '8100'];
  const premiumGifts = ['3', '6', '12gift'];
  const brawlPasses = ['pass', 'passplus', 'propass'];
  const brawlPacks = ['30', '80', '170', '360', '950', '2000', ...brawlPasses];

  const shopPage = document.querySelector('#donat');
  const content = document.querySelector('#shop-content');
  const search = document.querySelector('#shop-search');
  const clear = document.querySelector('#clear-search');
  const filters = [...document.querySelectorAll('#shop-filters button')];
  const state = { items: [], loading: false, failed: false, category: 'all' };

  const t = key => translations[lang()][key];
  const amount = value => money(value) + ' UZS';
  const optionLabel = value => lang() === 'ru'
    ? value.replace(' oy', ' мес.').replace('(kirishsiz)', '(подарок)')
    : value;
  const subtitle = item => (lang() === 'ru' && translatedSubtitles[item.id]) || item.subtitle;
  const cover = item => storefrontArt.has(item.id) ? `assets/donat/catalog/${item.id}.webp` : item.image;
  const botLink = start => {
    const link = telegramUrl(config.botUrl);
    if (!link) return null;
    link.search = '';
    link.searchParams.set('start', start);
    return link.href;
  };

  function card(item) {
    const cardStyle = cardStyles[item.id] || 'telegram';
    const goldTitle = goldTitles[item.id];
    const price = goldTitle ? item.options[0][2] : null;
    return `
      <button class="product-card ${cardStyle}" data-product="${escape(item.id)}" type="button">
        <img class="card-art" src="${escape(cover(item))}" alt="" width="318" height="201" decoding="async">
        <strong class="card-name">${escape(goldTitle || item.title)}</strong>
        <span class="card-desc">${goldTitle ? '100 Gold' : escape(subtitle(item))}</span>
        ${price === null ? '' : `<span class="card-price">${amount(price)}</span>`}
      </button>`;
  }

  function render() {
    filters.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.category === state.category)));
    if (state.loading) {
      content.innerHTML = `<p class="shop-empty">${t('loading')}</p>`;
      return;
    }
    if (state.failed) {
      content.innerHTML = `<div class="shop-empty">${t('loadError')}<br><button class="show-all" type="button" id="retry-shop">${t('retry')}</button></div>`;
      return;
    }

    const query = search.value.trim().toLowerCase();
    const items = state.items.filter(item => {
      const groupMatches = state.category === 'all' || (state.category === 'games') === (item.group === 'games');
      const title = [item.title, item.subtitle, subtitle(item), goldTitles[item.id]].join(' ').toLowerCase();
      return groupMatches && query.split(/\s+/).every(word => title.includes(word));
    });
    const services = items.filter(item => item.group !== 'games');
    const games = items.filter(item => item.group === 'games')
      .sort((a, b) => (gameOrder.get(a.id) ?? gameOrder.size) - (gameOrder.get(b.id) ?? gameOrder.size));
    if (!items.length) {
      content.innerHTML = `<p class="shop-empty">${t('noResults')}</p>`;
      return;
    }

    const gamesMarkup = games.map(item => `
      <button class="game-card" type="button" data-product="${escape(item.id)}">
        <img class="game-art" src="${escape(cover(item))}" alt="" width="248" height="177" decoding="async">
        <span class="game-name">${escape(item.title)}</span>
      </button>`).join('');
    content.innerHTML = `
      ${services.length ? `<div class="product-grid">${services.map(card).join('')}</div>` : ''}
      ${games.length ? `<h2 class="section-title">${glyph('shop')} ${t('other')}
        ${state.category === 'all' && !query ? `<button type="button" class="show-all" data-category="games">${t('showAll')} →</button>` : ''}
      </h2><div class="game-grid">${gamesMarkup}</div>` : ''}`;
  }

  async function loadCatalog(refresh = false) {
    state.loading = true;
    state.failed = false;
    render();
    try {
      const response = await fetch('assets/donat/catalog.json?v=20261110-uc-packs',refresh?{cache:'reload'}:undefined);
      if (!response.ok) throw new Error('Catalog unavailable');
      const data = await response.json();
      if (!Array.isArray(data.items)) throw new Error('Invalid catalog');
      state.items = data.items;
    } catch {
      state.failed = true;
    } finally {
      state.loading = false;
      render();
    }
  }

  function applyLanguage() {
    document.querySelectorAll('[data-shop-text]').forEach(element => {
      element.textContent = t(element.dataset.shopText);
    });
    search.placeholder = t('search');
    search.setAttribute('aria-label', t('search'));
    clear.setAttribute('aria-label', t('clear'));
    document.querySelector('#shop-filters').setAttribute('aria-label', t('filters'));
    render();
  }

  function quantityValid(order) {
    return Number.isSafeInteger(order.quantity) && order.quantity >= order.item.min && order.quantity <= order.item.max;
  }

  function selectedOption(order) {
    return order.item.options.find(([id]) => id === order.option);
  }

  function total(order) {
    if (order.item.kind !== 'quantity') return selectedOption(order)[2] * order.packs;
    const { options } = order.item;
    const upperIndex = options.findIndex(([id]) => order.quantity <= Number(id));
    const [upperQuantity, , upperAmount] = options[upperIndex];
    if (order.quantity === Number(upperQuantity)) return upperAmount;
    const [lowerQuantity, , lowerAmount] = options[upperIndex - 1];
    // The server uses the same adjacent preset prices and whole-sum rounding.
    const span = Number(upperQuantity) - Number(lowerQuantity);
    const difference = (order.quantity - Number(lowerQuantity)) * (upperAmount - lowerAmount);
    return lowerAmount + Math.ceil(difference / span);
  }

  function packageName(order) {
    if (order.item.kind === 'quantity') return money(order.quantity) + ' ' + order.item.unit;
    const label = optionLabel(selectedOption(order)[1]);
    return order.packs > 1 ? order.packs + ' × ' + label : label;
  }

  function detailValid(order) {
    if (order.item.input === 'game_id') return /^[A-Za-z0-9_#-]{4,40}$/.test(order.detail);
    if (order.item.input === 'username') return /^@?[A-Za-z0-9_.]{3,32}$/.test(order.detail);
    return order.detail.length <= 64 && !/[<>\x00-\x1f]/.test(order.detail);
  }

  function priceSummary(value, units = '', label = t('price')) {
    const detail = units ? `<small id="selected-units">${escape(units)}</small>` : '';
    return `<div class="price-summary"><span>${label}${detail}</span><strong id="selected-price" aria-live="polite">${value === null ? '—' : amount(value)}</strong></div>`;
  }

  function packArt(item, id) {
    let index = -1;
    if (item.id === 'pubg_mobile') index = Math.max(0, quickUc.findLastIndex(tier => Number(tier) <= Number(id)));
    else if (item.id === 'brawl_stars') index = brawlPacks.indexOf(id);
    else if (premiumGifts.includes(id)) index = quickUc.length + premiumGifts.indexOf(id);
    if (index < 0) {
      const image = item.id === 'telegram_premium' ? 'assets/donat/widget-telegram_premium.webp' : item.image;
      return `<img class="widget-pack-art" src="${escape(image)}" alt="">`;
    }
    const x = index % 3 * 50;
    const y = Math.floor(index / 3) * (item.id === 'pubg_mobile' ? 100 : 50);
    return `<span class="widget-pack-art" style="--art-x:${x}%;--art-y:${y}%" aria-hidden="true"></span>`;
  }

  function packageChoices(item, options = item.options, widget = false) {
    return `${widget ? '' : `<label id="package-label">${t('select')}</label>`}
      <div class="variant-list${item.kind === 'quantity' ? ' quantity-options' : ''}" role="group" aria-labelledby="package-label">${options.map(([id, name, price]) => {
        const label = escape(optionLabel(widget ? name.replace(' (kirishsiz)', '') : name));
        const text = `<span>${label}</span><strong>${amount(price)}</strong>`;
        const choice = `<button type="button" class="${item.max_packs ? 'pack-select' : 'variant'}" data-option="${escape(id)}" aria-pressed="false">
          ${widget ? `${packArt(item, id)}<span class="widget-pack-text">${text}</span>` : text}
        </button>`;
        if (!item.max_packs) return choice;
        return `<div class="variant pack-option${widget ? ' widget-pack-option' : ''}" data-pack="${escape(id)}">
          ${choice}
          <div class="pack-controls">
            <button type="button" class="pack-minus" data-pack-step="-1" aria-label="${escape(t('removePack'))}">−</button>
            <span class="pack-count"></span>
            <button type="button" class="pack-plus" data-pack-step="1" aria-label="${escape(t('addPack'))} · ${label}">+</button>
          </div>
        </div>`;
      }).join('')}</div>`;
  }

  function widgetMarkup(order, detailInput, tabs) {
    const { item } = order;
    const stars = item.id === 'telegram_stars';
    const recipientLabel = item.id === 'pubg_mobile' ? 'Player ID' : item.input === 'game_id' ? t('game') : '@username';
    const starsQuantity = Number.isSafeInteger(order.quantity) ? order.quantity : '';
    return `<div class="widget-scroll" data-widget-product="${escape(item.id)}">
      <div class="widget-cover">
        <img src="assets/donat/cover-${widgetCovers[item.id]}.webp" width="960" height="540" alt="${escape(item.title)} · ARSLAN SHOP" decoding="async">
      </div>
      <div class="widget-panel widget-recipient">
        <label for="product-detail">${recipientLabel}</label>
        <div class="widget-field-row">${detailInput}<button id="verify-product-detail" type="button">${t('verify')}</button></div>
        <p id="widget-detail-status" role="status" hidden></p>
      </div>
      ${stars ? `<h3 class="widget-label">${t('customStars')}</h3>
        <div class="widget-panel widget-amount">
          <label for="product-quantity">${t('starsQuantity')}</label>
          <div class="widget-quantity">
            <input id="product-quantity" type="number" inputmode="numeric" min="${item.min}" max="${item.max}" step="1" autocomplete="off" placeholder="0" value="${starsQuantity}">
            <svg class="widget-star" viewBox="0 0 24 24" aria-hidden="true"><path d="m12 2 3.1 6.3 7 .9-5.1 5 1.2 7-6.2-3.3-6.2 3.3 1.2-7-5.1-5 7-.9z"/></svg>
          </div>
          ${priceSummary(null, '', t('starsPrice'))}
          <p class="widget-stars-range"><span>${t('from')} <b>${money(item.min)} ⭐</b></span><span>${t('to')} <b>${money(item.max)} ⭐</b></span></p>
        </div>` : `<h3 class="widget-label" id="package-label">${t('chooseProduct')}</h3>
        <div class="widget-tabs" role="group" aria-labelledby="package-label">${tabs.map(([label], index) =>
          `<button type="button" data-widget-tab="${index}" aria-pressed="${index === order.tab}">${t(label)}</button>`).join('')}</div>
        ${tabs.map(([, options], index) => `<div data-widget-group="${index}"${index === order.tab ? '' : ' hidden'}>${packageChoices(item, options, true)}</div>`).join('')}`}
      </div>
      <div class="widget-footer"><button class="action" type="button" id="product-next" disabled>${t('buy')}</button></div>`;
  }

  function productSheet(order) {
    const item = order.item;
    const widget = widgetIds.has(item.id);
    const pubg = item.id === 'pubg_mobile';
    const isQuantity = item.kind === 'quantity';
    const quantityInput = isQuantity && !widget
      ? `<label for="product-quantity">${t(item.unit === 'Stars' ? 'starsQuantity' : 'quantity')} (${money(item.min)}–${money(item.max)})</label>
        <div class="qty">
          <button type="button" data-qty="-${item.step}" aria-label="−${item.step} ${item.unit}">−</button>
          <input id="product-quantity" type="number" min="${item.min}" max="${item.max}" step="1" inputmode="numeric" value="${order.quantity}">
          <button type="button" data-qty="${item.step}" aria-label="+${item.step} ${item.unit}">+</button>
        </div>`
      : '';
    const selectedUnits = () => money(Number(order.option) * order.packs) + ' ' + item.unit;
    const label = t({ game_id: 'game', username: 'username', optional: 'optional' }[item.input]);
    const example = item.input === 'username' ? (item.id === 'roblox' ? 'Username' : '@username') : t('example');
    const detailInput = `<input id="product-detail" maxlength="64" placeholder="${escape(pubg ? 'Player ID' : example)}" value="${escape(order.detail)}" autocomplete="off"${widget ? ` autocapitalize="none" spellcheck="false"${pubg ? ' inputmode="numeric"' : ''}` : ''}>`;
    let tabs = [];
    if (pubg) tabs = [
      ['fastUc', item.options.filter(([id]) => quickUc.includes(id))],
      ['bundles', item.options.filter(([id]) => !quickUc.includes(id))]
    ];
    if (item.id === 'telegram_premium') tabs = [
      ['global', item.options.filter(([id]) => premiumGifts.includes(id))],
      ['login', item.options.filter(([id]) => !premiumGifts.includes(id))]
    ];
    if (item.id === 'brawl_stars') tabs = [
      ['gems', item.options.filter(([id]) => !brawlPasses.includes(id))],
      ['brawlPass', item.options.filter(([id]) => brawlPasses.includes(id))]
    ];
    order.tab ??= 0;
    openSheet(item.title, widget ? widgetMarkup(order, detailInput, tabs) : `
      <p>${escape(subtitle(item))}</p>${packageChoices(item)}${quantityInput}
      <label for="product-detail">${escape(label)}</label>
      ${detailInput}
      ${priceSummary(total(order), item.max_packs ? selectedUnits() : '')}
      ${item.id === 'gold_rinok' ? `<p class="notice">${t('market')}</p>` : ''}
      <button class="action" type="button" id="product-next">${t('next')} →</button>`, widget);

    const quantity = sheetBody.querySelector('#product-quantity');
    const detail = sheetBody.querySelector('#product-detail');
    const price = sheetBody.querySelector('#selected-price');
    const units = sheetBody.querySelector('#selected-units');
    const next = sheetBody.querySelector('#product-next');
    const options = [...sheetBody.querySelectorAll('[data-option]')];
    const tiles = [...sheetBody.querySelectorAll('[data-pack]')];
    const detailStatus = sheetBody.querySelector('#widget-detail-status');
    const update = () => {
      if (quantity) order.quantity = quantity.valueAsNumber;
      order.detail = detail.value.trim();
      const validSelection = isQuantity ? quantityValid(order) : Boolean(selectedOption(order));
      if (price) price.textContent = validSelection ? amount(total(order)) : '—';
      if (units) units.textContent = selectedUnits();
      next.disabled = !validSelection || !detailValid(order);
      const selected = quantity ? String(order.quantity) : order.option;
      options.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.option === selected)));
      tiles.forEach(tile => {
        const active = tile.dataset.pack === selected;
        tile.classList.toggle('selected', active);
        tile.querySelector('.pack-count').textContent = active ? order.packs : '';
        tile.querySelector('.pack-minus').disabled = order.packs === 1 || (pubg && !active);
        tile.querySelector('.pack-plus').disabled = active && order.packs === item.max_packs;
        if (pubg) {
          const [id, , packPrice] = item.options.find(([id]) => id === tile.dataset.pack);
          const packs = active ? order.packs : 1;
          tile.querySelector('.widget-pack-text span').textContent = money(Number(id) * packs) + ' ' + item.unit;
          tile.querySelector('.widget-pack-text strong').textContent = amount(packPrice * packs);
        }
      });
    };

    quantity?.addEventListener('input', update);
    detail.addEventListener('input', () => {
      if (detailStatus) detailStatus.hidden = true;
      update();
    });
    if (widget) {
      sheetBody.querySelector('#verify-product-detail').onclick = () => {
        detail.blur();
        const valid = detailValid(order);
        detailStatus.textContent = t(valid ? 'formatValid' : 'formatInvalid');
        detailStatus.dataset.valid = String(valid);
        detailStatus.hidden = false;
      };
      const tabButtons = [...sheetBody.querySelectorAll('[data-widget-tab]')];
      const groups = [...sheetBody.querySelectorAll('[data-widget-group]')];
      tabButtons.forEach((button, index) => {
        button.onclick = () => {
          if (order.tab === index) return;
          order.tab = index;
          order.option = '';
          order.packs = 1;
          tabButtons.forEach((tab, i) => tab.setAttribute('aria-pressed', String(i === index)));
          groups.forEach((group, i) => { group.hidden = i !== index; });
          update();
        };
      });
    }
    options.forEach(button => {
      button.onclick = () => {
        const option = button.dataset.option;
        if (quantity) quantity.value = option;
        else if (order.option !== option) {
          order.option = option;
          order.packs = 1;
        }
        update();
      };
    });
    sheetBody.querySelectorAll('[data-pack-step]').forEach(button => {
      button.onclick = () => {
        const option = button.closest('[data-pack]').dataset.pack;
        const step = Number(button.dataset.packStep);
        if (order.option === option) {
          order.packs = Math.max(1, Math.min(item.max_packs, order.packs + step));
        } else {
          order.option = option;
          order.packs = pubg && step === 1 ? Math.min(item.max_packs, 2) : 1;
        }
        update();
      };
    });
    sheetBody.querySelectorAll('[data-qty]').forEach(button => {
      button.onclick = () => {
        const current = quantity.valueAsNumber || item.min;
        quantity.value = Math.max(item.min, Math.min(item.max, current + Number(button.dataset.qty)));
        update();
      };
    });
    next.onclick = () => { if (!next.disabled) paymentSheet(order); };
    update();
  }

  function paymentSheet(order) {
    const balance=walletBalance(), enough=balance>=total(order);
    openSheet(t('pay'),`
      <p><strong>${escape(order.item.title)}</strong> · ${escape(packageName(order))}</p>
      ${priceSummary(total(order))}
      ${starsOrderChoice(total(order))}
      <p>${escape(t('balance'))} · ${amount(balance)}</p>
      ${transferOrderChoices()}
      <button class="action" type="button" id="submit-order" ${!connected()||!enough?'disabled':''}>${escape(t('payBalance'))}</button>
      ${enough?'':`<button class="secondary" type="button" id="donat-topup">${escape(t('topup'))}</button>`}
      <button class="secondary" type="button" id="back-product">← ${t('back')}</button>`);
    const submit=sheetBody.querySelector('#submit-order');
    submit.onclick=()=>submitOrder(order,submit);
    bindStarsOrder('donat/create', () => ({...orderPayload(order, 'stars'), expectedAmount:total(order)}),
      () => paymentSheet(order), () => loadCatalog(true));
    bindTransferOrder('donat/create', method => ({...orderPayload(order, method), expectedAmount:total(order)}),
      () => paymentSheet(order));
    sheetBody.querySelector('#donat-topup')?.addEventListener('click',()=>openTopup(()=>paymentSheet(order)));
    sheetBody.querySelector('#back-product').onclick=()=>productSheet(order);
  }

  function orderPayload(order, paymentMethod = 'balance') {
    const fields = {
      product: order.item.id,
      quantity: order.item.kind === 'quantity' ? order.quantity : undefined,
      option: order.item.kind === 'options' ? order.option : undefined,
      packs: order.item.max_packs ? order.packs : undefined,
      detail: order.detail
    };
    const testTransfer = ['uzcard', 'humo'].includes(paymentMethod) ? paymentMethod : false;
    const key = JSON.stringify({...fields, testTransfer});
    if (!order.requests.has(key)) {
      const bytes = crypto.getRandomValues(new Uint8Array(16));
      order.requests.set(key, Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join(''));
    }
    return { ...fields, paymentMethod, lang: lang(), requestId: order.requests.get(key) };
  }

  async function copy(value) {
    try {
      await navigator.clipboard.writeText(value);
      toast(t('copied'));
    } catch {
      const field = document.createElement('textarea');
      field.value = value;
      field.readOnly = true;
      field.setAttribute('aria-label', t('copy'));
      sheetBody.append(field);
      field.focus();
      field.select();
      toast(t('copyHint'));
    }
  }

  async function submitOrder(order,submit) {
    if(submit.disabled)return;
    submit.disabled=true;
    try {
      await api('donat/create',{...orderPayload(order),expectedAmount:total(order)});
      await syncState();
      if(!submit.isConnected)return;
      showHistory();
      toast(t('paid'));
    } catch(error) {
      if(error.message==='insufficient_balance') {
        await syncState();
        if(submit.isConnected)paymentSheet(order);
        toast(t('walletShort'));
      } else if(error.message==='order_quote_changed'&&submit.isConnected) {
        closeSheet();
        loadCatalog(true);
        toast(t('quoteChanged'));
      } else if(submit.isConnected)toast(t('error'));
    } finally {submit.disabled=false;}
  }

  function partnerStats(data) {
    const statuses = {
      pending: t('waitingCommission'), available: t('availableCommission'), reversed: t('reversedCommission')
    };
    const history = (data.history || []).map(row => `
      <div class="partner-stat">
        <span>${row.kind === 'donat' ? 'Donat Shop' : 'Boost'} #${escape(row.orderId)} · ${escape(statuses[row.status] || row.status)}</span>
        <strong>${amount(row.commission)}</strong>
      </div>`).join('');
    return `
      <div class="partner-stats">
        <div class="partner-stat"><span>${t('clients')}</span><strong>${money(data.clients)}</strong></div>
        <div class="partner-stat"><span>${t('available')}</span><strong>${amount(data.available)}</strong></div>
        <div class="partner-stat"><span>${t('pending')}</span><strong>${amount(data.pending)}</strong></div>
      </div>
      ${data.url ? `<label for="partner-link">${t('link')}</label>
        <input id="partner-link" type="url" value="${escape(data.url)}" readonly>
        <button id="partner-copy" class="action" type="button">${t('copyLink')}</button>` : ''}
      <h3>${t('withdrawal')}</h3>
      <label for="partner-amount">${t('withdrawalAmount')}</label>
      <input id="partner-amount" type="number" min="10000" max="${Number(data.available)}" step="1" inputmode="numeric" placeholder="10000">
      <label for="partner-destination">${t('withdrawalDetails')}</label>
      <input id="partner-destination" maxlength="120" placeholder="+998…" autocomplete="off">
      <button class="secondary" id="partner-withdraw" type="button" ${data.available < 10000 ? 'disabled' : ''}>${t('apply')}</button>
      ${history ? `<h3>${t('commissions')}</h3><div class="partner-stats">${history}</div>` : ''}`;
  }

  async function openPartners() {
    const intro = `<p>${t('intro')}</p><div class="partner-facts">
      <span>50%</span><span>${t('delay')}</span><span>${t('minimum')}</span></div>`;
    const openInBot = () => {
      const link = botLink('partner');
      openSheet(t('partner'), intro + `<button class="action" type="button" id="partner-openbot"${link ? '' : ' disabled'}>${t('openBot')}</button>`);
      sheetBody.querySelector('#partner-openbot').onclick = () => openTelegram(link);
    };
    if (!connected()) {
      openInBot();
      return;
    }

    openSheet(t('partner'), intro + '<div id="partner-loading" aria-busy="true"></div>');
    const loading = sheetBody.querySelector('#partner-loading');
    try {
      const data = await api('referral/me');
      if (!loading.isConnected) return;
      if (data.status === 'pending' || data.status === 'suspended') {
        openSheet(t('partner'), intro + `<p class="notice">${t(data.status === 'pending' ? 'waiting' : 'disabled')}</p>`);
        return;
      }
      if (data.status === 'none' || data.status === 'rejected') {
        openSheet(t('partner'), intro + `
          ${data.status === 'rejected' ? `<p class="notice">${t('rejected')}</p>` : ''}
          <button class="action" type="button" id="partner-apply">${t('apply')}</button>`);
        const apply = sheetBody.querySelector('#partner-apply');
        apply.onclick = () => partnerRequest(apply, 'referral/apply', {});
        return;
      }
      openSheet(t('partner'), intro + partnerStats(data));
      const copyLink = sheetBody.querySelector('#partner-copy');
      if (copyLink) copyLink.onclick = () => copy(data.url);
      const withdraw = sheetBody.querySelector('#partner-withdraw');
      withdraw.onclick = () => {
        const amount = sheetBody.querySelector('#partner-amount').valueAsNumber;
        const destination = sheetBody.querySelector('#partner-destination').value.trim();
        if (!Number.isSafeInteger(amount) || amount < 10000 || amount > data.available || destination.length < 5) {
          toast(t('invalid'));
          return;
        }
        partnerRequest(withdraw, 'referral/withdraw', { amount, destination });
      };
    } catch (error) {
      if (!loading.isConnected) return;
      if (error.message === 'endpoint_missing') openInBot();
      else openSheet(t('partner'), intro + `<p class="notice">${t('error')}</p>`);
    }
  }

  async function partnerRequest(button, path, fields) {
    button.disabled = true;
    try {
      await api(path, fields);
      if (button.isConnected) {
        if (path === 'referral/withdraw') toast(t('withdrawalSent'));
        await openPartners();
      }
    } catch (error) {
      if (button.isConnected) {
        toast(t(error.message === 'insufficient_referral_balance' ? 'insufficient' : 'error'));
        button.disabled = false;
      }
    }
  }

  shopPage.addEventListener('click', event => {
    const button = event.target.closest('button');
    if (!button) return;
    if (button.dataset.category) {
      state.category = button.dataset.category;
      render();
      if (!button.isConnected) filters.find(filter => filter.dataset.category === state.category)?.focus();
    }
    if (button.dataset.product) {
      const item = state.items.find(product => product.id === button.dataset.product);
      if (item) productSheet({
        item, quantity: widgetIds.has(item.id) ? undefined : item.min,
        option: widgetIds.has(item.id) ? '' : item.options[0][0], packs: 1,
        detail: '', requests: new Map()
      });
    }
    if (button.id === 'retry-shop') loadCatalog();
  });
  search.addEventListener('input', () => {
    clear.hidden = !search.value;
    render();
  });
  clear.onclick = () => {
    search.value = '';
    clear.hidden = true;
    search.focus();
    render();
  };
  loadCatalog();

  return {
    applyLanguage,
    openPartners,
    optionLabel,
    productTitle: id => state.items.find(product => product.id === id)?.title || id
  };
};

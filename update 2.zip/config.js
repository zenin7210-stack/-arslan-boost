// Public configuration. No passwords or bot tokens belong here.
// Edit this file for future price/contact changes; upload the same update.zip.
window.ARSLAN_CONFIG = {
  version: '2026-10-31.1',
  supportUrl: 'https://t.me/theaxadov',
  paymentAdminUrl: 'https://t.me/khblyv',
  // Entry costs: Bronze, Silver, Gold, Phoenix, Ranger, Champion, Master, Elite, Legend.
  // Calibration -> The Legend = 99,000 so‘m. Sub-ranges add the same steps.
  prices: [0, 1500, 1000, 4000, 6000, 8500, 12500, 16500, 20500, 28500],
  paymentTags: {uzcard:'_uzcard', humo:'_humo', terminal:'_terminal'},
  introDuration: 800,
  banners: {uz:'assets/hero-banner-hd.png', ru:'assets/hero-banner-ru.png'},
};
